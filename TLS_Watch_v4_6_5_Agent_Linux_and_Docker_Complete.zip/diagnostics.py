"""Bounded, admin-invoked TLS probes. No subprocesses or application traffic."""
from __future__ import annotations

import ipaddress
import re
import socket
import ssl
import threading
import time
from datetime import datetime, timezone

from cryptography import x509
from cryptography.hazmat.primitives import hashes

PROBE_SLOTS = threading.BoundedSemaphore(2)
DNS_SLOTS = threading.BoundedSemaphore(2)
TOTAL_TIMEOUT = 15.0
STEP_TIMEOUT = 4.0


def normalize_host(value):
    if not isinstance(value, str) or not value or len(value) > 253 or value != value.strip() or '%' in value:
        raise ValueError('Enter one hostname or IP address, without a URL, path or port')
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        pass
    try:
        host = value.rstrip('.').encode('idna').decode('ascii').lower()
    except UnicodeError:
        raise ValueError('Invalid hostname') from None
    if len(host) > 253 or not all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', label)
                                 for label in host.split('.')):
        raise ValueError('Invalid hostname')
    # Reject alternative numeric IP spellings accepted by some resolvers.
    if all(re.fullmatch(r'(?:[0-9]+|0x[0-9a-f]+)', label) for label in host.split('.')):
        raise ValueError('Use a canonical IPv4 or IPv6 address')
    return host


def validate_input(data):
    if not isinstance(data, dict) or set(data) - {'host', 'port'}:
        raise ValueError('Provide only host and port')
    host = normalize_host(data.get('host'))
    port = data.get('port', 443)
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('Port must be an integer from 1 to 65535')
    return host, port


def permitted(host, address, allowlist):
    ip = ipaddress.ip_address(address)
    if ip.version == 6 and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    # Always block local management and cloud metadata destinations.
    if (ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified
            or ip.is_reserved or str(ip) in ('100.100.100.200', '168.63.129.16')):
        return False
    if ip.version == 6 and (ip.sixtofour or ip.teredo or
            ip in ipaddress.ip_network('64:ff9b::/96') or
            ip in ipaddress.ip_network('64:ff9b:1::/48')):
        return False
    if not allowlist.strip():
        return True  # Private LAN destinations are an intentional agent use case.
    for entry in allowlist.split(','):
        entry = entry.strip()
        try:
            if ip in ipaddress.ip_network(entry, strict=False):
                return True
        except ValueError:
            try:
                if normalize_host(entry) == host:
                    return True
            except ValueError:
                continue
    return False


def resolve(host, port, timeout):
    # getaddrinfo has no portable timeout. A separate, capped daemon resolver
    # releases its slot only when the OS lookup actually finishes.
    if not DNS_SLOTS.acquire(blocking=False):
        raise RuntimeError('DNS resolver is busy; retry later')
    done, result = threading.Event(), []
    def worker():
        try:
            result.append(socket.getaddrinfo(host, port, type=socket.SOCK_STREAM))
        except OSError as exc:
            result.append(exc)
        finally:
            DNS_SLOTS.release()
            done.set()
    threading.Thread(target=worker, daemon=True, name='diagnostic-dns').start()
    if not done.wait(timeout):
        raise TimeoutError('DNS resolution timed out')
    if isinstance(result[0], Exception):
        raise result[0]
    unique = {}
    for family, _, _, _, sockaddr in result[0]:
        if family in (socket.AF_INET, socket.AF_INET6):
            unique[(family, sockaddr)] = (family, sockaddr)
    if not unique or len(unique) > 64:
        raise ValueError('DNS returned no usable addresses or exceeded the 64-address limit')
    return list(unique.values())


def identity_matches(cert, host):
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    except x509.ExtensionNotFound:
        return False  # SAN required; no legacy common-name fallback.
    try:
        return ipaddress.ip_address(host) in san.get_values_for_type(x509.IPAddress)
    except ValueError:
        for name in san.get_values_for_type(x509.DNSName):
            name = name.lower()
            if name == host:
                return True
            if name.startswith('*.') and name.count('*') == 1:
                if host.split('.')[1:] == name.split('.')[1:] and len(host.split('.')) == len(name.split('.')):
                    return True
        return False


def certificate_info(der, host):
    cert = x509.load_der_x509_certificate(der)
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        names = san.get_values_for_type(x509.DNSName) + [str(v) for v in san.get_values_for_type(x509.IPAddress)]
    except x509.ExtensionNotFound:
        names = []
    now = datetime.now(timezone.utc)
    return {'subject': cert.subject.rfc4514_string(), 'issuer': cert.issuer.rfc4514_string(),
            'serial_number': format(cert.serial_number, 'x'),
            'not_before': cert.not_valid_before_utc.isoformat(),
            'expires_at': cert.not_valid_after_utc.isoformat(),
            'days_remaining': (cert.not_valid_after_utc - now).days,
            'currently_valid': cert.not_valid_before_utc <= now <= cert.not_valid_after_utc,
            'sans': names[:200], 'sans_truncated': len(names) > 200,
            'sha256_fingerprint': cert.fingerprint(hashes.SHA256()).hex(),
            'hostname_verified': identity_matches(cert, host)}


def safe_error(exc):
    if isinstance(exc, ssl.SSLCertVerificationError):
        return {'code': 'certificate_validation_failed', 'message': getattr(exc, 'verify_message', 'Certificate validation failed'),
                'verify_code': getattr(exc, 'verify_code', None)}
    if isinstance(exc, (TimeoutError, socket.timeout)):
        return {'code': 'timeout', 'message': 'Operation exceeded its time limit'}
    if isinstance(exc, socket.gaierror):
        return {'code': 'dns_failed', 'message': 'DNS resolution failed; check the hostname and agent DNS configuration'}
    if isinstance(exc, ssl.SSLError):
        return {'code': 'tls_failed', 'message': 'TLS handshake failed: ' + str(getattr(exc, 'reason', None) or 'protocol error')}
    if isinstance(exc, ConnectionRefusedError):
        return {'code': 'connection_refused', 'message': 'Target refused the TCP connection'}
    if isinstance(exc, OSError):
        return {'code': 'network_error', 'message': 'Network connection failed; check routing, firewall and port'}
    return {'code': 'diagnostic_failed', 'message': 'Diagnostic could not complete; check target and local trust configuration'}


def run(host, port, bundle, allowlist=''):
    start = time.monotonic()
    deadline = start + TOTAL_TIMEOUT
    report = {'host': host, 'port': port, 'success': False, 'steps': [],
              'trust_source': 'System trust plus installed target PEM certificates',
              'note': 'Observational TLS uses an unverified connection to inspect failures. No application data is sent. Trust is tested separately against the same IP; separate connections may receive different certificates.'}
    def remaining():
        value = min(STEP_TIMEOUT, deadline - time.monotonic())
        if value <= 0:
            raise TimeoutError()
        return value
    def step(name, fn):
        began = time.monotonic()
        try:
            value = fn()
            report['steps'].append({'name': name, 'success': True, 'duration_ms': round((time.monotonic()-began)*1000, 1)})
            return value
        except (OSError, ValueError, RuntimeError) as exc:
            report['steps'].append({'name': name, 'success': False, 'duration_ms': round((time.monotonic()-began)*1000, 1), 'error': safe_error(exc)})
            return None
    try:
        destinations = step('DNS resolution', lambda: resolve(host, port, remaining()))
        if not destinations:
            return report
        # Reject mixed permitted/blocked DNS answers and connect to this exact snapshot.
        if not all(permitted(host, addr[0], allowlist) for _, addr in destinations):
            report['steps'].append({'name': 'Destination policy', 'success': False, 'duration_ms': 0,
                                    'error': {'code': 'destination_blocked', 'message': 'Destination blocked by address policy or configured allowlist'}})
            return report
        report['resolved_addresses'] = [addr[0] for _, addr in destinations]
        family, address = destinations[0]
        report['selected_address'] = address[0]
        report['address_note'] = 'Tests use the first DNS address only; no fallback or scan.'
        def connect():
            sock = socket.socket(family, socket.SOCK_STREAM)
            try:
                sock.settimeout(remaining())
                sock.connect(address)
                return sock
            except BaseException:
                sock.close()
                raise
        sock = step('TCP connectivity', connect)
        if sock is None:
            return report
        def observe():
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            sock.settimeout(remaining())
            with ctx.wrap_socket(sock, server_hostname=host) as channel:
                report['tls'] = {'protocol': channel.version(), 'cipher': channel.cipher()}
                der = channel.getpeercert(binary_form=True)
                if not der or len(der) > 30000:
                    raise ValueError('Missing or oversized certificate')
                report['certificate'] = certificate_info(der, host)
                return True
        try:
            observed = step('TLS handshake and peer certificate', observe)
        finally:
            sock.close()
        if not observed:
            return report
        identity = {'name': 'Hostname verification (SAN)',
                    'success': report['certificate']['hostname_verified'], 'duration_ms': 0}
        if not identity['success']:
            identity['error'] = {'code': 'hostname_mismatch', 'message': 'Certificate SAN does not match the requested hostname or IP (SAN required)'}
        report['steps'].append(identity)
        def verify_chain():
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            if bundle:
                ctx.load_verify_locations(cadata=bundle)
            with connect() as raw:
                raw.settimeout(remaining())
                with ctx.wrap_socket(raw, server_hostname=host) as channel:
                    cert = x509.load_der_x509_certificate(channel.getpeercert(binary_form=True))
                    report['trust_certificate_matches_observed'] = cert.fingerprint(hashes.SHA256()).hex() == report['certificate']['sha256_fingerprint']
                    return True
        trusted = step('Certificate chain and trust validation', verify_chain)
        if trusted and not report['trust_certificate_matches_observed']:
            report['steps'].append({'name': 'Certificate consistency', 'success': False, 'duration_ms': 0,
                                    'error': {'code': 'certificate_changed', 'message': 'The certificate changed between inspection and trust validation; rerun the test'}})
        report['success'] = bool(trusted and report['certificate']['hostname_verified']
                                 and report['trust_certificate_matches_observed'])
        return report
    finally:
        report['duration_ms'] = round((time.monotonic()-start)*1000, 1)
