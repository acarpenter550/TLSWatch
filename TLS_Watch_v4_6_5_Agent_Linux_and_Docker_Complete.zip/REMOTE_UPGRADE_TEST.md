# Test a remote agent upgrade from the primary

## Bootstrap and create publisher keys

An unmodified v4.6.3 agent has no remote-update receiver. Manually install v4.6.5
once, including its launcher. You can then remotely reinstall this same signed
v4.6.5 ZIP to exercise the delivery/verification/restart/acknowledgment workflow.
Same-version reinstalls are supported; version downgrades are blocked.

On your protected signing machine, using Python with the release dependencies:

```bash
python tools/sign_agent_release.py keygen --private-key publisher-private.pem --public-key publisher-public.txt
```

Keep `publisher-private.pem` offline/restricted and outside application/release
archives. The public file is a single base64 line. Set that line as:

- Primary service: `UPDATE_PUBLIC_KEY=<public line>`
- Agent `.env`: `AGENT_UPDATE_PUBLIC_KEY=<same public line>`
- Native agent `.env`: `AGENT_ALLOW_REMOTE_UPDATES=1` to permit installation.

Restart both services after setting these. The agent must be running through
`start_agent.sh`. Public-key pinning is independent of pairing and primary TLS
trust: a primary cannot install an unsigned or differently signed package.

## Sign this release

Use the standalone agent ZIP from this delivery, keeping its files at ZIP root:

```bash
python tools/sign_agent_release.py sign --private-key publisher-private.pem --zip TLS_Watch_v4_6_5_Agent_Linux_and_Docker_Complete.zip --out agent-4.6.5-signed.json
```

The tool refuses to overwrite existing keys or output packages. For another test,
choose a different output filename. No private key is embedded in the JSON.

## Request the update

1. On the primary dashboard, expand **Monitoring & Operations → Agent health & signed software updates**.
2. Upload `agent-4.6.5-signed.json`. The primary verifies the signature and archive.
3. Select v4.6.5 in the release list. For your agent, select **Stage release**.
4. Wait for its next polls, then select **Refresh operations**. Status should show
   **staged**. Both primary and agent verify the package; no runtime files changed.
5. For a native agent with local opt-in, select **Install & restart native agent**
   and confirm. The agent downloads/verifies again, waits for monitoring jobs to
   finish, exits with the launcher's update code, installs and restarts.
6. Refresh after reconnection. Expect agent version **4.6.5** and **installed**.
   The command is acknowledged, and configuration/queues remain intact.

The native installer preserves `.env` and all data. Runtime files have rollback
copies under `data/update_backup_4_6_5/`. File replacement failures restore those
files; the launcher quarantines failed requests and starts the retained runtime.
This is exception rollback, not a transactional guarantee against power loss
mid-install or a guarantee of health of arbitrary future signed application code.
Keep your stopped-service backup for deployment rollback. Per-version update
backups can be removed manually after validating the release.

Dependency changes require installing the new requirements manually first; the
remote receiver blocks them. Remote installation requires the native launcher and
explicit opt-in; direct-Python deployments support staging only.

Docker agents report installation as blocked. They can stage/verify the release;
rebuild and restart with the new agent source and existing volume to apply it.
No Docker socket or host-management credentials are exposed to the primary.
Use **Cancel pending request** to cancel an undelivered command; a command already
received by an agent cannot be cancelled retroactively.

## Trust model

Updates are served only over the enrolled agent's existing authenticated primary
connection. Each command/download is scoped to that agent registration. Existing
HTTPS verification and redirect rejection apply. Use HTTPS for primary traffic;
signature verification still protects code integrity on an explicitly allowed
HTTP lab link. The signature covers component, version, size and SHA-256. ZIP paths,
file types, counts, sizes, expected runtime files and Python syntax are checked.
No arbitrary update URL, shell command, dependency installer or private signing
key is sent by the primary. This is a local release registry, not an Internet
release feed or automatic unattended update policy.
