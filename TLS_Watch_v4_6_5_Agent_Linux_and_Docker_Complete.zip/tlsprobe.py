"""Shared CPython TLS chain inspection, with bounded certificate parsing."""
import hashlib
import socket
import ssl
from datetime import datetime, timezone
from cryptography import x509
from cryptography.hazmat.primitives import serialization


def describe(pem):
    if isinstance(pem,bytes): pem=pem.decode('ascii')
    if not isinstance(pem,str) or len(pem)>20000: raise ValueError('Certificate too large')
    cert=x509.load_pem_x509_certificate(pem.encode('ascii'))
    now=datetime.now(timezone.utc)
    try:
        sans=cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        names=sans.get_values_for_type(x509.DNSName)+[str(v) for v in sans.get_values_for_type(x509.IPAddress)]
    except x509.ExtensionNotFound: names=[]
    return {'subject':cert.subject.rfc4514_string(),'issuer':cert.issuer.rfc4514_string(),
            'not_before':cert.not_valid_before_utc.isoformat(),'expires_at':cert.not_valid_after_utc.isoformat(),
            'currently_valid':cert.not_valid_before_utc<=now<=cert.not_valid_after_utc,
            'sha256':hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest(),
            'sans':names[:200],'pem':pem}


def chain(channel, verified=False):
    method='get_verified_chain' if verified else 'get_unverified_chain'
    # Public on newer Python, CPython _sslobj equivalent on 3.10–3.12.
    getter=getattr(channel,method,None) or getattr(getattr(channel,'_sslobj',None),method,None)
    if getter is None:
        return [describe(ssl.DER_cert_to_PEM_cert(channel.getpeercert(True)))],False
    values=getter() or []
    if len(values)>10: raise ValueError('Certificate chain exceeds 10 certificates')
    result=[]
    for value in values:
        pem=value if isinstance(value,bytes) else value.public_bytes()
        if isinstance(pem,bytes) and not pem.startswith(b'-----BEGIN'):
            pem=ssl.DER_cert_to_PEM_cert(pem)
        result.append(describe(pem))
    return result,True


def inspect(host, destinations, timeout, bundle=''):
    chosen=None
    details={}
    error=None
    for family,address in destinations[:8]:
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname=False
        ctx.verify_mode=ssl.CERT_NONE
        try:
            with socket.socket(family,socket.SOCK_STREAM) as raw:
                raw.settimeout(timeout)
                raw.connect(address)
                with ctx.wrap_socket(raw,server_hostname=host) as channel:
                    leaf=channel.getpeercert(True)
                    if not leaf or len(leaf)>15000: raise ValueError('Missing/oversized leaf certificate')
                    details={'protocol':channel.version(),'cipher':channel.cipher(),
                             'selected_address':address[0]}
                    details['presented_chain'],details['chain_capture_supported']=chain(channel)
            chosen=(family,address)
            break
        except OSError as exc: error=exc
    if chosen is None: raise OSError(str(error or 'TLS handshake failed'))
    verified=True
    reason=None
    ctx=ssl.create_default_context()
    if bundle: ctx.load_verify_locations(cadata=bundle)
    try:
        with socket.socket(chosen[0],socket.SOCK_STREAM) as raw:
            raw.settimeout(timeout)
            raw.connect(chosen[1])
            with ctx.wrap_socket(raw,server_hostname=host) as channel:
                if channel.getpeercert(True)!=leaf: raise ssl.SSLError('Certificate changed during verification')
                details['verified_chain'],_=chain(channel,True)
    except OSError as exc:
        verified=False
        reason=str(getattr(exc,'verify_message',None) or getattr(exc,'reason',None) or 'TLS trust/hostname verification failed')[:600]
    details['trust_verified']=verified
    details['trust_error']=reason
    details['trust_source']='system plus installed target PEMs' if bundle else 'system'
    details['revocation_checked']=False
    details.update(chain_warnings(details))
    import json
    if len(json.dumps(details))>200000: raise ValueError('Certificate chain details exceed the 200 KB reporting limit')
    return {'success':True,'certificate_pem':ssl.DER_cert_to_PEM_cert(leaf),
            'tls_verified':verified,'verify_error':reason,'tls_details':details}


def chain_warnings(details):
    presented=details.get('presented_chain',[])
    verified=details.get('verified_chain',[])
    observed={c['sha256'] for c in presented}
    missing=[c['subject'] for c in verified[1:-1] if c['sha256'] not in observed]
    invalid=[c['subject'] for c in presented if not c['currently_valid']]
    return {'missing_intermediates':missing,'invalid_date_certificates':invalid,
            'chain_note':'A root normally comes from local trust and need not be sent by the server. Missing-path diagnosis is limited when validation fails.'}


def sanitize(details):
    """Reparse agent-supplied chains; never trust their subject/validity fields."""
    if details is None: return None
    if not isinstance(details,dict): raise ValueError('Invalid TLS details')
    import json
    if len(json.dumps(details))>220000: raise ValueError('TLS details too large')
    output={}
    for key in ('protocol','selected_address','trust_source','trust_error'):
        value=details.get(key)
        if value is not None and (not isinstance(value,str) or len(value)>600): raise ValueError('Invalid TLS '+key)
        output[key]=value
    cipher=details.get('cipher')
    if cipher is not None and (not isinstance(cipher,(list,tuple)) or len(cipher)!=3 or len(str(cipher))>300): raise ValueError('Invalid cipher')
    output['cipher']=cipher
    for key in ('trust_verified','chain_capture_supported','revocation_checked'):
        if key in details and type(details[key]) is not bool: raise ValueError('Invalid TLS flag')
        output[key]=details.get(key,False)
    for key in ('presented_chain','verified_chain'):
        values=details.get(key,[])
        if not isinstance(values,list) or len(values)>10: raise ValueError('Invalid certificate chain')
        output[key]=[describe(item.get('pem')) for item in values if isinstance(item,dict)]
        if len(output[key])!=len(values): raise ValueError('Invalid chain entry')
    output.update(chain_warnings(output))
    return output
