"""Agent v4.6.5 spool bounds, minimal Linux health and signed update commands."""
import json
import os
from pathlib import Path
import shutil
import threading
import time
import updates


def queue_limits():
    def number(name,default,low,high):
        return max(low,min(high,int(os.environ.get(name,str(default)))))
    return {'rows':number('AGENT_QUEUE_MAX_RESULTS',10000,10,1000000),
            'bytes':number('AGENT_QUEUE_MAX_BYTES',50000000,1000000,2000000000),
            'days':number('AGENT_REJECTED_RETENTION_DAYS',30,1,365)}


def capacity(con, extra=0):
    limits=queue_limits()
    row=con.execute('SELECT COUNT(*),COALESCE(SUM(LENGTH(CAST(payload_json AS BLOB))),0) FROM outbox').fetchone()
    return row[0]<limits['rows'] and row[1]+extra<=limits['bytes']


def prune(con,now):
    from datetime import datetime,timedelta
    cutoff=(datetime.fromisoformat(now.replace('Z','+00:00'))-timedelta(days=queue_limits()['days'])).isoformat(timespec='seconds').replace('+00:00','Z')
    # Pending results are never discarded, even if older than the retention period.
    con.execute("DELETE FROM outbox WHERE status='rejected' AND created_at<?",(cutoff,))
    con.execute('PRAGMA incremental_vacuum(64)')


_cpu_lock=threading.Lock()
_cpu_previous=None
UPDATE_LOCK=threading.Lock()


def health(data, stats):
    result={'disk_free_bytes':shutil.disk_usage(data).free,
            'oldest_pending_at':stats.get('oldest_pending_at'),
            'queue_limits':queue_limits(),'queue_blocked':stats.get('queue_blocked',False)}
    # No process command lines, environment, user names or network inventories.
    try:
        values={line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemTotal:','MemAvailable:'))}
        result.update(memory_total_bytes=values['MemTotal'],memory_available_bytes=values['MemAvailable'])
        counters=[int(x) for x in Path('/proc/stat').read_text().splitlines()[0].split()[1:9]]
        total=sum(counters); idle=counters[3]+counters[4]
        global _cpu_previous
        with _cpu_lock:
            if _cpu_previous and total>_cpu_previous[0]: result['cpu_percent']=round(100*(1-(idle-_cpu_previous[1])/(total-_cpu_previous[0])),1)
            _cpu_previous=(total,idle)
    except (OSError,ValueError,KeyError,IndexError):
        result['metrics_note']='CPU/memory metrics require Linux /proc; unavailable values are omitted'
    return result


def update_state(data,pid=None):
    name='update_status_'+pid+'.json' if pid else 'agent_update.json'
    try: return json.loads((data/name).read_text())
    except (OSError,ValueError): return {'status':'idle'}


def receive_update(m,settings,command):
    if not isinstance(command,dict) or command.get('action') not in ('stage','install'): return
    cid=command.get('command_id')
    if not isinstance(cid,str) or len(cid)!=32: return
    # Commands are scoped to a single enrollment; repeated polls are idempotent.
    with UPDATE_LOCK:
        previous=update_state(m.DATA_DIR,settings['profile_id'])
        if previous.get('command_id')==cid and previous.get('status') in ('staged','installed','failed','blocked'): return
        if (m.DATA_DIR/'pending_update.json').exists(): return
        state={'command_id':cid,'version':command.get('version'),'status':'failed','profile_id':settings['profile_id']}
        try:
            key=os.environ.get('AGENT_UPDATE_PUBLIC_KEY','')
            if not key: raise ValueError('Pinned update public key is not configured')
            package=m.primary_call(settings,'/agent/v1/update',{'command_id':cid})
            if not m.still_active(settings): return
            updates.verify(package,key,m.VERSION)
            if package['manifest']['version']!=command.get('version') or package['manifest']['sha256']!=command.get('release_id'): raise ValueError('Command does not match signed package')
            if command['action']=='install':
                if os.environ.get('AGENT_ALLOW_REMOTE_UPDATES','0')!='1':
                    state.update(status='blocked',message='Set AGENT_ALLOW_REMOTE_UPDATES=1 to authorize native remote installation')
                elif os.environ.get('AGENT_DEPLOYMENT','native')=='docker':
                    state.update(status='blocked',message='Docker: stage the release and rebuild the image; running image is immutable')
                elif os.environ.get('AGENT_UPDATE_LAUNCHER')!='1':
                    state.update(status='blocked',message='Remote installation requires running through start_agent.sh')
                else:
                    # The native launcher installs before starting the next process.
                    current=(Path(m.__file__).resolve().parent/'requirements.txt').read_text().splitlines()
                    import io,zipfile
                    with zipfile.ZipFile(io.BytesIO(updates.verify(package,key,m.VERSION))) as z:
                        if z.read('requirements.txt').decode().splitlines()!=current: raise ValueError('Dependency changes require manual installation first')
                    updates.atomic_json(m.DATA_DIR/'pending_update.json',package)
                    state.update(status='restarting',message='Signed update will be applied by the native launcher')
            else:
                updates.atomic_json(m.DATA_DIR/'staged_update.json',package)
                state.update(status='staged',message='Signed release verified and staged')
        except Exception:
            state['message']='Update failed; check signing key, connectivity, dependency compatibility and release policy'
        updates.atomic_json(m.DATA_DIR/'agent_update.json',state)
        updates.atomic_json(m.DATA_DIR/('update_status_'+settings['profile_id']+'.json'),state)
    if state['status']=='restarting':
        request_restart(m)


def request_restart(m):
    def restart():
        time.sleep(2)
        m.stop_event.set()
        m.check_pool.shutdown(wait=True)
        os._exit(75)
    threading.Thread(target=restart,daemon=True,name='agent-update-restart').start()
