"""Regression checks for the v4.6.2 agent admin accordions, using only stdlib."""
import re
import unittest
from pathlib import Path
from html.parser import HTMLParser

SOURCE = (Path(__file__).resolve().parents[1] / 'agent.py').read_text()
import agent
PAGE = agent.PAGE

class Outline(HTMLParser):
    def __init__(self):
        super().__init__()
        self.stack=[]
        self.panels={}
        self.ids={}
    def handle_starttag(self, tag, attrs):
        attrs=dict(attrs)
        if 'id' in attrs:
            self.ids[attrs['id']]=self.ids.get(attrs['id'],0)+1
        if tag == 'details':
            self.stack.append({'id':attrs.get('id'), 'summary':0, 'forms':[]})
        elif tag == 'summary' and self.stack:
            self.stack[-1]['summary']+=1
        elif tag == 'form' and self.stack:
            self.stack[-1]['forms'].append(attrs.get('id'))
    def handle_endtag(self, tag):
        if tag == 'details' and self.stack:
            panel=self.stack.pop()
            if panel['id']:
                self.panels[panel['id']]=panel

class AccordionUI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.parser=Outline()
        cls.parser.feed(PAGE)
    def test_all_three_native_rollups(self):
        self.assertEqual(self.parser.panels['pairAccordion']['summary'],1)
        self.assertEqual(self.parser.panels['trustAccordion']['summary'],1)
        self.assertEqual(self.parser.panels['httpsAccordion']['summary'],1)
    def test_forms_stay_inside_appropriate_panel(self):
        self.assertIn('pair', self.parser.panels['pairAccordion']['forms'])
        self.assertIn('trustForm', self.parser.panels['trustAccordion']['forms'])
        self.assertIn('uiTlsForm', self.parser.panels['httpsAccordion']['forms'])
    def test_existing_interaction_ids_not_duplicated(self):
        for uid in ('pair','url','code','trustForm','trustRows','targetPem','uiTlsForm',
                    'adminCert','adminKey','enableHttps','disableHttps','removeAdminTls'):
            self.assertEqual(self.parser.ids.get(uid),1,uid)
    def test_first_time_pairing_and_counts(self):
        self.assertIn("if(!d.primaries.length)byId('pairAccordion').open=true",PAGE)
        self.assertIn("byId('trustCount').textContent=d.certificates.length+' installed'",PAGE)
        self.assertIn('id="httpsState"',PAGE)

if __name__=='__main__': unittest.main()
