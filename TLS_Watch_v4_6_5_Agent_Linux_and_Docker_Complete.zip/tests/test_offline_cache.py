"""Durability and independent replay for v4.6 primary-local SQLite outboxes."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import agent


class OfflineReplayTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.patchpaths = patch.multiple(agent, DATA_DIR=self.dir,
                                         CONFIG_FILE=self.dir/'agent.json',
                                         LEGACY_CACHE_FILE=self.dir/'agent_cache.sqlite3')
        self.patchpaths.start()
        self.addCleanup(self.patchpaths.stop)
        with agent.lock:
            agent.config = {'schema_version': 2, 'primaries': []}
            agent.primary_states.clear()
            agent.local_inflight.clear()
            agent.syncing.clear()
            agent.next_polls.clear()
        self.profile = {'profile_id': agent.profile_id(), 'agent_name': 'Customer',
                        'primary_url': 'https://customer.example.test',
                        'agent_id': 9, 'token': 'tlsw-agent-customer'}
        with agent.lock:
            agent.config['primaries'].append(self.profile)
            agent.primary_states[self.profile['profile_id']] = agent.default_state()
        agent.init_cache(self.profile['profile_id'])
        self.site = {'site_id': 17, 'url': 'https://internal.lan', 'hostname': 'internal.lan',
                     'port': 443, 'paused': 0, 'last_checked_at': None,
                     'next_check_at': agent.stamp()}
        agent.reconcile_assignments(self.profile['profile_id'], [self.site])

    def test_outage_stores_observation_and_replay_dequeues(self):
        pid = self.profile['profile_id']
        with patch.object(agent, 'check_certificate', return_value={'success': False, 'error': 'TLS down'}):
            agent.run_local_check([(pid, self.site)])
        self.assertEqual(agent.cache_stats(pid)['queued_results'], 1)
        with patch.object(agent, 'primary_call', side_effect=OSError('offline')):
            with self.assertRaises(OSError):
                agent.flush_outbox(self.profile)
        self.assertEqual(agent.cache_stats(pid)['queued_results'], 1)
        agent.init_cache(pid)  # close/reopen as if process restarted
        def accepted(settings, path, body):
            self.assertEqual(settings['token'], self.profile['token'])
            self.assertEqual(path, '/agent/v1/results/batch')
            self.assertTrue(body['results'][0]['checked_at'])
            return {'outcomes': [{'result_id': r['result_id'], 'status': 'accepted'} for r in body['results']]}
        with patch.object(agent, 'primary_call', side_effect=accepted):
            agent.flush_outbox(self.profile)
        self.assertEqual(agent.cache_stats(pid)['queued_results'], 0)

    def test_reconcile_preserves_local_schedule_while_queued(self):
        pid = self.profile['profile_id']
        with patch.object(agent, 'check_certificate', return_value={'success': False, 'error': 'no DNS'}):
            agent.run_local_check([(pid, self.site)])
        with agent.cache_db(pid) as con:
            first = con.execute('SELECT last_checked_at,next_check_at FROM inventory WHERE site_id=17').fetchone()
        agent.reconcile_assignments(pid, [self.site])
        with agent.cache_db(pid) as con:
            second = con.execute('SELECT last_checked_at,next_check_at FROM inventory WHERE site_id=17').fetchone()
        self.assertEqual(tuple(first), tuple(second))


if __name__ == '__main__':
    unittest.main()
