"""Unit/integration checks for CA trust, local admin TLS and primary management.
Run after installing requirements: python -m unittest discover -s tests -v.
"""
import base64
import json
import ssl
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import agent

# A real X.509 PEM fixture is generated with openssl on developer CI; tests here
# cover auth and malformed inputs without adding an opaque private key to the repo.
class TLSConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        path = Path(self.temp.name)
        self.patcher = patch.multiple(
            agent, DATA_DIR=path, TRUST_DIR=path / 'trusted_targets',
            TRUST_INDEX=path / 'trusted_targets' / 'index.json',
            UI_TLS_CONFIG=path / 'ui_tls.json',
            UI_TLS_CERT=path / 'ui_server_cert.pem',
            UI_TLS_KEY=path / 'ui_server_key.pem',
        )
        self.patcher.start()
        self.addCleanup(self.patcher.stop)
        self.headers = {'Authorization': 'Basic ' + base64.b64encode(b'admin:admin1234').decode(),
                        'X-TLSWatch-Agent': '1'}

    def test_tls_disabled_until_explicitly_enabled(self):
        self.assertFalse(agent.tls_ui_config()['enabled'])
        with agent.app.test_client() as client:
            self.assertEqual(client.post('/api/security/ui-tls',
                json={'action':'enable'}, headers=self.headers).status_code, 400)
            result = client.get('/api/security/ui-tls', headers=self.headers).json
            self.assertEqual(result['installed'], False)
            self.assertEqual(result['enabled_on_next_start'], False)

    def test_https_toggle_is_persisted_without_leaking_key(self):
        with agent.app.test_client() as client:
            self.assertEqual(client.post('/api/security/ui-tls',
                json={'action':'disable'}, headers=self.headers).status_code, 200)
            self.assertFalse(json.loads(agent.UI_TLS_CONFIG.read_text())['enabled'])
            self.assertEqual(client.post('/api/security/ui-tls',
                json={'action':'install', 'certificate_pem':'garbage',
                      'private_key_pem':'garbage'}, headers=self.headers).status_code, 400)
            response = client.get('/api/security/ui-tls', headers=self.headers)
            self.assertNotIn('private_key_pem', response.get_data(as_text=True))
            self.assertEqual(client.post('/api/security/ui-tls',
                json={'action':'delete'}, headers=self.headers).status_code, 200)

    def test_invalid_ca_certificate_rejected_and_path_inputs_not_used(self):
        with agent.app.test_client() as client:
            self.assertEqual(client.post('/api/trust/add',
                json={'label':'bad', 'pem':'not-a-cert'}, headers=self.headers).status_code, 400)
            self.assertEqual(client.post('/api/trust/delete',
                json={'fingerprint':'../../evil'}, headers=self.headers).status_code, 400)
            self.assertEqual(client.get('/api/trust',headers=self.headers).json['certificates'],[])

    def test_write_endpoints_require_auth_and_csrf_header(self):
        with agent.app.test_client() as client:
            self.assertEqual(client.post('/api/trust/add',json={}).status_code,401)
            self.assertEqual(client.post('/api/security/ui-tls',
                json={'action':'disable'},headers={'Authorization':self.headers['Authorization']}).status_code,403)

if __name__ == '__main__':
    unittest.main()
