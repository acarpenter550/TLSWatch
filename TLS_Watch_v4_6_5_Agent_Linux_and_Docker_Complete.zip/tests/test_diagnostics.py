"""Offline security and real TLS integration tests. All keys are ephemeral."""
import base64
import ipaddress
import socket
import ssl
import tempfile
import threading
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
import agent
import diagnostics as d


class DiagnosticsTests(unittest.TestCase):
    def setUp(self):
        self.headers = {'Authorization': 'Basic '+base64.b64encode(b'admin:admin1234').decode(),
                        'X-TLSWatch-Agent': '1'}

    def test_input_validation(self):
        for host in ('https://example.com', 'a/b', 'a:443', 'user@host', '-bad', 'a..b',
                     'x\n', '*.example.com', '127.1', '2130706433', '0x7f000001', '2001:4860::8888%eth0', '', None):
            with self.subTest(host=host), self.assertRaises(ValueError):
                d.validate_input({'host': host})
        for port in (0, 65536, True, 4.5, '443', None):
            with self.assertRaises(ValueError): d.validate_input({'host':'example.com', 'port':port})
        for value in ([], None, {'host':'example.com','command':'ping'}):
            with self.assertRaises(ValueError): d.validate_input(value)
        self.assertEqual(d.validate_input({'host':'EXAMPLE.com.'}), ('example.com',443))
        self.assertEqual(d.normalize_host('bücher.example'), 'xn--bcher-kva.example')

    def test_address_policy_and_allowlist(self):
        for address in ('127.0.0.1','0.0.0.0','169.254.169.254','224.0.0.1','::1',
                        '::ffff:127.0.0.1','fe80::1','100.100.100.200','168.63.129.16',
                        '64:ff9b::7f00:1', '2002:7f00:1::'):
            self.assertFalse(d.permitted('test.lan', address, 'test.lan'), address)
        self.assertTrue(d.permitted('test.lan','10.5.0.1',''))
        self.assertTrue(d.permitted('test.lan','10.5.0.1','10.5.0.0/16'))
        self.assertTrue(d.permitted('test.lan','10.5.0.1','test.lan'))
        self.assertFalse(d.permitted('test.lan','10.6.0.1','10.5.0.0/16'))

    def test_admin_csrf_and_fail_closed(self):
        with agent.app.test_client() as c:
            self.assertEqual(c.post('/api/diagnostics',json={}).status_code,401)
            self.assertEqual(c.post('/api/diagnostics',json={},headers={'Authorization':self.headers['Authorization']}).status_code,403)
            self.assertEqual(c.post('/api/diagnostics',json={},headers={**self.headers,'Origin':'https://evil.example'}).status_code,403)
            with patch.object(agent,'UI_PASSWORD',''):
                self.assertEqual(c.post('/api/diagnostics',json={},headers=self.headers).status_code,401)
            self.assertEqual(c.post('/api/diagnostics',json=[],headers=self.headers).status_code,400)
            self.assertEqual(c.post('/api/diagnostics',data='x',headers=self.headers).status_code,400)
            with patch.object(agent,'local_trust_bundle',return_value=''), patch.object(d,'run',return_value={'success':True}):
                response=c.post('/api/diagnostics',json={'host':'example.com'},headers=self.headers)
                self.assertEqual(response.status_code,200)
                self.assertEqual(response.headers['Cache-Control'],'no-store')

    def test_concurrency_limit(self):
        with patch.object(d,'PROBE_SLOTS',threading.BoundedSemaphore(0)), agent.app.test_client() as c:
            self.assertEqual(c.post('/api/diagnostics',json={'host':'example.com'},headers=self.headers).status_code,429)

    def test_dns_errors_timeout_and_cap(self):
        with patch.object(socket,'getaddrinfo',side_effect=socket.gaierror()):
            self.assertEqual(d.run('example.com',443,'')['steps'][0]['error']['code'],'dns_failed')
        release=threading.Event()
        def slow(*args,**kwargs):
            release.wait(1)
            return []
        with patch.object(socket,'getaddrinfo',side_effect=slow):
            try:
                with self.assertRaises(TimeoutError): d.resolve('example.com',443,.01)
            finally: release.set()
        with patch.object(d,'DNS_SLOTS',threading.BoundedSemaphore(0)):
            with self.assertRaises(RuntimeError): d.resolve('example.com',443,.01)

    def test_blocked_mixed_dns_never_connects(self):
        answers=[(socket.AF_INET,('10.0.0.1',443)),(socket.AF_INET,('127.0.0.1',443))]
        with patch.object(d,'resolve',return_value=answers), patch.object(socket,'socket') as sock:
            result=d.run('example.com',443,'')
            self.assertEqual(result['steps'][-1]['error']['code'],'destination_blocked')
            sock.assert_not_called()

    def test_network_errors_are_sanitized(self):
        self.assertNotIn('secret',str(d.safe_error(OSError('secret /data/agent.json token=abc'))))
        with patch.object(d,'resolve',return_value=[(socket.AF_INET,('10.1.2.3',443))]), patch.object(socket.socket,'connect',side_effect=ConnectionRefusedError()):
            result=d.run('example.com',443,'')
            self.assertFalse(result['success'])
            self.assertEqual(result['steps'][-1]['error']['code'],'connection_refused')

    def test_rollup_is_collapsed_and_safe(self):
        self.assertIn('id="diagnosticsAccordion"><summary>',agent.PAGE)
        self.assertIn("byId('diagnosticsResult').textContent=",agent.PAGE)
        self.assertIn('button.disabled=true',agent.PAGE)

    def test_handshake_timeout_and_non_tls(self):
        for error, code in ((TimeoutError(), 'timeout'), (ssl.SSLError(1, 'not TLS'), 'tls_failed')):
            with self.subTest(code=code), patch.object(d,'resolve',return_value=[(socket.AF_INET,('10.1.2.3',443))]), patch.object(socket.socket,'connect'), patch.object(ssl.SSLContext,'wrap_socket',side_effect=error):
                result=d.run('example.com',443,'')
                self.assertFalse(result['success'])
                self.assertEqual(result['steps'][-1]['error']['code'],code)

    def test_trust_load_failure_is_sanitized(self):
        with patch.object(agent,'local_trust_bundle',side_effect=ValueError('secret')), agent.app.test_client() as c:
            response=c.post('/api/diagnostics',json={'host':'example.com'},headers=self.headers)
            self.assertEqual(response.status_code,503)
            self.assertNotIn('secret',response.get_data(as_text=True))


class LocalTLS(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.path=Path(cls.temp.name)
        cls.key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        now=datetime.now(timezone.utc)
        name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Diagnostics Test CA')])
        cls.ca=(x509.CertificateBuilder().subject_name(name).issuer_name(name)
                .public_key(cls.key.public_key()).serial_number(x509.random_serial_number())
                .not_valid_before(now-timedelta(days=1)).not_valid_after(now+timedelta(days=30))
                .add_extension(x509.BasicConstraints(ca=True,path_length=None),critical=True)
                .sign(cls.key,hashes.SHA256()))
        cls.bundle=cls.ca.public_bytes(serialization.Encoding.PEM).decode()

    @classmethod
    def tearDownClass(cls): cls.temp.cleanup()

    def probe(self, host='service.example', trusted=True, expired=False):
        now=datetime.now(timezone.utc)
        name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'service.example')])
        cert=(x509.CertificateBuilder().subject_name(name).issuer_name(self.ca.subject)
              .public_key(self.key.public_key()).serial_number(x509.random_serial_number())
              .not_valid_before(now-timedelta(days=3))
              .not_valid_after(now+timedelta(days=-1 if expired else 7))
              .add_extension(x509.SubjectAlternativeName([x509.DNSName('service.example'),
                              x509.DNSName('*.customer.example'),x509.IPAddress(ipaddress.ip_address('10.1.2.3'))]),critical=False)
              .sign(self.key,hashes.SHA256()))
        certfile=self.path/'server.pem'
        keyfile=self.path/'key.pem'
        certfile.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
        keyfile.write_bytes(self.key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(certfile,keyfile)
        listener=socket.socket()
        listener.bind(('127.0.0.1',0))
        listener.listen(5)
        listener.settimeout(.1)
        port=listener.getsockname()[1]
        stop=threading.Event()
        def serve():
            while not stop.is_set():
                try: raw,_=listener.accept()
                except socket.timeout: continue
                except OSError: return
                try:
                    raw.settimeout(2)
                    with ctx.wrap_socket(raw,server_side=True): pass
                except (OSError,ssl.SSLError): raw.close()
        thread=threading.Thread(target=serve,daemon=True)
        thread.start()
        try:
            # Fixture only: allow the local test server, never change production policy.
            with patch.object(d,'resolve',return_value=[(socket.AF_INET,('127.0.0.1',port))]), patch.object(d,'permitted',return_value=True):
                return d.run(host,port,self.bundle if trusted else '')
        finally:
            stop.set()
            thread.join(3)
            listener.close()

    def test_installed_ca_chain_protocol_cipher_identity(self):
        result=self.probe()
        self.assertTrue(result['success'],result)
        self.assertTrue(result['trust_certificate_matches_observed'])
        self.assertTrue(result['tls']['protocol'].startswith('TLS'))
        self.assertTrue(result['tls']['cipher'][0])
        self.assertIn('Diagnostics Test CA',result['certificate']['issuer'])
        self.assertEqual(len(result['certificate']['sha256_fingerprint']),64)
        self.assertIn('10.1.2.3',result['certificate']['sans'])
        self.assertLess(result['duration_ms'],15000)

    def test_unknown_ca_still_returns_peer_details(self):
        result=self.probe(trusted=False)
        self.assertFalse(result['success'])
        self.assertTrue(result['certificate']['hostname_verified'])
        self.assertEqual(result['steps'][-1]['error']['code'],'certificate_validation_failed')

    def test_hostname_mismatch_independent_of_trust(self):
        result=self.probe(host='wrong.example')
        self.assertFalse(result['success'])
        self.assertFalse(result['certificate']['hostname_verified'])
        self.assertTrue(result['steps'][-1]['success'])

    def test_expired_certificate(self):
        result=self.probe(expired=True)
        self.assertFalse(result['success'])
        self.assertFalse(result['certificate']['currently_valid'])
        self.assertEqual(result['steps'][-1]['error']['code'],'certificate_validation_failed')

    def test_ip_san_and_wildcard(self):
        self.assertTrue(self.probe(host='10.1.2.3')['success'])
        self.assertTrue(self.probe(host='one.customer.example')['success'])
        self.assertFalse(self.probe(host='two.one.customer.example')['success'])
