"""Run: python -m unittest discover -s tests -v (Flask installed)."""
import base64
import tempfile
import sqlite3
from contextlib import closing
import unittest
from pathlib import Path
from unittest.mock import patch

import agent


class MultiPrimaryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.paths = patch.multiple(agent, DATA_DIR=self.dir,
                                    CONFIG_FILE=self.dir/'agent.json',
                                    LEGACY_CACHE_FILE=self.dir/'agent_cache.sqlite3')
        self.paths.start()
        self.addCleanup(self.paths.stop)
        with agent.lock:
            agent.config = {'schema_version': 2, 'primaries': []}
            agent.primary_states.clear()
            agent.local_inflight.clear()
            agent.syncing.clear()
            agent.next_polls.clear()

    def profile(self, name, url, token):
        pid = agent.profile_id()
        profile = {'profile_id': pid, 'agent_name': name, 'agent_id': 3,
                   'primary_url': url, 'token': token}
        with agent.lock:
            agent.config['primaries'].append(profile)
            agent.primary_states[pid] = agent.default_state()
        agent.init_cache(pid)
        return profile

    @staticmethod
    def assignment(site_id, hostname='internal.example.test'):
        return {'site_id': site_id, 'hostname': hostname, 'port': 443,
                'url': 'https://' + hostname, 'paused': 0,
                'next_check_at': agent.stamp(), 'last_checked_at': None}

    def test_same_numeric_site_ids_never_collide_across_primaries(self):
        a = self.profile('MSP', 'https://msp.example.test', 'tlsw-agent-a')
        b = self.profile('Customer', 'https://customer.example.test', 'tlsw-agent-b')
        sa, sb = self.assignment(17, 'msp.lan'), self.assignment(17, 'customer.lan')
        agent.reconcile_assignments(a['profile_id'], [sa])
        agent.reconcile_assignments(b['profile_id'], [sb])
        with patch.object(agent, 'check_certificate', side_effect=OSError('DNS unreachable')):
            agent.run_local_check([(a['profile_id'], sa)])
            agent.run_local_check([(b['profile_id'], sb)])
        self.assertEqual(agent.cache_stats(a['profile_id'])['queued_results'], 1)
        self.assertEqual(agent.cache_stats(b['profile_id'])['queued_results'], 1)
        calls = []
        def fake_primary(settings, path, data):
            calls.append((settings['primary_url'], settings['token'], data['results'][0]['site_id']))
            return {'outcomes': [{'result_id': r['result_id'], 'status': 'accepted'} for r in data['results']]}
        with patch.object(agent, 'primary_call', side_effect=fake_primary):
            agent.flush_outbox(a)
        self.assertEqual(calls, [('https://msp.example.test', 'tlsw-agent-a', 17)])
        self.assertEqual(agent.cache_stats(a['profile_id'])['queued_results'], 0)
        self.assertEqual(agent.cache_stats(b['profile_id'])['queued_results'], 1)

    def test_shared_handshake_creates_independent_ids_and_schedules(self):
        a = self.profile('MSP', 'https://msp.example.test', 'tlsw-agent-a')
        b = self.profile('Customer', 'https://customer.example.test', 'tlsw-agent-b')
        sa = self.assignment(7, 'shared.lan')
        sb = self.assignment(7, 'shared.lan')
        agent.reconcile_assignments(a['profile_id'], [sa])
        agent.reconcile_assignments(b['profile_id'], [sb])
        with patch.object(agent, 'check_certificate', return_value={'success': False, 'error': 'test'}) as check:
            # Execute the grouping operation synchronously by intercepting dispatch.
            with patch.object(agent.check_pool, 'submit', side_effect=lambda fn, jobs: fn(jobs)):
                agent.schedule_due()
            self.assertEqual(check.call_count, 1)
        with agent.cache_db(a['profile_id']) as db:
            first = db.execute('SELECT result_id, payload_json FROM outbox').fetchone()
        with agent.cache_db(b['profile_id']) as db:
            second = db.execute('SELECT result_id, payload_json FROM outbox').fetchone()
        self.assertIsNotNone(first)
        self.assertIsNotNone(second)
        self.assertNotEqual(first['result_id'], second['result_id'])
        self.assertEqual(agent.cache_stats(a['profile_id'])['queued_results'], 1)
        self.assertEqual(agent.cache_stats(b['profile_id'])['queued_results'], 1)

    def test_one_primary_offline_other_synchronizes(self):
        a = self.profile('Down', 'https://down.example.test', 'tlsw-agent-a')
        b = self.profile('Up', 'https://up.example.test', 'tlsw-agent-b')
        def fake(settings, path, data):
            if settings['primary_url'].startswith('https://down'):
                raise OSError('offline')
            return {'timezone': 'America/New_York', 'assignments': [self.assignment(3, 'up.lan')]}
        with patch.object(agent, 'primary_call', side_effect=fake):
            agent.poll_one(a)
            agent.poll_one(b)
        self.assertIn('offline', agent.primary_states[a['profile_id']]['last_error'])
        self.assertIsNone(agent.primary_states[b['profile_id']]['last_error'])
        self.assertEqual(agent.cache_stats(a['profile_id'])['assigned_sites'], 0)
        self.assertEqual(agent.cache_stats(b['profile_id'])['assigned_sites'], 1)

    def test_v45_migration_keeps_pending_results_and_original_database(self):
        original = {'primary_url': 'https://old.example.test', 'agent_name': 'Old',
                    'token': 'tlsw-agent-old', 'agent_id': 1}
        agent.CONFIG_FILE.write_text(__import__('json').dumps(original), encoding='utf-8')
        with closing(sqlite3.connect(agent.LEGACY_CACHE_FILE)) as db:
            db.executescript(agent.CACHE_SCHEMA)
            db.execute('INSERT INTO inventory(site_id,url,hostname,port,paused,next_check_at) VALUES(?,?,?,?,?,?)',
                       (2, 'https://old.lan', 'old.lan', 443, 0, agent.stamp()))
            db.execute('INSERT INTO outbox(result_id,site_id,checked_at,payload_json,created_at) VALUES(?,?,?,?,?)',
                       ('old_id', 2, agent.stamp(), '{}', agent.stamp()))
            db.commit()
        agent.load_config()
        self.assertEqual(len(agent.config['primaries']), 1)
        pid = agent.config['primaries'][0]['profile_id']
        self.assertEqual(agent.cache_stats(pid)['queued_results'], 1)
        self.assertEqual(agent.cache_stats(pid)['assigned_sites'], 1)
        self.assertTrue(agent.LEGACY_CACHE_FILE.exists())
        agent.load_config()
        self.assertEqual(agent.config['primaries'][0]['profile_id'], pid)
        self.assertEqual(agent.cache_stats(pid)['queued_results'], 1)

    def test_pause_repair_and_disconnect_isolated_from_other_primary(self):
        a = self.profile('MSP', 'https://msp.example.test', 'tlsw-agent-old')
        b = self.profile('Customer', 'https://customer.example.test', 'tlsw-agent-second')
        with agent.cache_db(a['profile_id']) as con:
            con.execute('INSERT INTO outbox(result_id,site_id,checked_at,payload_json,created_at) VALUES (?,?,?,?,?)',
                        ('r1', 10, agent.stamp(), '{}', agent.stamp()))
        hdr = {'Authorization': 'Basic '+base64.b64encode(b'admin:admin1234').decode(),
               'X-TLSWatch-Agent': '1'}
        with agent.app.test_client() as client:
            r=client.post('/api/primary/pause',json={'profile_id':a['profile_id'],'paused':True},headers=hdr)
            self.assertEqual(r.status_code,200,r.json)
            self.assertTrue(agent.is_paused(a['profile_id']))
            with patch.object(agent,'primary_call',return_value={'agent_id':99,'agent_name':'Wrong',
                       'agent_token':'tlsw-agent-other'}):
                r=client.post('/api/primary/repair',json={'profile_id':a['profile_id'],
                    'enrollment_code':'x'*60},headers=hdr)
                self.assertEqual(r.status_code,409)
                self.assertEqual(agent.profile_by_id(a['profile_id'])['token'],'tlsw-agent-old')
            with patch.object(agent,'primary_call',return_value={'agent_id':3,'agent_name':'MSP',
                       'agent_token':'tlsw-agent-new'}):
                r=client.post('/api/primary/repair',json={'profile_id':a['profile_id'],
                    'enrollment_code':'x'*60},headers=hdr)
                self.assertEqual(r.status_code,200,r.json)
            self.assertEqual(agent.cache_stats(a['profile_id'])['queued_results'],1)
            self.assertEqual(agent.profile_by_id(a['profile_id'])['token'],'tlsw-agent-new')
            self.assertEqual(client.post('/api/disconnect',json={'profile_id':a['profile_id']},
                headers=hdr).status_code,409)
            self.assertEqual(client.post('/api/disconnect',json={'profile_id':a['profile_id'],
                'force':True},headers=hdr).status_code,200)
            self.assertIsNone(agent.profile_by_id(a['profile_id']))
            self.assertEqual(agent.profile_by_id(b['profile_id'])['token'],'tlsw-agent-second')

    def test_api_pairing_and_ui_basic_auth(self):
        # Test the real Flask handlers with both new enrollment and authenticated management.
        with agent.app.test_client() as client:
            self.assertEqual(client.get('/api/state').status_code, 401)
            hdr = {'Authorization': 'Basic '+base64.b64encode(b'admin:admin1234').decode()}
            self.assertEqual(client.get('/api/state', headers=hdr).status_code, 200)
            self.assertEqual(client.post('/api/pair', json={}, headers=hdr).status_code, 403)
            hdr['X-TLSWatch-Agent'] = '1'
            def fake(settings, path, data):
                return {'agent_id': 11, 'agent_name': 'MSP', 'agent_token': 'tlsw-agent-secret'}
            with patch.object(agent, 'primary_call', side_effect=fake):
                body = {'primary_url': 'https://msp.example.test', 'enrollment_code': 'x'*60,
                        'allow_http': False, 'ca_pem': ''}
                response = client.post('/api/pair', json=body, headers=hdr)
                self.assertEqual(response.status_code, 200, response.get_json())
                # Duplicating the same primary fails without dropping the first profile.
                self.assertEqual(client.post('/api/pair', json=body, headers=hdr).status_code, 400)
            data = client.get('/api/state', headers=hdr).json
            self.assertEqual(len(data['primaries']), 1)
            self.assertNotIn('token', data['primaries'][0])
            pid = data['primaries'][0]['profile_id']
            response = client.post('/api/disconnect', json={'profile_id': pid}, headers=hdr)
            self.assertEqual(response.status_code, 200)
            self.assertEqual(len(client.get('/api/state', headers=hdr).json['primaries']), 0)


if __name__ == '__main__':
    unittest.main()
