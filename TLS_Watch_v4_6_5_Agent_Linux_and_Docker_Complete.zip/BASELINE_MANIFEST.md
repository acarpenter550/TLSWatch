# Baseline comparison

Source: `TLS_Watch_v4_6_3_Agent_Linux_and_Docker_Complete.zip`

SHA-256: `7f4fc69d19e8225527fb5b9842d1c81048ede2f1ce15178fcce2f9ad834f200e`

| File | Status |
|---|---|
| .dockerignore | Unchanged |
| .env.example | Updated |
| .gitignore | Unchanged |
| AGENT_API.md | Updated |
| DEFERRED.md | Added |
| DIAGNOSTICS.md | Unchanged |
| Dockerfile | Updated |
| FEATURE_GUIDE.md | Added |
| README.md | Updated |
| RELEASE_NOTES.md | Updated |
| REMOTE_UPGRADE_TEST.md | Added |
| UPGRADE.md | Added |
| VALIDATION.md | Updated |
| VERSION | Updated |
| agent.py | Updated |
| agent_operations.py | Added |
| compose.bridge.yaml | Unchanged |
| compose.yaml | Unchanged |
| diagnostics.py | Unchanged |
| install_linux.sh | Unchanged |
| install_user_service.sh | Unchanged |
| requirements-dev.txt | Added |
| requirements.txt | Unchanged |
| start_agent.sh | Updated |
| tests/test_accordion_ui.py | Unchanged |
| tests/test_agent.py | Unchanged |
| tests/test_cert_security.py | Unchanged |
| tests/test_diagnostics.py | Unchanged |
| tests/test_offline_cache.py | Unchanged |
| tlsprobe.py | Added |
| tools/sign_agent_release.py | Added |
| updates.py | Added |
