# Agent Diagnostics — v4.6.3

Open the agent Web UI using the existing administrator credentials and expand
**Agent Diagnostics**. Enter one DNS hostname or IP and a TCP port (default 443).
Select **Run diagnostics**. The panel stays open across dashboard refreshes.

The report shows DNS addresses, the selected address, TCP connectivity, TLS
handshake, negotiated protocol/cipher, certificate subject/issuer, serial number,
validity dates, days remaining, SANs, SHA-256 fingerprint, hostname verification,
and chain/trust verification. Every network stage reports elapsed milliseconds,
with an overall duration and actionable failure categories.

## Trust and identity

An observational handshake obtains the peer leaf certificate even when trust
validation would fail. This connection sends no HTTP or other application data.
A second handshake validates the server-provided chain using OpenSSL's system
trust store **plus the PEM certificates installed through the existing target
trust panel**. Primary-specific CA configuration and the admin HTTPS keypair are
not used as target trust anchors. No CA is downloaded automatically.

Hostname validation checks DNS/IP SANs independently of trust. It requires SANs,
accepts a wildcard only as the entire leftmost DNS label for one label, and does
not fall back to a common name. For an IP target, the certificate needs that IP
in an IP SAN. Expired/untrusted certificates remain inspectable, but do not pass.
Fingerprints must match between the inspection and verified connections for
overall success. A load balancer that changes certificates can cause a consistency
failure; rerun the test. Chain validation is OpenSSL path validation, not revocation
checking or a guarantee that the server sends every intermediate. The UI displays
leaf details, not a complete chain inventory. OCSP/CRL fetching is not performed.

## Destination policy and limits

- Private LAN and public targets are permitted by default. The first resolved
  address is tested; the other answers are shown, with no address fallback or scan.
- URLs, userinfo, paths, shell syntax, scoped IPv6 addresses and noncanonical
  numeric address spellings are rejected. Ports must be integers 1–65535.
- Loopback, link-local, multicast, unspecified, reserved addresses, common cloud
  metadata addresses and IPv6 transition forms are blocked. This applies even
  when a hostname is allowlisted. Mixed allowed/blocked DNS answers are rejected.
- Resolution happens once. Subsequent sockets connect directly to that snapshot,
  using the original hostname for SNI. No proxy environment settings are used.
- Optional `AGENT_DIAGNOSTICS_ALLOWLIST` accepts comma-separated exact hostnames,
  IPs or CIDRs. Example: `service.customer.lan,10.20.0.0/16,fd12:3456::/48`.
  Empty means the default policy above. Restart after changing the environment.
  An invalid nonempty list fails closed unless a valid entry matches. Use network
  egress controls for additional restrictions appropriate to your environment.
- At most two probes and two outstanding DNS lookups run concurrently. Busy
  probes return HTTP 429. Diagnostics have separate capacity from monitoring.
- Network stages have a 4-second maximum, within a 15-second network budget.
  Local trust loading, certificate processing and request overhead are additional.
  OS DNS lookups cannot be forcibly cancelled: a timed-out lookup retains its
  bounded resolver slot until the OS completes it, while the request returns.

## API and privacy

`POST /api/diagnostics` requires configured, nonempty administrator credentials
with HTTP Basic authentication, JSON and `X-TLSWatch-Agent: 1`. Existing same-origin
checks apply. It fails closed if UI authentication has been disabled. There is no
diagnostic endpoint authenticated by a primary enrollment token.

Request: `{"host":"service.customer.lan","port":443}`.
HTTP 200 contains `success`, `steps`, timings and available public certificate
details, including when an actual probe fails. HTTP 400 indicates invalid input,
401 missing/disabled authentication, 403 origin/header rejection, 429 capacity
exhaustion and 503 unreadable local trust. Responses are not cached on success.

Results stay in the current page; diagnostics do not write configuration, queue
results, enroll primaries or upload to them. Error responses omit private keys,
pairing tokens, environment values and local paths. Target hostnames, IPs and
public certificate identity are intentionally visible to the administrator.
The UI writes result text with `textContent` to prevent certificate-text HTML
injection. Continue using your existing HTTPS/LAN credential practices.

## Tests

After installing `requirements.txt`, run:

```bash
python -m unittest discover -s tests -v
```

The suite needs no Internet. TLS fixtures create temporary keys/certificates and
local sockets. Only those fixtures bypass the loopback policy to exercise actual
TLS handshakes; production destination validation remains enabled.
