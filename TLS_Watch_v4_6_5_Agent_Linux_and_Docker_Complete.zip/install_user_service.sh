#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "$(readlink -f -- "$0")")" && pwd)"
if ! command -v systemctl >/dev/null 2>&1; then
  echo 'systemctl not available; use ./start_agent.sh instead.' >&2
  exit 1
fi
if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
  echo 'Install dependencies first: ./install_linux.sh' >&2
  exit 1
fi
mkdir -p "$HOME/.config/systemd/user"
SERVICE="$HOME/.config/systemd/user/tlswatch-agent.service"
cat > "$SERVICE" <<UNIT
[Unit]
Description=TLS Watch Remote Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$ROOT
ExecStart=$ROOT/start_agent.sh
Restart=always
RestartSec=10
NoNewPrivileges=true
UMask=0077

[Install]
WantedBy=default.target
UNIT
systemctl --user daemon-reload
systemctl --user enable --now tlswatch-agent.service
printf 'Agent service installed. View logs: journalctl --user -u tlswatch-agent -f\n'
printf 'For background startup without an active login, ask an administrator to run: sudo loginctl enable-linger %s\n' "$USER"
