# Upgrade to Primary and Agent v4.6.5

## Before replacing files

Stop both services. Back up each complete persistent data directory and the
environment/credential configuration while stopped. For a primary database outside
the application, preserve the configured `DB_PATH`. Keeping the SQLite database
with its WAL/SHM while stopped is safe; a SQLite backup also works. Keep native
virtual environments unless you intend to recreate them.

This is an application-only update. No pairing codes or primary registrations
need to be recreated. Migrations add tables/columns in place and run idempotently.
For rollback, restore the stopped-service backup, not just the old source files.

## Primary v4.6 → v4.6.5

Replace application files using `primary/`, including `operations.py`,
`release_routes.py`, `tlsprobe.py`, `updates.py` and all static files. Keep your
actual credentials and data; do not replace `.env` with `.env.example`.

Refresh dependencies with your existing environment:

```bash
.venv/bin/python -m pip install -r requirements.txt
./start_tls_watch.sh
```

Windows: use `.venv\Scripts\python.exe -m pip install -r requirements.txt`, then
your existing `START_TLS_WATCH.bat` or service. The Windows launcher uses service/
shell environment variables; it does not source `.env`. The Linux launcher now
loads an optional administrator-controlled `.env` before applying defaults.

Set `SMTP_PASSWORD` in the primary service environment when SMTP authentication
is needed. Configure the remaining email fields through the dashboard. Configure
`UPDATE_PUBLIC_KEY` only if using signed agent releases. These are public-key/
service settings, independent of the existing admin password and webhook keys.

Optional new primary Docker deployment: copy `.env.example` to `.env`, supply your
existing credentials, then `docker compose up -d --build`. Existing native data is
not automatically migrated to a new Docker volume; continue using your current
deployment unless intentionally moving it.

## Agent v4.6.2/v4.6.3 → v4.6.5 (one-time manual bootstrap)

Replace application files using `agent/`. Keep `.env`, `data/` or the entire Docker
volume. Include the new `agent_operations.py`, `tlsprobe.py`, `updates.py`, `VERSION`
and updated `start_agent.sh`; the launcher implements native update restarts.

```bash
.venv/bin/python -m pip install -r requirements.txt
chmod +x start_agent.sh install_linux.sh install_user_service.sh
./start_agent.sh
```

The native service should run **start_agent.sh**, not `python agent.py` directly,
for remote install/restart support. Existing generated user services already use
the launcher. Direct Python launches remain valid for monitoring/staging, but are
not a supported remote-install deployment.

Docker: retain the same Compose project directory/name and volume, then run
`docker compose up -d --build` (or your existing `-f compose.bridge.yaml` option).
Do not run `down -v`. Docker installs use rebuilt images; remote code replacement
inside a running container is intentionally blocked.

Existing LAN bind/port, multi-primary enrollments, offline queues, installed PEM
trust and admin HTTPS settings are retained. Configure non-24-hour policies after
the assigned agent is v4.6.5; older agents ignore the new interval field. New agents
can still communicate with Primary v4.6, using the default 24-hour interval when no
policy field is provided.

The first resumed native/agent check establishes a new fixed interval schedule.
Manually queued checks still run immediately. Suppression affects notification
delivery only; it does not pause scheduled checks or hide Needs Attention.
