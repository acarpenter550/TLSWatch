# v4.6.5 feature guide

## Monitoring policies

Use the Website policy form to choose 1, 6, 12 or 24 hours and an expiration
warning of 1–365 days. Profiles reuse these settings and a notification-enable
flag. Editing a profile updates linked sites and makes their next check due;
deleting a profile retains sites' effective settings. Assigning a custom policy
detaches that site from its prior profile. Manual checks remain immediate.
Schedules are fixed intervals from observation time; the old random-calendar-day
helper remains only for legacy paths. Staleness warning/critical thresholds follow
one/two configured intervals. Browser dates use browser local time; API timestamps
are UTC. Existing 30/60/90 expiration bands remain, while the profile threshold
controls Needs Attention and the new profile warning notification.

## Chain details

The saved certificate dialog shows leaf fields plus negotiated protocol/cipher,
the server-presented chain and OpenSSL's verified path (which can include a local
root). Each chain certificate has identity, issuer, dates and SHA-256 fingerprint.
Dates and the trust result are observations at check time. Expired/not-yet-valid
certificates are flagged. Missing intermediates can be identified against a
successful verified path; when verification fails, its reason is shown instead
of inventing a missing root/intermediate. Servers normally omit the root.

Agents validate with system plus installed target PEM trust. The primary uses its
system trust. Primary-specific connection CA settings and admin HTTPS keypairs
remain separate. Trust results are monitoring-location reports, not revalidation
by the primary's trust store. Agent chain PEMs are reparsed by the primary so it
does not trust supplied identity/date labels. Chain data is saved with successful
historical checks, including delayed offline observations; failed checks do not
invent a new chain. Protocol/cipher and agent trust assertions are agent-reported.

Full capture uses the public Python chain API when available, or the CPython
_ssl equivalent on Python 3.10–3.12. Unsupported runtimes report leaf-only capture.
Chains are capped at 10 certificates and details at 200 KB. No OCSP/CRL fetching,
active protocol/cipher scanning or multi-location consistency feature is included.

## Notifications and maintenance

Acknowledgment suppresses repeat notifications for an incident and clears when
the site recovers. Snooze ends at an explicit time. Maintenance windows target
the selected site or all sites. Monitoring, history and Needs Attention continue.
Suppression is checked both at event creation and at delivery. Deferred active
incidents get one catch-up Needs Attention event after suppression ends. Healthy
sites do not generate stale catch-up warnings. Delivery is at-least-once: a crash
after SMTP/webhook acceptance but before the local delivered marker can duplicate
a notification, as with typical retry queues.

SMTP configuration is in the dashboard; its password comes from `SMTP_PASSWORD`
in the service environment. TLS/STARTTLS certificate verification is mandatory.
Email starts disabled and supports at most 25 recipients. Up to three delivery
attempts use bounded socket waits; failures are redacted. A test message is queued
through the same path. Existing webhook routing/events remain supported. Custom
profile warnings are supported as `profile_expiration_warning` in the event API;
existing webhook subscriptions are not silently expanded.

## Retention, queues and health

Default primary retention: 365 days of checks/certificate versions, 1,000 checks
per site, 365 days of audit, 30 days of completed deliveries. Cleanup is hourly;
per-site count pruning also runs on each check. The current saved certificate and
pending/sending deliveries are preserved. Replay receipts are kept to preserve
idempotency for agents whose pending results have no age-based expiry. These
receipt IDs are deliberately outside history retention. SQLite may retain freed
pages for reuse; retention does not promise immediate shrinking of database files.

Each agent primary queue defaults to 10,000 rows/50,000,000 payload bytes, configured
by `AGENT_QUEUE_MAX_RESULTS` / `AGENT_QUEUE_MAX_BYTES` in the agent environment.
Capacity includes pending and rejected entries. A small result reserve avoids
starting probes when insufficient capacity remains. Full queues pause new checks;
upload/retry continues, and unsent results are never deleted for age/space. Rejected
results are removed after `AGENT_REJECTED_RETENTION_DAYS` (default 30). Limits cover
queued JSON payload, not SQLite file/WAL, inventory, update backups or the whole
filesystem; monitor disk free space. Increasing a limit or draining the queue
automatically resumes checks. Existing queues above a new cap are preserved.

Health includes Linux `/proc` CPU utilization between samples, available/total
memory, free data-filesystem disk space, queue age and queue-limit state. CPU is
unavailable until a second sample. Missing/unsupported metrics are omitted, never
reported as zero. `/proc` values can describe the host rather than container quota
limits. Only this small public metric schema crosses to primaries; no environment,
process arguments, tokens, keys or filesystem paths are reported.

## Audit and API

Successful administrator POST/PUT/PATCH/DELETE operations are logged with actor,
time, method, route and response status. Bodies, headers, query strings, notes,
passwords and tokens are not copied into audit. The log is operational evidence,
not a cryptographically tamper-proof store; it has configurable retention.

New admin endpoints require the existing admin authorization, same-origin checks,
JSON objects for writes and `X-TLSWatch-Admin: 1`:

- `GET /api/operations`: profiles, alert controls, maintenance, SMTP status, retention, recent audit/mail/health.
- `POST /api/operations/profiles`, `PUT/DELETE /api/operations/profiles/<id>`.
- `PUT /api/operations/sites/<id>/policy` and `/alert`.
- `POST /api/operations/maintenance`, `DELETE /api/operations/maintenance/<id>`.
- `PUT /api/operations/smtp`, `POST /api/operations/smtp/test`.
- `PUT /api/operations/retention`.
- `GET/POST /api/operations/releases`, `POST /api/operations/agents/<id>/update`.

Agent sync adds optional interval, health and update fields to the existing v1
protocol. `POST /agent/v1/update` uses the existing enrollment bearer and a scoped
command ID. No public API key authorizes updates or other admin writes.
