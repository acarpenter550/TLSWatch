# Saved for later

The unselected recommendations remain deferred:

- 5: Multiple monitoring locations per website.
- 6: Certificate consistency comparisons across agents.
- 8: Full configuration backup/restore UI (existing inventory export remains).
- 11: Certificate discovery/scanning.
- 13: Mandatory first-run password change, session authentication and primary admin HTTPS management.

These are not part of v4.6.5. Existing agent HTTPS and configuration remain intact.
