# TLS Watch v4.6.5 validation — October 25, 2026

## Executed successfully

- **76 primary/integration pytest tests passed** (Python 3.12, Windows, Flask 3.1.3,
  cryptography 47.0.0). Includes 46 existing primary tests and 30 new checks.
- **31 agent unittest tests passed**, retaining the earlier diagnostics, pairing,
  multi-primary isolation, offline replay, trust and admin HTTPS regressions.
- Four existing Node regression suites passed: agent filter, dashboard statistics,
  group filters, group-modal search/selection. App and operations JavaScript and
  exact inline agent UI script syntax checks passed.
- Actual local HTTP listener: urllib transport, bearer authorization, sync, durable
  result upload and primary ingestion, using both real applications.
- Actual local TLS listeners: complete root/intermediate/leaf path, missing and
  expired intermediate failures, unknown CA, hostname mismatch, IP SAN, wildcards,
  expiry and negotiated protocol/cipher.
- Cross-application checks: offline policy persistence/change, outage/replay,
  certificate changes, receipts/deduplication, two-primary queue isolation, queue
  row/byte caps, health validation and optional legacy protocol fields.
- Update checks: signed registry upload, scoped authorized download, staging,
  native installer file replacement with configuration preservation, status ACK,
  per-primary independent status, opt-in/Docker blocks, tampered signatures,
  downgrade/path traversal rejection and rollback after an injected write error.
- Policies/profiles, alert suppression/recovery/catch-up, SMTP TLS calls/retries/
  redaction, retention, audit and legacy-schema idempotent migration tests passed.
- Browser smoke test: expanded operations rollup, changed the sample website to a
  one-hour policy, saved it and verified the persisted human-readable summary.
  Screenshot: Dashboard_Verification.png in the complete release.
- Source parse checks, ZIP CRC/source-byte checks, exclusion of local data/secrets,
  executable Unix script modes and full shipped-agent ZIP signing/verification
  were checked at release packaging.

## Test repairs

The v4.6.2 accordion source-extraction test was repaired in v4.6.3. A baseline
primary reassignment test was isolated from the newly scheduled local probe;
otherwise it raced the legitimate local check while asserting rejection of the
old agent. Runtime reassignment behavior was retained.

## Limits of this validation

The run used Windows/Python 3.12. Docker is unavailable here: no image build,
container launch or Docker deployment was executed. No real Linux/systemd service
restart or process-level native upgrade was executed; installer file replacement,
rollback and launcher policy were tested in isolated directories. The actual
restart/launcher behavior still needs your deployment test. SMTP transport was
mocked at the SMTP interface; no external SMTP account received a message. The
browser smoke test covers the website-policy flow, not every administrative form.
Some multi-primary integration tests bridge Flask requests in process; actual
network HTTP transport was independently exercised against a local primary.

No production system or user credentials were changed. Private test keys are
ephemeral and excluded from all delivered artifacts.

## Reproduce

From the complete release, install `primary/requirements-dev.txt` into a test
environment, then run from primary/: `python -m pytest -q`. Keep primary/ and
agent/ as siblings for the cross-application suite. Standalone primary testing
skips cross-application tests when the sibling agent source is absent.
From agent/: `python -m unittest discover -s tests -v`.
Run each `primary/tests/*.cjs` with Node for the JavaScript regression checks.
