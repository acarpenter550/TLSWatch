"""Signed agent release verification and rollback-capable native installation."""
from __future__ import annotations
import argparse
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import zipfile
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

MAX_ARCHIVE=1_500_000
RUNTIME={'agent.py','diagnostics.py','tlsprobe.py','agent_operations.py','updates.py',
         'VERSION','requirements.txt','start_agent.sh','install_linux.sh','install_user_service.sh',
         'Dockerfile','compose.yaml','compose.bridge.yaml','.env.example','.dockerignore','.gitignore'}


def version_tuple(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{1,3}\.\d{1,3}\.\d{1,3}',value): raise ValueError('Invalid release version')
    return tuple(map(int,value.split('.')))


def signed_bytes(manifest):
    return json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()


def verify(package, public_key, current='0.0.0'):
    if not public_key: raise ValueError('Configure a pinned Ed25519 update public key first')
    if not isinstance(package,dict) or set(package)!={'manifest','signature','archive'}: raise ValueError('Invalid signed release package')
    manifest=package['manifest']
    if not isinstance(manifest,dict) or set(manifest)!={'version','sha256','size','component'} or manifest['component']!='agent': raise ValueError('Invalid agent manifest')
    if version_tuple(manifest['version'])<version_tuple(current): raise ValueError('Downgrades are blocked')
    if type(manifest['size']) is not int or not 1<=manifest['size']<=MAX_ARCHIVE: raise ValueError('Invalid archive size')
    if not isinstance(package['archive'],str) or len(package['archive'])>MAX_ARCHIVE*4//3+8: raise ValueError('Archive too large')
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key,validate=True)).verify(
            base64.b64decode(package['signature'],validate=True),signed_bytes(manifest))
        archive=base64.b64decode(package['archive'],validate=True)
    except Exception: raise ValueError('Update signature or encoding is invalid') from None
    if len(archive)!=manifest['size'] or hashlib.sha256(archive).hexdigest()!=manifest['sha256']: raise ValueError('Archive checksum/size mismatch')
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        entries=z.infolist()
        names=[i.filename for i in entries]
        if len(names)!=len(set(names)) or len(names)>200 or sum(i.file_size for i in entries)>8_000_000: raise ValueError('Invalid archive contents')
        for entry in entries:
            name=entry.filename
            if entry.is_dir(): continue
            if ('\\' in name or name.startswith('/') or '..' in Path(name).parts or
                (entry.external_attr>>16)&0o170000==0o120000 or entry.file_size>500_000): raise ValueError('Unsafe archive path/type/size')
            if name not in RUNTIME and name not in ('requirements-dev.txt','tools/sign_agent_release.py') and not (name.startswith('tests/') and name.endswith(('.py','.cjs'))) and not (len(Path(name).parts)==1 and name.endswith('.md')):
                raise ValueError('Unexpected release file: '+name[:80])
        required={'agent.py','diagnostics.py','tlsprobe.py','agent_operations.py','updates.py','VERSION','requirements.txt','start_agent.sh'}
        if not required<=set(names): raise ValueError('Release is missing runtime files')
        if z.read('VERSION').decode().strip()!=manifest['version']: raise ValueError('Archive version differs from signed manifest')
        # v4.6.5 cannot safely change dependencies while running; install new
        # dependencies manually before applying a future incompatible release.
        import ast
        for name in names:
            if name.endswith('.py'): ast.parse(z.read(name).decode('utf-8'))
    return archive


def atomic_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp')
    temp.write_text(json.dumps(value),encoding='utf-8')
    os.chmod(temp,0o600)
    temp.replace(path)


def apply_pending(root,data,public_key):
    marker=data/'pending_update.json'
    if not marker.exists(): return False
    package=json.loads(marker.read_text())
    current=(root/'VERSION').read_text().strip()
    archive=verify(package,public_key,current)
    release=package['manifest']['version']
    # Rollback files cover every replacement. Configuration and queues are never copied.
    backup=data/('update_backup_'+release.replace('.','_'))
    backup.mkdir(parents=True,exist_ok=True)
    os.chmod(backup,0o700)
    changed=[]
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        try:
            for name in sorted(RUNTIME.intersection(z.namelist())):
                target=root/name
                # Explicit root-only names; reject pre-existing symlink targets.
                if target.is_symlink(): raise ValueError('Refusing symbolic-link runtime file')
                existed=target.exists()
                if existed: shutil.copy2(target,backup/name)
                changed.append((name,existed))
                temporary=root/(name+'.update-tmp')
                temporary.write_bytes(z.read(name))
                os.chmod(temporary,0o755 if name.endswith('.sh') else 0o644)
                temporary.replace(target)
        except BaseException:
            for name,existed in reversed(changed):
                target=root/name
                if existed: shutil.copy2(backup/name,target)
                else: target.unlink(missing_ok=True)
            raise
    marker.unlink()
    try: previous=json.loads((data/'agent_update.json').read_text())
    except (OSError,ValueError): previous={}
    state={'status':'installed','version':release,'command_id':previous.get('command_id'),'profile_id':previous.get('profile_id')}
    atomic_json(data/'agent_update.json',state)
    pid=previous.get('profile_id')
    if isinstance(pid,str) and re.fullmatch('[a-f0-9]{32}',pid): atomic_json(data/('update_status_'+pid+'.json'),state)
    return True


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--apply-pending',action='store_true',required=True)
    parser.parse_args()
    root=Path(__file__).resolve().parent
    data=Path(os.environ.get('AGENT_DATA_DIR',str(root/'data')))
    try:
        apply_pending(root,data,os.environ.get('AGENT_UPDATE_PUBLIC_KEY',''))
    except Exception:
        # Roll back replacement failures, quarantine the request, then run the old
        # agent so it can report the failure instead of entering a restart loop.
        marker=data/'pending_update.json'
        if marker.exists(): marker.replace(data/'failed_update.json')
        try: previous=json.loads((data/'agent_update.json').read_text())
        except (OSError,ValueError): previous={}
        state={'status':'failed','command_id':previous.get('command_id'),'profile_id':previous.get('profile_id'),
               'message':'Update installation failed; previous runtime retained'}
        atomic_json(data/'agent_update.json',state)
        pid=previous.get('profile_id')
        if isinstance(pid,str) and re.fullmatch('[a-f0-9]{32}',pid): atomic_json(data/('update_status_'+pid+'.json'),state)
        print('TLS Watch: update failed; starting the retained agent runtime',flush=True)
