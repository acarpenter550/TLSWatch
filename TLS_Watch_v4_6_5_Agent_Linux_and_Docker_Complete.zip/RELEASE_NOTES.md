# TLS Watch v4.6.5 — October 25, 2026

Primary and agent both increment to 4.6.5. This release adds the selected monitoring,
alerting and operational features listed in FEATURE_GUIDE.md. Existing primary
protocol, multi-primary agents, durable offline sync, pairing, agent Diagnostics,
installed PEMs, admin HTTPS and LAN configuration are retained.

New migrations are additive and idempotent. Back up data/config while stopped.
Default checks are 24-hour intervals; email is disabled; remote native installs
require a pinned publisher key, administrator command and local opt-in. Docker
supports signed staging and requires image rebuild to apply software changes.

The package includes tests and a signing tool in the complete bundle. See
VALIDATION.md for executed checks and deployment limitations. UPGRADE.md and
REMOTE_UPGRADE_TEST.md cover the one-time agent bootstrap and same-version 4.6.5
remote reinstall test. Private keys and existing user data are not bundled.
