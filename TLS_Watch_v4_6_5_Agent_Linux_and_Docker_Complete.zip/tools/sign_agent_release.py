"""Offline signing utility. Keep the private key outside distributed releases."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import zipfile
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


def write_new(path,content,mode=0o600):
    # Exclusive create prevents accidental replacement of a publisher key/release.
    with open(path,'xb') as stream: stream.write(content)
    os.chmod(path,mode)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    keygen=sub.add_parser('keygen');keygen.add_argument('--private-key',required=True);keygen.add_argument('--public-key',required=True)
    sign=sub.add_parser('sign');sign.add_argument('--private-key',required=True);sign.add_argument('--zip',required=True);sign.add_argument('--out',required=True)
    args=parser.parse_args()
    if args.command=='keygen':
        key=Ed25519PrivateKey.generate()
        raw=key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
        public=base64.b64encode(key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw))+b'\n'
        write_new(args.private_key,raw)
        write_new(args.public_key,public,0o644)
        print('Publisher keypair created. Protect the private key; configure only the public key on servers/agents.')
    else:
        key=serialization.load_pem_private_key(Path(args.private_key).read_bytes(),password=None)
        if not isinstance(key,Ed25519PrivateKey): raise SystemExit('An Ed25519 private key is required')
        archive=Path(args.zip).read_bytes()
        if len(archive)>1_500_000: raise SystemExit('Agent archive exceeds release size limit')
        with zipfile.ZipFile(args.zip) as z: version=z.read('VERSION').decode().strip()
        manifest={'version':version,'component':'agent','size':len(archive),'sha256':hashlib.sha256(archive).hexdigest()}
        message=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()
        package={'manifest':manifest,'signature':base64.b64encode(key.sign(message)).decode(),'archive':base64.b64encode(archive).decode()}
        write_new(args.out,json.dumps(package,separators=(',',':')).encode())
        print('Signed agent release written: '+args.out)


if __name__=='__main__': main()
