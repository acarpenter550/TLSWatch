#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$(readlink -f -- "$0")")"
umask 077
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Python 3.10 or newer is required.' >&2
  exit 1
fi
python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    sys.exit('Python 3.10 or newer is required')
PY
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
if [[ ! -e .env ]]; then
  cp .env.example .env
fi
chmod 600 .env
mkdir -p data
chmod 700 data
printf '\nInstalled. Edit .env if needed, then run ./start_agent.sh\n'
