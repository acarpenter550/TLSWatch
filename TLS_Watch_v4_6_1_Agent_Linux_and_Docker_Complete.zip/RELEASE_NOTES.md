# TLS Watch v4.6 — agent-only release

- Add independent connections to multiple v4.5 primary servers (up to 32).
- Web UI to enroll multiple primaries and inspect individual connectivity / queue metrics.
- Retain independent offline schedules and SQLite result queues for each primary.
- Group same-target checks due together so one handshake can feed independent queues.
- Automatically migrate existing v4.5 single-primary pairing and SQLite cache in place.
- Keep native Linux and Docker deployment options and host network mode.
- Keep LAN UI defaults on new installs; basic username `admin`, password `admin1234` (CHANGE IMMEDIATELY).
- No changes to primary; a future primary change can be released separately as v4.6.

Status: Python syntax / UI JavaScript checks and isolated core unit tests passed in the build environment. Flask/Docker runtime and two-primary live integration not executed in this environment. Test with two non-production primaries before production rollout.

## v4.6.1 (agent only)

- Connected primary controls: Pause/Resume, Re-pair using a new code for the *same agent record*, Retry, Disconnect with undelivered-results safety check.
- Admin Web UI can install/list/delete per-agent trusted target CA or self-signed X.509 PEM certificates. Verified TLS checks now use these trust anchors without relaxing hostname validation.
- Admin Web UI supports uploading a PEM certificate chain + matching private key, then enabling HTTPS on next restart; supports disabling HTTPS and deleting the keypair.
- Docker and native Linux use the same implementation and persistent `/data` or `data/` storage; primary protocol remains compatible with TLS Watch primary v4.5/v4.6.
