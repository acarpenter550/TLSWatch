"""TLS Watch Remote Agent 4.6.3: multi-primary, independently durable certificate monitoring.

Each enrolled primary owns its own token, assignment cache, and result outbox.
All remote communication is initiated by this agent. The primary 4.5 protocol
(/agent/v1/enroll, /sync, /results/batch) is unchanged.
"""
from __future__ import annotations

import hmac
import diagnostics
import hashlib
import re
import json
import os
import secrets
import socket
import sqlite3
import ssl
import threading
import time
import urllib.error
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager, closing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from flask import Flask, jsonify, render_template_string, request

VERSION = "4.6.3"
DATA_DIR = Path(os.environ.get("AGENT_DATA_DIR", str(Path(__file__).resolve().parent / "data")))
CONFIG_FILE = DATA_DIR / "agent.json"  # v4.5 legacy is auto-migrated
LEGACY_CACHE_FILE = DATA_DIR / "agent_cache.sqlite3"
PORT = int(os.environ.get("AGENT_UI_PORT", "8899"))
UI_BIND = os.environ.get("AGENT_UI_BIND", "0.0.0.0").strip()
UI_USERNAME = os.environ.get("AGENT_UI_USERNAME", "admin").strip()
UI_PASSWORD = os.environ.get("AGENT_UI_PASSWORD", "admin1234")
POLL_SECONDS = max(5, min(60, int(os.environ.get("POLL_SECONDS", "15"))))
TLS_TIMEOUT = max(3, min(30, int(os.environ.get("TLS_TIMEOUT_SECONDS", "8"))))
WORKERS = max(1, min(8, int(os.environ.get("AGENT_WORKERS", "3"))))
MAX_PRIMARIES = 32
TRUST_DIR = DATA_DIR / "trusted_targets"
TRUST_INDEX = TRUST_DIR / "index.json"
UI_TLS_CONFIG = DATA_DIR / "ui_tls.json"
UI_TLS_CERT = DATA_DIR / "ui_server_cert.pem"
UI_TLS_KEY = DATA_DIR / "ui_server_key.pem"

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200_000
lock = threading.RLock()
config: dict = {"schema_version": 2, "primaries": []}
primary_states: dict[str, dict] = {}
local_inflight: set[tuple[str, int]] = set()
syncing: set[str] = set()
next_polls: dict[str, float] = {}
check_pool = ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix="tls-check")
network_pool = ThreadPoolExecutor(max_workers=10, thread_name_prefix="tls-primary")
stop_event = threading.Event()


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def profile_id() -> str:
    return uuid.uuid4().hex


def cache_path(pid: str) -> Path:
    if not isinstance(pid, str) or len(pid) != 32 or any(c not in "0123456789abcdef" for c in pid):
        raise ValueError("Invalid primary profile ID")
    return DATA_DIR / ("primary_" + pid + ".sqlite3")


def atomic_config(new: dict) -> None:
    """On-disk config is replaced atomically; avoids partial credentials after crashes."""
    global config
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = CONFIG_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(new, indent=2), encoding="utf-8")
    os.chmod(temp, 0o600)
    temp.replace(CONFIG_FILE)
    config = new


def load_config() -> None:
    """Upgrade a paired v4.5 agent in place without losing its offline queue."""
    global config
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(DATA_DIR, 0o700)
    if not CONFIG_FILE.exists():
        config = {"schema_version": 2, "primaries": []}
        return
    raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("Invalid agent configuration")
    if raw.get("schema_version") == 2 and isinstance(raw.get("primaries"), list):
        checked = set()
        for item in raw["primaries"]:
            pid = item.get("profile_id")
            cache_path(pid)
            if pid in checked or not item.get("token") or not item.get("primary_url"):
                raise ValueError("Invalid or duplicate primary profile")
            checked.add(pid)
        config = raw
    elif raw.get("token") and raw.get("primary_url"):
        pid = profile_id()
        new = {"schema_version": 2, "primaries": [{**raw, "profile_id": pid}]}
        # SQLite backup() captures any committed WAL changes, including queued results.
        # Original files are retained for rollback; v4.5 may be stopped before upgrade.
        if LEGACY_CACHE_FILE.exists():
            dest = cache_path(pid)
            with closing(sqlite3.connect(LEGACY_CACHE_FILE, timeout=30)) as src, closing(sqlite3.connect(dest, timeout=30)) as out:
                src.backup(out)
                out.commit()
            os.chmod(dest, 0o600)
        else:
            init_cache(pid)
        atomic_config(new)
    else:
        # An unpaired v4.5 installation can upgrade without enrollment.
        atomic_config({"schema_version": 2, "primaries": []})
    for profile in config["primaries"]:
        init_cache(profile["profile_id"])
        primary_states.setdefault(profile["profile_id"], default_state())


def default_state() -> dict:
    return {"last_contact": None, "last_sync": None, "last_error": None,
            "last_result": None, "checks": 0, "running": 0,
            "timezone": "America/New_York"}


def profiles() -> list[dict]:
    with lock:
        return [dict(p) for p in config["primaries"]]


def profile_by_id(pid: str) -> dict | None:
    with lock:
        return next((dict(p) for p in config["primaries"] if p["profile_id"] == pid), None)


def still_active(settings: dict) -> bool:
    current = profile_by_id(settings["profile_id"])
    return current is not None and hmac.compare_digest(current["token"], settings["token"])


def is_paused(pid: str) -> bool:
    with lock:
        return next((bool(p.get("paused", False)) for p in config["primaries"]
                     if p["profile_id"] == pid), True)


def require_profile(pid: str) -> dict | None:
    cache_path(pid)  # Validate path component even if not found.
    return profile_by_id(pid)


def primary_url(raw: str, allow_http: bool) -> str:
    value = raw.strip().rstrip("/")
    parsed = urlsplit(value)
    if (parsed.scheme != "https" and not (parsed.scheme == "http" and allow_http)) or not parsed.hostname:
        raise ValueError("Use HTTPS, or explicitly allow HTTP on a trusted network")
    if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ("", "/"):
        raise ValueError("Primary URL must contain only the scheme, hostname and optional port")
    if parsed.port is not None and not 1 <= parsed.port <= 65535:
        raise ValueError("Invalid primary port")
    return value


def make_context(settings: dict) -> ssl.SSLContext:
    context = ssl.create_default_context()
    if settings.get("ca_pem"):
        context.load_verify_locations(cadata=settings["ca_pem"])
    return context


class RejectRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError("Primary redirected request; refusing to forward agent credentials")


def primary_call(settings: dict, path: str, data: dict) -> dict:
    payload = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(settings["primary_url"] + path, payload,
            {"Content-Type": "application/json", "User-Agent": "TLSWatch-Agent/4.6.3"}, method="POST")
    if path != "/agent/v1/enroll":
        req.add_header("Authorization", "Bearer " + settings["token"])
    try:
        opener = urllib.request.build_opener(RejectRedirect(), urllib.request.HTTPSHandler(context=make_context(settings)))
        with opener.open(req, timeout=18) as response:
            limit = 8_000_000 if path == "/agent/v1/sync" else 200_000
            raw = response.read(limit + 1)
            if len(raw) > limit:
                raise ValueError("Primary response exceeded size limit")
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise ValueError("Primary response must be a JSON object")
            return result
    except urllib.error.HTTPError as exc:
        error = exc.read(2000).decode("utf-8", "replace")
        raise RuntimeError(f"Primary returned HTTP {exc.code}: {error[:400]}") from exc


def checked_pem(pem: str) -> tuple[str, str]:
    """Validate one plain X.509 PEM cert and return normalized PEM and SHA-256 fingerprint."""
    if not isinstance(pem, str) or len(pem.encode("utf-8")) > 20_000:
        raise ValueError("PEM certificate must be a text file smaller than 20 KB")
    match = re.fullmatch(r"\s*(-----BEGIN CERTIFICATE-----\s+[A-Za-z0-9+/=\s]+-----END CERTIFICATE-----)\s*", pem)
    if not match:
        raise ValueError("Upload one X.509 PEM certificate (not a bundle or private key)")
    normalized = match.group(1).strip() + "\n"
    der = ssl.PEM_cert_to_DER_cert(normalized)
    if len(der) > 15_000:
        raise ValueError("Certificate is unexpectedly large")
    context = ssl.create_default_context()
    context.load_verify_locations(cadata=normalized)
    return normalized, hashlib.sha256(der).hexdigest()


def trust_index() -> dict:
    if not TRUST_INDEX.exists():
        return {}
    result = json.loads(TRUST_INDEX.read_text(encoding="utf-8"))
    if not isinstance(result, dict):
        raise ValueError("Invalid local trust index")
    return result


def trust_entries() -> list[dict]:
    with lock:
        values = trust_index()
    return [{"fingerprint": fp, "label": row.get("label", "Certificate")}
            for fp, row in sorted(values.items(), key=lambda p: p[1].get("label", "").lower())]


def save_trust_index(index: dict) -> None:
    TRUST_DIR.mkdir(parents=True, exist_ok=True)
    path = TRUST_INDEX.with_suffix(".tmp")
    path.write_text(json.dumps(index, indent=2), encoding="utf-8")
    os.chmod(path, 0o600)
    path.replace(TRUST_INDEX)


def local_trust_bundle() -> str:
    with lock:
        items = trust_index()
        pem_parts = []
        for fingerprint in items:
            if not re.fullmatch(r"[0-9a-f]{64}", fingerprint):
                raise ValueError("Invalid fingerprint in trust store")
            path = TRUST_DIR / (fingerprint + ".pem")
            pem_parts.append(path.read_text(encoding="utf-8"))
    return "\n".join(pem_parts)


def tls_ui_config() -> dict:
    if not UI_TLS_CONFIG.exists():
        return {"enabled": False}
    data = json.loads(UI_TLS_CONFIG.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or type(data.get("enabled")) is not bool:
        raise ValueError("Invalid HTTPS admin UI settings")
    return data


def set_tls_ui_config(enabled: bool) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = UI_TLS_CONFIG.with_suffix(".tmp")
    temp.write_text(json.dumps({"enabled": enabled}, indent=2), encoding="utf-8")
    os.chmod(temp, 0o600)
    temp.replace(UI_TLS_CONFIG)


def validate_server_pair(cert_file: Path, key_file: Path) -> None:
    tls_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    tls_context.load_cert_chain(certfile=str(cert_file), keyfile=str(key_file))


def ui_tls_state(running_secure: bool) -> dict:
    settings = tls_ui_config()
    installed = UI_TLS_CERT.is_file() and UI_TLS_KEY.is_file()
    return {"installed": installed, "enabled_on_next_start": settings["enabled"],
            "currently_https": running_secure,
            "restart_required": running_secure != settings["enabled"]}


def tls_handshake(host: str, dest: tuple, verify: bool):
    family, address = dest
    ctx = ssl.create_default_context() if verify else ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    if verify:
        bundle = local_trust_bundle()
        if bundle:
            ctx.load_verify_locations(cadata=bundle)
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    with socket.socket(family, socket.SOCK_STREAM) as sock:
        sock.settimeout(TLS_TIMEOUT)
        sock.connect(address)
        with ctx.wrap_socket(sock, server_hostname=host) as channel:
            return None if verify else channel.getpeercert(binary_form=True)


def check_certificate(host: str, port: int) -> dict:
    # Resolve/connect from the remote agent's LAN. No HTTP request or page download.
    addresses = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    if not addresses:
        raise OSError("Hostname has no resolved addresses")
    last_error = None
    der, chosen = None, None
    for family, _, _, _, sockaddr in addresses:
        try:
            der = tls_handshake(host, (family, sockaddr), False)
            if der:
                chosen = (family, sockaddr)
                break
        except (OSError, ssl.SSLError) as exc:
            last_error = exc
    if der is None or chosen is None:
        raise OSError(str(last_error or "Server did not present a certificate"))
    if len(der) > 30_000:
        raise ValueError("Certificate exceeds maximum supported length")
    pem = ssl.DER_cert_to_PEM_cert(der)
    verify_error = None
    verified = True
    try:
        tls_handshake(host, chosen, True)
    except (OSError, ssl.SSLError) as exc:
        verified = False
        verify_error = str(exc)[:600]
    return {"success": True, "certificate_pem": pem, "tls_verified": verified,
            "verify_error": verify_error}


# Per-primary SQLite inventories and result queues.
CACHE_SCHEMA = """
CREATE TABLE IF NOT EXISTS inventory (
 site_id INTEGER PRIMARY KEY, url TEXT NOT NULL, hostname TEXT NOT NULL,
 port INTEGER NOT NULL, paused INTEGER NOT NULL DEFAULT 0,
 next_check_at TEXT, last_checked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_local_due ON inventory(paused,next_check_at);
CREATE TABLE IF NOT EXISTS outbox (
 result_id TEXT PRIMARY KEY,site_id INTEGER NOT NULL,checked_at TEXT NOT NULL,
 payload_json TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',
 rejected_reason TEXT,created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_outbox_pending ON outbox(status,checked_at);
"""


def init_cache(pid: str) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    path = cache_path(pid)
    with closing(sqlite3.connect(path, timeout=20)) as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(CACHE_SCHEMA)
        con.commit()
    os.chmod(path, 0o600)


@contextmanager
def cache_db(pid: str):
    path = cache_path(pid)
    if not path.exists():
        with lock:
            if not path.exists():
                init_cache(pid)
    con = sqlite3.connect(path, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=20000")
    try:
        yield con
        con.commit()
    except BaseException:
        con.rollback()
        raise
    finally:
        con.close()


def next_random_check(now: datetime, tz: str) -> str:
    try:
        zone = ZoneInfo(tz)
    except (ZoneInfoNotFoundError, ValueError):
        zone = timezone.utc
    date = now.astimezone(zone).date() + timedelta(days=1)
    start = datetime(date.year, date.month, date.day, tzinfo=zone).astimezone(timezone.utc)
    later = date + timedelta(days=1)
    end = datetime(later.year, later.month, later.day, tzinfo=zone).astimezone(timezone.utc)
    seconds = max(1, int((end - start).total_seconds()))
    return (start + timedelta(seconds=secrets.randbelow(seconds))).isoformat(timespec="seconds").replace("+00:00", "Z")


def cache_stats(pid: str) -> dict:
    with cache_db(pid) as con:
        total = con.execute("SELECT COUNT(*) FROM inventory").fetchone()[0]
        pending = con.execute("SELECT COUNT(*) FROM outbox WHERE status='pending'").fetchone()[0]
        rejected = con.execute("SELECT COUNT(*) FROM outbox WHERE status='rejected'").fetchone()[0]
        last = con.execute("SELECT MAX(last_checked_at) FROM inventory").fetchone()[0]
        earliest = con.execute("SELECT MIN(checked_at) FROM outbox WHERE status='pending'").fetchone()[0]
        reject = con.execute("SELECT rejected_reason FROM outbox WHERE status='rejected' ORDER BY created_at DESC LIMIT 1").fetchone()
    return {"assigned_sites": total, "queued_results": pending, "rejected_results": rejected,
            "last_local_check": last, "oldest_pending_at": earliest,
            "last_rejection": reject[0] if reject else None}


def reconcile_assignments(pid: str, assignments: list[dict]) -> None:
    if not isinstance(assignments, list) or len(assignments) > 20000:
        raise ValueError("Invalid primary assignment snapshot")
    seen = set()
    with cache_db(pid) as con:
        con.execute("BEGIN IMMEDIATE")
        for item in assignments:
            if not isinstance(item, dict):
                raise ValueError("Invalid assignment")
            site_id = item.get("site_id")
            if (type(site_id) is not int or site_id < 1 or site_id in seen or
                not isinstance(item.get("hostname"), str) or not item["hostname"] or
                not isinstance(item.get("url"), str) or not item["url"] or
                type(item.get("port")) is not int or not 1 <= item["port"] <= 65535 or
                item.get("paused") not in (0, 1)):
                raise ValueError("Invalid site assignment from primary")
            seen.add(site_id)
            prior = con.execute("SELECT * FROM inventory WHERE site_id=?", (site_id,)).fetchone()
            remote_last = item.get("last_checked_at")
            # Retain local schedule while offline observations are still ahead
            # of the primary's recorded time, preventing double-checking.
            same_target = bool(prior and prior["hostname"] == item["hostname"] and prior["port"] == item["port"])
            protect_local = (same_target and prior["last_checked_at"] and
                             (not remote_last or prior["last_checked_at"] > remote_last))
            next_at = prior["next_check_at"] if protect_local else item.get("next_check_at")
            if not next_at and not item["paused"]:
                next_at = stamp()
            last_at = prior["last_checked_at"] if protect_local else remote_last
            con.execute("""INSERT INTO inventory
                (site_id,url,hostname,port,paused,next_check_at,last_checked_at)
                VALUES (?,?,?,?,?,?,?) ON CONFLICT(site_id) DO UPDATE SET
                url=excluded.url,hostname=excluded.hostname,port=excluded.port,
                paused=excluded.paused,next_check_at=excluded.next_check_at,
                last_checked_at=excluded.last_checked_at""",
                (site_id, item["url"], item["hostname"], item["port"], int(item["paused"]),
                 next_at if not item["paused"] else None, last_at))
        if seen:
            placeholders = ",".join("?" for _ in seen)
            con.execute(f"DELETE FROM inventory WHERE site_id NOT IN ({placeholders})", tuple(sorted(seen)))
        else:
            con.execute("DELETE FROM inventory")
        # Already checked results are deliberately retained for the primary to
        # ACK or reject if the website was reassigned during disconnection.


def flush_outbox(settings: dict) -> None:
    pid = settings["profile_id"]
    with cache_db(pid) as con:
        rows = con.execute("""SELECT result_id,payload_json FROM outbox WHERE status='pending'
                 ORDER BY checked_at,result_id LIMIT 15""").fetchall()
    if not rows:
        return
    selected, size = [], 20
    for row in rows:
        estimated = len(row["payload_json"].encode("utf-8")) + 2
        if selected and size + estimated > 350_000:
            break
        selected.append(row)
        size += estimated
    result_data = [json.loads(row["payload_json"]) for row in selected]
    reply = primary_call(settings, "/agent/v1/results/batch", {"results": result_data})
    outcomes = reply.get("outcomes", [])
    if not isinstance(outcomes, list) or len(outcomes) != len(selected):
        raise RuntimeError("Primary returned incomplete outbox acknowledgment")
    expected = {r["result_id"] for r in selected}
    if {r.get("result_id") for r in outcomes} != expected:
        raise RuntimeError("Primary acknowledged unexpected results")
    if not still_active(settings):
        return
    with cache_db(pid) as con:
        for outcome in outcomes:
            rid = outcome["result_id"]
            result = outcome.get("status")
            if result in ("accepted", "duplicate"):
                con.execute("DELETE FROM outbox WHERE result_id=?", (rid,))
            elif result == "rejected":
                con.execute("UPDATE outbox SET status='rejected',rejected_reason=? WHERE result_id=?",
                            (str(outcome.get("reason", "Rejected by primary"))[:400], rid))
            else:
                raise RuntimeError("Unrecognized result acknowledgment status")


def run_local_check(jobs: list[tuple[str, dict]]) -> None:
    """One physical TLS handshake can be fanned out to multiple due primary jobs.

    Each primary independently gets its own result ID, timestamp, schedule,
    and outbox entry; no identity or access token is shared between them.
    """
    try:
        site = jobs[0][1]
        try:
            report = check_certificate(site["hostname"], int(site["port"]))
        except Exception as exc:
            report = {"success": False, "error": f"{type(exc).__name__}: {exc}"[:800]}
        now = datetime.now(timezone.utc)
        checked = now.isoformat(timespec="seconds").replace("+00:00", "Z")
        for pid, site in jobs:
            with lock:
                profile = next((p for p in config["primaries"] if p["profile_id"] == pid), None)
                tz = primary_states.get(pid, {}).get("timezone", "UTC")
            if not profile:
                continue
            next_at = next_random_check(now, tz)
            payload = {"result_id": uuid.uuid4().hex, "site_id": site["site_id"],
                       "checked_at": checked, "next_check_at": next_at, **report}
            try:
                with cache_db(pid) as con:
                    con.execute("BEGIN IMMEDIATE")
                    # Never overwrite a newer assignment/schedule after a
                    # concurrent primary inventory synchronization.
                    exists = con.execute("SELECT hostname,port FROM inventory WHERE site_id=?",
                                         (site["site_id"],)).fetchone()
                    if not exists or exists["hostname"] != site["hostname"] or exists["port"] != site["port"]:
                        continue
                    con.execute("""INSERT INTO outbox
                        (result_id,site_id,checked_at,payload_json,created_at) VALUES (?,?,?,?,?)""",
                        (payload["result_id"], site["site_id"], checked, json.dumps(payload), checked))
                    con.execute("UPDATE inventory SET last_checked_at=?,next_check_at=? WHERE site_id=?",
                                (checked, next_at, site["site_id"]))
                with lock:
                    s = primary_states.setdefault(pid, default_state())
                    s["checks"] += 1
                    s["last_result"] = {"site": site["url"], "success": report["success"], "at": checked}
            except Exception as exc:
                with lock:
                    primary_states.setdefault(pid, default_state())["last_error"] = (
                        f"Could not cache result for {site['url']}: {exc}"[:500])
    finally:
        with lock:
            for pid, site in jobs:
                local_inflight.discard((pid, site["site_id"]))
                s = primary_states.get(pid)
                if s:
                    s["running"] = max(0, s["running"] - 1)


def schedule_due() -> None:
    """Scan all independently persisted inventories and coalesce matching due TLS targets."""
    with lock:
        # A shared handshake may count as two profile jobs; using the number
        # of per-primary running checks is conservative but never oversubscribes.
        active_slots = WORKERS - sum(s["running"] for s in primary_states.values())
        if active_slots <= 0:
            return
        active = [p for p in config["primaries"] if not p.get("paused", False)]
        due = []
        for profile in active:
            pid = profile["profile_id"]
            with cache_db(pid) as con:
                rows = con.execute("""SELECT * FROM inventory WHERE paused=0 AND next_check_at IS NOT NULL
                    AND next_check_at<=? ORDER BY next_check_at LIMIT ?""",
                    (stamp(), max(WORKERS * 4, 12))).fetchall()
            for row in rows:
                site = dict(row)
                if (pid, site["site_id"]) not in local_inflight:
                    due.append((pid, site))
        due.sort(key=lambda item: item[1]["next_check_at"] or "")
        by_target: dict[tuple[str, int], list[tuple[str, dict]]] = {}
        for pid, site in due:
            key = (site["hostname"].casefold(), int(site["port"]))
            by_target.setdefault(key, []).append((pid, site))
        for grouped in list(by_target.values())[:active_slots]:
            for pid, site in grouped:
                local_inflight.add((pid, site["site_id"]))
                primary_states.setdefault(pid, default_state())["running"] += 1
            check_pool.submit(run_local_check, grouped)


def poll_one(settings: dict) -> None:
    pid = settings["profile_id"]
    try:
        if not still_active(settings) or is_paused(pid):
            return
        # Flush first so that previous observations advance the primary clock.
        flush_outbox(settings)
        stats = cache_stats(pid)
        reply = primary_call(settings, "/agent/v1/sync",
                             {"version": VERSION, "queued_results": stats["queued_results"],
                              "last_check_at": stats["last_local_check"]})
        if not still_active(settings) or is_paused(pid):
            return
        reconcile_assignments(pid, reply["assignments"])
        with lock:
            state = primary_states.setdefault(pid, default_state())
            state.update(last_contact=stamp(), last_sync=stamp(), last_error=None,
                         timezone=reply.get("timezone", "UTC"))
    except Exception as exc:
        with lock:
            primary_states.setdefault(pid, default_state())["last_error"] = (
                f"Primary connection/sync failed: {exc}"[:500])
    finally:
        with lock:
            syncing.discard(pid)


def scheduler_step(now: float | None = None):
    now = time.monotonic() if now is None else now
    with lock:
        for settings in list(config["primaries"]):
            if settings.get("paused", False):
                continue
            pid = settings["profile_id"]
            if pid in syncing or next_polls.get(pid, 0) > now:
                continue
            syncing.add(pid)
            next_polls[pid] = now + POLL_SECONDS
            network_pool.submit(poll_one, dict(settings))
    # Independent of connectivity to all primaries.
    schedule_due()


def polling_loop() -> None:
    while not stop_event.is_set():
        try:
            scheduler_step()
        except Exception as exc:
            print(f"TLS Watch scheduler failure: {exc}", flush=True)
        stop_event.wait(2)

@app.before_request
def protect_setup():
    if UI_USERNAME and UI_PASSWORD:
        credentials = request.authorization
        if (not credentials or credentials.type.lower() != "basic"
                or not hmac.compare_digest(credentials.username or "", UI_USERNAME)
                or not hmac.compare_digest(credentials.password or "", UI_PASSWORD)):
            return ("Authentication required", 401,
                    {"WWW-Authenticate": 'Basic realm="TLS Watch Agent"'})
    if request.method == "POST":
        origin = request.headers.get("Origin", "")
        if origin:
            parsed = urlsplit(origin)
            if parsed.scheme not in ("http", "https") or parsed.netloc != request.host:
                return jsonify({"error": "Invalid origin"}), 403
        # A non-simple custom header prevents cross-origin form-based CSRF
        # against a browser's cached HTTP Basic authentication credentials.
        if request.headers.get("X-TLSWatch-Agent") != "1":
            return jsonify({"error": "Missing agent UI request header"}), 403


PAGE = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TLS Watch Agent v4.6.3</title>
<style>
:root{color-scheme:dark;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#0d1622;color:#eff5ff}*{box-sizing:border-box}body{margin:0;padding:22px}main{max-width:1040px;margin:auto}h1{font-size:1.6rem;margin:0}h2{font-size:1.12rem;margin:0 0 12px}p,small{color:#afc4dc;line-height:1.5}header{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;border-bottom:1px solid #324054;padding-bottom:18px}.pill{background:#214839;color:#9df0c7;border-radius:20px;padding:5px 12px;font-size:.85rem}.box{background:#162436;border:1px solid #30445a;border-radius:14px;padding:22px;margin:20px 0}.stats{display:flex;flex-wrap:wrap;gap:16px;margin-top:8px}.stat{border:1px solid #3b5065;padding:10px 16px;border-radius:10px;min-width:120px}.stat b{display:block;font-size:1.35rem}.stat span{color:#b5c8dd;font-size:.85rem}label{display:block;margin:14px 0 6px;font-weight:600;font-size:.9rem}input:not([type=checkbox]),textarea{width:100%;background:#0e1b2c;color:white;border:1px solid #405772;border-radius:8px;padding:12px;font:inherit}textarea{height:90px}.checkbox{width:auto;vertical-align:middle;margin-right:8px}button{background:#2bb88b;color:#041c13;border:0;padding:11px 16px;border-radius:8px;font-weight:700;cursor:pointer;margin:7px 7px 0 0}button.secondary{background:#304a61;color:#f1f5fa}button.danger{background:#64343d;color:#fff}button:disabled{opacity:.6;cursor:not-allowed}td,th{padding:10px 12px;text-align:left;vertical-align:top;border-bottom:1px solid #30445a}th{color:#afc4dc;font-weight:600;font-size:.84rem}table{border-collapse:collapse;width:100%}.scroller{overflow-x:auto}.muted{color:#a9bfd8}.ok{color:#95f1c3}.bad{color:#ffc4bf}.warning{padding:12px;border-left:4px solid #e9b65d;background:#362f20;color:#ffe5aa;border-radius:6px;margin:14px 0}code{padding:2px 5px;background:#0d1c2c}.tiny{font-size:.78rem}.wrap{overflow-wrap:anywhere;word-break:break-word;max-width:280px}#feedback{min-height:22px;white-space:pre-wrap}footer{margin:25px 0;color:#9eb7d0}@media(max-width:700px){body{padding:12px}.box{padding:14px}table{font-size:.86rem}td,th{padding:8px}.stats{gap:7px}.stat{min-width:90px;padding:8px}}

/* Native, keyboard-operable rollups for optional agent administration. */
.accordion{padding:0;overflow:hidden}
.accordion>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:12px;justify-content:space-between;padding:20px 22px;font-size:1.12rem;font-weight:650;color:#eff5ff}
.accordion>summary::-webkit-details-marker{display:none}
.accordion>summary:focus-visible{outline:3px solid #7ce4bc;outline-offset:-4px;border-radius:10px}
.accordion>summary:hover{background:#21344a}
.accordion>summary::after{content:'+';flex:0 0 auto;display:inline-flex;justify-content:center;align-items:center;width:28px;height:28px;border:1px solid #4e728c;border-radius:8px;color:#bce8da;font-size:1.4rem;font-weight:400;line-height:1}
.accordion[open]>summary::after{content:'−'}
.accordion[open]>summary{border-bottom:1px solid #30445a}
.accordion-body{padding:20px 22px 22px}
.accordion-body>p:first-child{margin-top:0}
.accordion-label{flex:1;min-width:0}
.accordion-meta{flex:0 1 auto;color:#b5c8dd;font-size:.8rem;font-weight:400;margin-left:auto;text-align:right}
@media(max-width:700px){.accordion>summary{padding:14px;flex-wrap:wrap}.accordion-body{padding:14px}.accordion-meta{flex:1 1 100%;text-align:left;order:3;margin-left:0}}
</style></head><body><main>
<header><div><h1>TLS Watch · Remote Agent</h1><small>v4.6.3 · Multiple independent primaries · Offline queues</small></div><span class="pill" id="overall">Loading…</span></header>
<div class="warning" id="defaultWarn" hidden>Default admin credentials are enabled. Change AGENT_UI_USERNAME and AGENT_UI_PASSWORD in .env before allowing untrusted users to reach this interface. Use HTTPS/VPN; Basic authentication on HTTP is not encrypted.</div>
<section class="box"><h2>Local monitoring summary</h2><div class="stats"><div class="stat"><b id="primaryCount">0</b><span>Primaries</span></div><div class="stat"><b id="assignedTotal">0</b><span>Assignments</span></div><div class="stat"><b id="queuedTotal">0</b><span>Queued results</span></div><div class="stat"><b id="checksTotal">0</b><span>Checks this run</span></div></div><p class="tiny">Each primary controls only its own assignments. Shared target checks are reused when concurrently due, but results and credentials remain isolated per primary.</p></section>
<section class="box"><h2>Connected primary servers</h2><div class="scroller"><table><thead><tr><th>Primary / Agent</th><th>Connection</th><th>Sites</th><th>Queue</th><th>Last contact</th><th>Management</th></tr></thead><tbody id="rows"><tr><td colspan="6">No primary connected yet.</td></tr></tbody></table></div><p id="managementFeedback" role="status"></p></section>
<details class="box accordion" id="pairAccordion"><summary><span class="accordion-label">Add another primary</span><span class="accordion-meta">Connect an MSP or customer primary</span></summary><div class="accordion-body"><p>Create a monitoring agent and 15-minute pairing code on the desired primary (TLS Watch v4.5+). Add it here without disturbing the other primaries.</p>
<form id="pair"><label for="url">Primary URL (reachable from this machine)</label><input id="url" type="url" placeholder="https://monitor.customer.example:8080" required><label for="code">One-time pairing code</label><input id="code" type="password" autocomplete="off" required><label><input id="allow" class="checkbox" type="checkbox">Allow plain HTTP to primary (trusted lab networks only)</label><label for="ca">Additional trusted CA certificate for the primary (PEM; optional)</label><textarea id="ca" spellcheck="false" placeholder="-----BEGIN CERTIFICATE-----"></textarea><div><button type="submit" id="connect">Connect to primary</button></div><p id="feedback" role="status"></p></form></div></details>
<details class="box accordion" id="trustAccordion"><summary><span class="accordion-label">Trust certificates for monitored HTTPS targets</span><span id="trustCount" class="accordion-meta" aria-live="polite">Loading…</span></summary><div class="accordion-body"><p>Upload a PEM CA certificate or the exact self-signed server certificate to trust it during TLS checks. Hostname and expiration validation remain enabled. This trust list applies to local targets checked for any primary, but does not change primary connection trust or the agent admin Web UI.</p>
<form id="trustForm"><label for="targetPem">Target CA / self-signed certificate (PEM file)</label><input type="file" id="targetPem" accept=".pem,.crt,.cer" required><label for="targetLabel">Description</label><input id="targetLabel" maxlength="80" placeholder="Customer LAN CA" required><button type="submit">Install trusted certificate</button><p id="trustMessage" role="status"></p></form>
<div class="scroller"><table><thead><tr><th>Description</th><th>SHA-256 fingerprint</th><th>Action</th></tr></thead><tbody id="trustRows"><tr><td colspan="3">No additional trust certificates installed.</td></tr></tbody></table></div></div></details>
<details class="box accordion" id="httpsAccordion"><summary><span class="accordion-label">Agent Admin UI · HTTPS</span><span class="accordion-meta" id="httpsState" aria-live="polite">HTTPS status loading…</span></summary><div class="accordion-body"><p>Install a server certificate and matching unencrypted private key in PEM format. Enable HTTPS to protect credentials and administration traffic. Restart the agent to activate a change to HTTPS or HTTP. Use a certificate whose SAN matches the hostname you enter in your browser.</p>
<form id="uiTlsForm"><label for="adminCert">Admin UI server certificate (PEM)</label><input type="file" id="adminCert" accept=".pem,.crt,.cer" required><label for="adminKey">Matching private key (unencrypted PEM)</label><input type="file" id="adminKey" accept=".pem,.key" required><div><button type="submit">Install certificate &amp; key</button></div><p id="httpsMessage" role="status"></p></form>
<div><button type="button" id="enableHttps">Enable HTTPS after restart</button><button type="button" id="disableHttps" class="secondary">Disable HTTPS after restart</button><button type="button" id="removeAdminTls" class="danger">Delete admin UI certificate &amp; key</button></div><p class="tiny">The private key is never returned to the browser. TLS certificates/keys are saved in the persistent agent data directory with restrictive permissions. Deletion disables HTTPS after restart.</p></div></details>
<details class="box accordion" id="diagnosticsAccordion"><summary><span class="accordion-label">Agent Diagnostics</span><span class="accordion-meta">On-demand DNS · TCP · TLS · Trust</span></summary><div class="accordion-body">
<p>Run a single endpoint test from this agent. System and installed target PEM certificates are used for trust validation. Private LAN destinations are supported; loopback, link-local, metadata and special-use IPs are blocked. DNS answers are pinned for the test. No HTTP request is sent and results are not saved or sent to primaries.</p>
<form id="diagnosticsForm"><label for="diagnosticsHost">Hostname or IP address</label><input id="diagnosticsHost" maxlength="253" placeholder="service.customer.example" required autocomplete="off"><label for="diagnosticsPort">TCP port</label><input id="diagnosticsPort" type="number" min="1" max="65535" value="443" required><button id="diagnosticsRun" type="submit">Run diagnostics</button></form>
<p id="diagnosticsStatus" role="status" aria-live="polite"></p><pre id="diagnosticsResult" style="white-space:pre-wrap;overflow-wrap:anywhere" tabindex="0" aria-label="Diagnostic results"></pre>
</div></details>
<footer>Monitoring probes originate from this Linux machine's real network interfaces and routes. Connections to all primaries are outbound. Local assignments and result queues survive agent restarts and primary outages. Keep the /data volume or native data/ directory.</footer>
</main><script>
const byId=id=>document.getElementById(id);
async function call(path,options={}){const r=await fetch(path,options);let data={};try{data=await r.json();}catch(e){}if(!r.ok)throw Error(data.error||'HTTP '+r.status);return data;}
const posted=data=>({method:'POST',headers:{'Content-Type':'application/json','X-TLSWatch-Agent':'1'},body:JSON.stringify(data)});
function addCell(row,value,css=''){const td=document.createElement('td');td.textContent=value;td.className=css;row.appendChild(td);return td;}
async function refreshTrust(){try{const d=await call('/api/trust');byId('trustCount').textContent=d.certificates.length+' installed';const body=byId('trustRows');body.replaceChildren();if(!d.certificates.length){const tr=document.createElement('tr');addCell(tr,'No additional certificates installed.').colSpan=3;body.appendChild(tr);}for(const item of d.certificates){const tr=document.createElement('tr');addCell(tr,item.label);addCell(tr,item.fingerprint,'tiny wrap');const td=document.createElement('td');const btn=document.createElement('button');btn.type='button';btn.className='danger tiny';btn.textContent='Delete';btn.addEventListener('click',async()=>{if(!confirm('Remove trust for '+item.label+'? A self-signed server may fail TLS verification after this.'))return;try{await call('/api/trust/delete',posted({fingerprint:item.fingerprint}));byId('trustMessage').textContent='Trusted certificate removed.';await refreshTrust();}catch(e){byId('trustMessage').textContent=e.message;}});td.appendChild(btn);tr.appendChild(td);body.appendChild(tr);}}catch(e){byId('trustMessage').textContent=e.message;}}
async function refreshTls(){try{const d=await call('/api/security/ui-tls');byId('httpsState').textContent=(d.currently_https?'Running HTTPS':'Running HTTP')+' · '+(d.installed?'Certificate installed':'No certificate installed')+' · '+(d.enabled_on_next_start?'HTTPS enabled for next start':'HTTP enabled for next start')+(d.restart_required?' · RESTART REQUIRED':'');byId('enableHttps').disabled=!d.installed;byId('removeAdminTls').disabled=!d.installed;}catch(e){byId('httpsMessage').textContent=e.message;}}
let firstStatusRefresh=true;
async function refresh(){try{const d=await call('/api/state');if(firstStatusRefresh){if(!d.primaries.length)byId('pairAccordion').open=true;firstStatusRefresh=false;}byId('overall').textContent=d.primaries.length+' primary connection(s)';byId('primaryCount').textContent=d.primaries.length;byId('assignedTotal').textContent=d.assigned_sites;byId('queuedTotal').textContent=d.queued_results;byId('checksTotal').textContent=d.checks;byId('defaultWarn').hidden=!d.default_credentials;
const body=byId('rows');body.replaceChildren();if(!d.primaries.length){const tr=document.createElement('tr');addCell(tr,'No primary connected yet.').colSpan=6;body.appendChild(tr);}
for(const p of d.primaries){const tr=document.createElement('tr');const first=addCell(tr,p.agent_name||'Unnamed');first.appendChild(document.createElement('br'));const small=document.createElement('small');small.textContent=p.primary_url;small.className='wrap';first.appendChild(small);addCell(tr,p.connection,p.connection==='Connected'?'ok':(p.paused?'muted':'bad'));addCell(tr,String(p.assigned_sites));addCell(tr,String(p.queued_results)+' pending / '+p.rejected_results+' rejected');addCell(tr,p.last_contact||'Never');const tools=document.createElement('td');const detail=document.createElement('details');const summary=document.createElement('summary');summary.textContent='Details';detail.appendChild(summary);const paragraph=document.createElement('p');paragraph.className='tiny wrap';paragraph.textContent='Last sync: '+(p.last_sync||'Never')+' | Last check: '+(p.last_local_check||'Never')+' | Last error: '+(p.last_error||'None');detail.appendChild(paragraph);tools.appendChild(detail);
const pause=document.createElement('button');pause.type='button';pause.className='secondary tiny';pause.textContent=p.paused?'Resume':'Pause';pause.title=p.paused?'Restore synchronization and scheduled checks':'Stop synchronization and local checks for this primary, preserving its assignments and queued results';pause.addEventListener('click',()=>pausePrimary(p));tools.appendChild(pause);
const retry=document.createElement('button');retry.type='button';retry.className='secondary tiny';retry.textContent='Retry now';retry.disabled=p.paused;retry.title='Immediately retry the connection to this primary';retry.addEventListener('click',()=>retryPrimary(p));tools.appendChild(retry);
const repair=document.createElement('button');repair.type='button';repair.className='secondary tiny';repair.textContent='Re-pair';repair.title='Update pairing token using a new code from the same agent record on the primary';repair.addEventListener('click',()=>repairPrimary(p));tools.appendChild(repair);
const remove=document.createElement('button');remove.type='button';remove.className='danger tiny';remove.textContent='Disconnect';remove.addEventListener('click',()=>removePrimary(p));tools.appendChild(remove);tr.appendChild(tools);body.appendChild(tr);}
}catch(e){byId('overall').textContent='Status unavailable';byId('managementFeedback').textContent=e.message;}}
async function pausePrimary(p){try{await call('/api/primary/pause',posted({profile_id:p.profile_id,paused:!p.paused}));byId('managementFeedback').textContent=p.paused?'Primary resumed; checks and sync will continue.':'Primary paused; cached results and assignments retained.';await refresh();}catch(e){byId('managementFeedback').textContent=e.message;}}
async function retryPrimary(p){try{await call('/api/primary/retry',posted({profile_id:p.profile_id}));byId('managementFeedback').textContent='Connection retry requested for '+p.agent_name;await refresh();}catch(e){byId('managementFeedback').textContent=e.message;}}
async function repairPrimary(p){if(!p.paused){byId('managementFeedback').textContent='Pause this primary before re-pairing, so its local inventory and result queue stay consistent.';return;}
const code=prompt('Generate a new pairing code on the EXISTING agent record in '+p.agent_name+' (primary), then paste it here. Cancel to keep the current pairing.');if(code===null)return;
try{await call('/api/primary/repair',posted({profile_id:p.profile_id,enrollment_code:code.trim()}));byId('managementFeedback').textContent='Re-paired '+p.agent_name+'. Resume the connection to continue checks.';await refresh();}catch(e){byId('managementFeedback').textContent=e.message;}}
async function removePrimary(p){if(!confirm('Disconnect '+p.agent_name+' at '+p.primary_url+'? Its local inventory will be removed. Other primary connections are not affected.'))return;try{await call('/api/disconnect',posted({profile_id:p.profile_id}));byId('managementFeedback').textContent='Disconnected '+p.agent_name;await refresh();}catch(e){if(p.queued_results>0&&confirm('This primary has '+p.queued_results+' undelivered result(s). FORCE DISCONNECT will permanently discard them. Proceed?')){try{await call('/api/disconnect',posted({profile_id:p.profile_id,force:true}));byId('managementFeedback').textContent='Disconnected; pending results discarded.';await refresh();}catch(x){byId('managementFeedback').textContent=x.message;}}else{byId('managementFeedback').textContent=e.message;}}}
byId('pair').addEventListener('submit',async e=>{e.preventDefault();const button=byId('connect');button.disabled=true;byId('feedback').textContent='Connecting…';try{await call('/api/pair',posted({primary_url:byId('url').value,enrollment_code:byId('code').value,allow_http:byId('allow').checked,ca_pem:byId('ca').value}));byId('feedback').textContent='Primary connected. Inventory sync begins automatically.';byId('code').value='';byId('url').value='';byId('ca').value='';await refresh();}catch(x){byId('feedback').textContent=x.message;}finally{button.disabled=false;}});
byId('trustForm').addEventListener('submit',async e=>{e.preventDefault();try{const f=byId('targetPem').files[0];if(!f)throw Error('Choose a certificate PEM file');const data=await call('/api/trust/add',posted({label:byId('targetLabel').value,pem:await f.text()}));byId('trustMessage').textContent='Installed '+data.label+'. Future TLS checks will include this trust anchor.';byId('targetPem').value='';byId('targetLabel').value='';await refreshTrust();}catch(err){byId('trustMessage').textContent=err.message;}});
byId('uiTlsForm').addEventListener('submit',async e=>{e.preventDefault();try{const cert=byId('adminCert').files[0];const key=byId('adminKey').files[0];if(!cert||!key)throw Error('Choose both PEM files');await call('/api/security/ui-tls',posted({action:'install',certificate_pem:await cert.text(),private_key_pem:await key.text()}));byId('httpsMessage').textContent='Matching server certificate and key installed. Click Enable HTTPS, then restart the agent.';byId('adminCert').value='';byId('adminKey').value='';await refreshTls();}catch(err){byId('httpsMessage').textContent=err.message;}});
async function tlsAction(action){if(action==='delete'&&!confirm('Delete the installed admin UI certificate and key, and disable HTTPS on next restart?'))return;try{await call('/api/security/ui-tls',posted({action}));byId('httpsMessage').textContent=(action==='enable'?'HTTPS enabled for next start.':action==='disable'?'HTTPS disabled for next start.':'Certificate and key deleted.')+' RESTART AGENT to apply.';await refreshTls();}catch(e){byId('httpsMessage').textContent=e.message;}}
byId('enableHttps').addEventListener('click',()=>tlsAction('enable'));
byId('disableHttps').addEventListener('click',()=>tlsAction('disable'));
byId('removeAdminTls').addEventListener('click',()=>tlsAction('delete'));
refresh();refreshTrust();refreshTls();setInterval(refresh,5000);
byId('diagnosticsForm').addEventListener('submit',async e=>{e.preventDefault();const button=byId('diagnosticsRun');button.disabled=true;byId('diagnosticsStatus').textContent='Running diagnostics (up to 15 seconds)…';byId('diagnosticsResult').textContent='';try{const d=await call('/api/diagnostics',posted({host:byId('diagnosticsHost').value,port:Number(byId('diagnosticsPort').value)}));byId('diagnosticsStatus').textContent=d.success?'All checks passed.':'Diagnostics completed with failures. Review results below.';const lines=d.steps.map(s=>(s.success?'PASS':'FAIL')+' · '+s.name+' · '+s.duration_ms+' ms'+(s.error?' · '+s.error.message:''));byId('diagnosticsResult').textContent=lines.join('\n')+'\n\n'+JSON.stringify(d,null,2);}catch(err){byId('diagnosticsStatus').textContent=err.message;}finally{button.disabled=false;}});
</script></body></html>'''


@app.get("/")
def home():
    return render_template_string(PAGE)


@app.get("/api/state")
def public_state():
    with lock:
        active = list(config["primaries"])
        states = {p["profile_id"]: dict(primary_states.get(p["profile_id"], default_state())) for p in active}
    result = []
    for profile in active:
        pid = profile["profile_id"]
        info = cache_stats(pid)
        s = states[pid]
        last = s["last_contact"]
        try:
            online = bool(last and (datetime.now(timezone.utc) - datetime.fromisoformat(last.replace("Z", "+00:00"))).total_seconds() < 90)
        except (ValueError, TypeError):
            online = False
        result.append({"profile_id": pid, "primary_url": profile["primary_url"],
                       "agent_name": profile.get("agent_name"), "agent_id": profile.get("agent_id"),
                       "connection": "Paused" if profile.get("paused", False) else (
                           "Connected" if online else "Offline / retrying"),
                       "paused": bool(profile.get("paused", False)),
                       **s, **info})
    return jsonify({"version": VERSION, "configured": bool(result), "primaries": result,
                    "assigned_sites": sum(p["assigned_sites"] for p in result),
                    "queued_results": sum(p["queued_results"] for p in result),
                    "rejected_results": sum(p["rejected_results"] for p in result),
                    "checks": sum(p["checks"] for p in result),
                    "default_credentials": UI_USERNAME == "admin" and UI_PASSWORD == "admin1234"})


@app.post("/api/diagnostics")
def agent_diagnostics():
    # Fail closed even if an operator disables authentication for legacy routes.
    credentials = request.authorization
    if (not UI_USERNAME or not UI_PASSWORD or not credentials or credentials.type.lower() != "basic"
            or not hmac.compare_digest(credentials.username or "", UI_USERNAME)
            or not hmac.compare_digest(credentials.password or "", UI_PASSWORD)):
        return jsonify({"error": "Configured administrator authentication is required"}), 401
    if not request.is_json:
        return jsonify({"error": "Send a JSON object"}), 400
    try:
        host, port = diagnostics.validate_input(request.get_json(silent=True))
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    if not diagnostics.PROBE_SLOTS.acquire(blocking=False):
        return jsonify({"error": "Diagnostics busy; retry after the current test finishes"}), 429
    try:
        try:
            bundle = local_trust_bundle()
        except (OSError, ValueError):
            return jsonify({"error": "Unable to load installed target trust certificates"}), 503
        result = diagnostics.run(host, port, bundle, os.environ.get("AGENT_DIAGNOSTICS_ALLOWLIST", ""))
        response = jsonify(result)
        response.headers["Cache-Control"] = "no-store"
        return response
    finally:
        diagnostics.PROBE_SLOTS.release()


@app.get("/api/trust")
def get_trust():
    return jsonify({"certificates": trust_entries()})


@app.post("/api/trust/add")
def add_trust():
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return jsonify({"error": "Expected a certificate and label"}), 400
    try:
        label = body.get("label", "")
        if not isinstance(label, str) or not 1 <= len(label.strip()) <= 80:
            raise ValueError("Description must be 1–80 characters")
        pem, fingerprint = checked_pem(body.get("pem", ""))
        with lock:
            index = trust_index()
            if fingerprint not in index and len(index) >= 100:
                raise ValueError("At most 100 additional trusted certificates are supported")
            TRUST_DIR.mkdir(parents=True, exist_ok=True)
            os.chmod(TRUST_DIR, 0o700)
            target = TRUST_DIR / (fingerprint + ".pem")
            temporary = TRUST_DIR / (fingerprint + ".tmp")
            temporary.write_text(pem, encoding="utf-8")
            os.chmod(temporary, 0o600)
            temporary.replace(target)
            index[fingerprint] = {"label": label.strip()}
            save_trust_index(index)
        return jsonify({"ok": True, "label": label.strip(), "fingerprint": fingerprint})
    except (ValueError, ssl.SSLError) as exc:
        return jsonify({"error": str(exc)}), 400


@app.post("/api/trust/delete")
def delete_trust():
    body = request.get_json(silent=True)
    fingerprint = body.get("fingerprint") if isinstance(body, dict) else None
    if not isinstance(fingerprint, str) or not re.fullmatch(r"[0-9a-f]{64}", fingerprint):
        return jsonify({"error": "Invalid certificate fingerprint"}), 400
    with lock:
        index = trust_index()
        if fingerprint not in index:
            return jsonify({"error": "Certificate not found"}), 404
        del index[fingerprint]
        save_trust_index(index)
        (TRUST_DIR / (fingerprint + ".pem")).unlink(missing_ok=True)
    return jsonify({"ok": True})


@app.get("/api/security/ui-tls")
def get_ui_tls():
    return jsonify(ui_tls_state(request.is_secure))


@app.post("/api/security/ui-tls")
def configure_ui_tls():
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return jsonify({"error": "Invalid request"}), 400
    action = body.get("action")
    try:
        with lock:
            if action == "install":
                certificate_pem = body.get("certificate_pem", "")
                private_key_pem = body.get("private_key_pem", "")
                if (not isinstance(certificate_pem, str) or not isinstance(private_key_pem, str) or
                        not certificate_pem.startswith("-----BEGIN CERTIFICATE-----") or
                        "PRIVATE KEY-----" not in private_key_pem or
                        "ENCRYPTED PRIVATE KEY" in private_key_pem or
                        len(certificate_pem.encode("utf-8")) > 90_000 or
                        len(private_key_pem.encode("utf-8")) > 90_000):
                    raise ValueError("Upload a server certificate chain and matching unencrypted private key as PEM files (up to 90 KB each)")
                DATA_DIR.mkdir(parents=True, exist_ok=True)
                staged_cert = DATA_DIR / "ui_cert_stage.tmp"
                staged_key = DATA_DIR / "ui_key_stage.tmp"
                try:
                    for target, value in ((staged_cert, certificate_pem), (staged_key, private_key_pem)):
                        target.write_text(value, encoding="utf-8")
                        os.chmod(target, 0o600)
                    validate_server_pair(staged_cert, staged_key)
                    staged_cert.replace(UI_TLS_CERT)
                    staged_key.replace(UI_TLS_KEY)
                finally:
                    staged_cert.unlink(missing_ok=True)
                    staged_key.unlink(missing_ok=True)
            elif action == "enable":
                if not UI_TLS_CERT.is_file() or not UI_TLS_KEY.is_file():
                    raise ValueError("Install a matching server certificate and key before enabling HTTPS")
                validate_server_pair(UI_TLS_CERT, UI_TLS_KEY)
                set_tls_ui_config(True)
            elif action == "disable":
                set_tls_ui_config(False)
            elif action == "delete":
                set_tls_ui_config(False)
                UI_TLS_CERT.unlink(missing_ok=True)
                UI_TLS_KEY.unlink(missing_ok=True)
            else:
                raise ValueError("Unknown action")
        return jsonify({"ok": True, "restart_required": True})
    except (ValueError, OSError, ssl.SSLError) as exc:
        return jsonify({"error": str(exc)[:350]}), 400


@app.post("/api/pair")
def pair():
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return jsonify({"error": "A JSON configuration object is required"}), 400
    try:
        allow = body.get("allow_http") is True
        url = primary_url(str(body.get("primary_url", "")), allow)
        code = body.get("enrollment_code", "")
        ca = body.get("ca_pem", "")
        if not isinstance(code, str) or not 35 <= len(code) <= 160:
            raise ValueError("Paste the complete enrollment code")
        if not isinstance(ca, str) or len(ca) > 20000:
            raise ValueError("Custom CA certificate is too large")
        with lock:
            if len(config["primaries"]) >= MAX_PRIMARIES:
                raise ValueError("Maximum number of primary connections reached")
            if any(p["primary_url"].casefold() == url.casefold() for p in config["primaries"]):
                raise ValueError("This primary URL is already connected; disconnect before re-pairing")
        pending = {"primary_url": url, "ca_pem": ca, "allow_http": allow}
        reply = primary_call(pending, "/agent/v1/enroll", {"enrollment_code": code})
        token = reply.get("agent_token")
        agent_id = reply.get("agent_id")
        name = reply.get("agent_name")
        if (not isinstance(token, str) or not token.startswith("tlsw-agent-") or
            type(agent_id) is not int or agent_id < 1 or not isinstance(name, str)):
            raise ValueError("Primary enrollment response was invalid")
        pid = profile_id()
        pending.update(profile_id=pid, token=token, agent_id=agent_id, agent_name=name, paused=False)
        init_cache(pid)
        with lock:
            if any(p["primary_url"].casefold() == url.casefold() for p in config["primaries"]):
                raise ValueError("Primary URL became connected during enrollment")
            atomic_config({"schema_version": 2, "primaries": [*config["primaries"], pending]})
            primary_states[pid] = default_state()
        return jsonify({"ok": True, "profile_id": pid, "agent_name": name})
    except Exception as exc:
        return jsonify({"error": f"{type(exc).__name__}: {exc}"[:600]}), 400


@app.post("/api/primary/pause")
def pause_primary():
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or not isinstance(body.get("profile_id"), str) or type(body.get("paused")) is not bool:
        return jsonify({"error": "profile_id and a boolean paused are required"}), 400
    pid = body["profile_id"]
    try:
        with lock:
            if not require_profile(pid):
                return jsonify({"error": "Primary profile not found"}), 404
            updated = []
            for p in config["primaries"]:
                updated.append({**p, "paused": body["paused"]} if p["profile_id"] == pid else dict(p))
            atomic_config({**config, "primaries": updated})
            if not body["paused"]:
                next_polls[pid] = 0
        return jsonify({"ok": True, "paused": body["paused"]})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.post("/api/primary/retry")
def retry_primary():
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or not isinstance(body.get("profile_id"), str):
        return jsonify({"error": "profile_id required"}), 400
    pid = body["profile_id"]
    try:
        with lock:
            p = require_profile(pid)
            if p is None:
                return jsonify({"error": "Primary profile not found"}), 404
            if p.get("paused", False):
                return jsonify({"error": "Resume this primary before retrying"}), 409
            next_polls[pid] = 0
        return jsonify({"ok": True, "message": "Connection retry scheduled"})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.post("/api/primary/repair")
def repair_primary():
    """Re-enroll an existing primary profile without discarding its cached checks.

    Only a pairing code generated for the SAME primary agent identity is accepted.
    Different identities must be connected as separate profiles; mixing queues would
    lead to cross-tenant result delivery or silently rejected observations.
    """
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or not isinstance(body.get("profile_id"), str):
        return jsonify({"error": "profile_id and enrollment_code required"}), 400
    pid = body["profile_id"]
    code = body.get("enrollment_code")
    if not isinstance(code, str) or not 35 <= len(code) <= 160:
        return jsonify({"error": "Paste a valid one-time enrollment code"}), 400
    try:
        with lock:
            existing = require_profile(pid)
            if existing is None:
                return jsonify({"error": "Primary profile not found"}), 404
            if not existing.get("paused", False):
                return jsonify({"error": "Pause this primary before re-pairing"}), 409
            if pid in syncing or any(k[0] == pid for k in local_inflight):
                return jsonify({"error": "Checks or synchronization are still in progress; retry shortly"}), 409
        reply = primary_call(existing, "/agent/v1/enroll", {"enrollment_code": code})
        token, agent_id = reply.get("agent_token"), reply.get("agent_id")
        if not isinstance(token, str) or not token.startswith("tlsw-agent-") or type(agent_id) is not int:
            return jsonify({"error": "Primary returned an invalid enrollment response"}), 502
        if agent_id != existing["agent_id"]:
            return jsonify({"error": "Pairing code belongs to a DIFFERENT agent record. Generate a code for the existing agent record on this primary, or disconnect and add as a new primary (the current offline queue must first be handled)."}), 409
        with lock:
            current = require_profile(pid)
            if current is None or not current.get("paused", False) or current["token"] != existing["token"]:
                return jsonify({"error": "Primary profile changed during re-pairing; retry"}), 409
            updated = [{**p, "token": token, "agent_name": reply.get("agent_name") or p.get("agent_name")}
                       if p["profile_id"] == pid else dict(p) for p in config["primaries"]]
            atomic_config({**config, "primaries": updated})
            primary_states.setdefault(pid, default_state())["last_error"] = None
        return jsonify({"ok": True, "profile_id": pid, "paused": True, "message": "Re-paired; resume to synchronize"})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"error": f"{type(exc).__name__}: {exc}"[:600]}), 502


@app.post("/api/disconnect")
def disconnect():
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or not isinstance(body.get("profile_id"), str):
        return jsonify({"error": "profile_id is required"}), 400
    pid = body["profile_id"]
    try:
        cache_path(pid)
        with lock:
            if not any(p["profile_id"] == pid for p in config["primaries"]):
                return jsonify({"error": "Primary profile not found"}), 404
            if pid in syncing or any(key[0] == pid for key in local_inflight):
                return jsonify({"error": "Check or synchronization in progress; retry shortly"}), 409
            stats = cache_stats(pid)
            if stats["queued_results"] and body.get("force") is not True:
                return jsonify({"error": "This primary has undelivered results. Synchronize before disconnecting or explicitly force removal."}), 409
            atomic_config({"schema_version": 2, "primaries": [p for p in config["primaries"] if p["profile_id"] != pid]})
            primary_states.pop(pid, None)
            next_polls.pop(pid, None)
        # Other profiles are unaffected. The removed database is deleted only
        # after its credentials have been removed from the agent config.
        path = cache_path(pid)
        for filename in (path, Path(str(path) + "-wal"), Path(str(path) + "-shm")):
            filename.unlink(missing_ok=True)
        return jsonify({"ok": True})
    except Exception as exc:
        return jsonify({"error": str(exc)[:600]}), 500


def validate_runtime():
    if not UI_BIND:
        raise ValueError("AGENT_UI_BIND must be a valid listen address")
    if not 1 <= PORT <= 65535:
        raise ValueError("AGENT_UI_PORT must be 1..65535")
    if (UI_USERNAME and not UI_PASSWORD) or (UI_PASSWORD and not UI_USERNAME):
        raise ValueError("Set both AGENT_UI_USERNAME and AGENT_UI_PASSWORD, or neither")
    if UI_BIND not in ("127.0.0.1", "::1", "localhost") and not (UI_USERNAME and UI_PASSWORD):
        raise ValueError("Non-loopback agent Web UI requires username and password")


if __name__ == "__main__":
    validate_runtime()
    load_config()
    security = tls_ui_config()
    admin_tls = None
    if security["enabled"]:
        if not UI_TLS_CERT.exists() or not UI_TLS_KEY.exists():
            raise RuntimeError("Agent HTTPS is enabled but no matching server certificate/key is installed")
        validate_server_pair(UI_TLS_CERT, UI_TLS_KEY)
        admin_tls = (str(UI_TLS_CERT), str(UI_TLS_KEY))
    threading.Thread(target=polling_loop, daemon=True, name="agent-scheduler").start()
    scheme = "https" if admin_tls else "http"
    print(f"TLS Watch v{VERSION}: agent Web UI listening on {scheme}://{UI_BIND}:{PORT}", flush=True)
    app.run(host=UI_BIND, port=PORT, ssl_context=admin_tls, debug=False, use_reloader=False, threaded=True)
