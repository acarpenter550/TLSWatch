# Baseline comparison

Source ZIP: `TLS_Watch_v4_6_2_Agent_Linux_and_Docker_Complete.zip`

SHA-256: `c0abd7481d1a50b26e39cb712760bba5a274f436d4d9353e78b1d256da0b6318`

| File | Status |
|---|---|
| .dockerignore | Unchanged |
| .env.example | Updated |
| .gitignore | Unchanged |
| AGENT_API.md | Updated |
| DIAGNOSTICS.md | Added |
| Dockerfile | Updated |
| README.md | Updated |
| RELEASE_NOTES.md | Updated |
| VALIDATION.md | Added |
| VERSION | Updated |
| agent.py | Updated |
| compose.bridge.yaml | Unchanged |
| compose.yaml | Unchanged |
| diagnostics.py | Added |
| install_linux.sh | Unchanged |
| install_user_service.sh | Unchanged |
| requirements.txt | Updated |
| start_agent.sh | Unchanged |
| tests/test_accordion_ui.py | Updated |
| tests/test_agent.py | Unchanged |
| tests/test_cert_security.py | Unchanged |
| tests/test_diagnostics.py | Added |
| tests/test_offline_cache.py | Unchanged |
