# TLS Watch Agent v4.6.3 — local UI/API and primary protocol

Agent HTTP listener: `http://AGENT-LAN-IP:8899` by default. The setup API requires the same Basic authentication as the Web UI (`admin` / `admin1234` initially; **change these**). `POST` requests from the browser must contain `X-TLSWatch-Agent: 1`; this prevents cross-origin form posts relying on ambient HTTP Basic credentials. Restrict this interface to trusted LAN/VPN/HTTPS proxy access.

## Agent-local endpoints

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/` | Multi-primary pairing and status dashboard |
| `GET` | `/api/state` | Aggregated status and per-primary status / queue lengths; tokens omitted |
| `POST` | `/api/pair` | Enroll a new, additional primary |
| `POST` | `/api/disconnect` | Forget a selected primary, optionally force-discarding its pending results |

### `POST /api/pair`

```json
{
  "primary_url": "https://msp-primary.example.net",
  "enrollment_code": "<one-time code from that primary's Monitoring Agents panel>",
  "allow_http": false,
  "ca_pem": ""
}
```

Response: `{"ok": true, "profile_id": "<local 32-character id>", "agent_name": "<primary-created agent name>"}`. You can enroll other *different* primary origins in the same agent. Each primary creates its own registration and single-use code. Re-pairing an already enrolled origin is blocked to protect cached results; disconnect first after syncing its queue.

### `POST /api/disconnect`

```json
{"profile_id": "<profile_id from /api/state>"}
```

If results remain undelivered, the server responds with `409`. After explicit confirmation that losing those results is acceptable, a client may use:

```json
{"profile_id": "<profile_id>", "force": true}
```

Disconnect is refused while that primary has active sync/check work. Other primaries remain connected. The removed primary's own registration can also be revoked via its primary-side Monitoring Agents panel.

### `GET /api/state`

Each entry under `primaries` includes `profile_id`, `primary_url`, `agent_name`, `agent_id`, `connection`, `assigned_sites`, `queued_results`, `rejected_results`, `last_contact`, `last_sync`, `last_local_check`, and `last_error`. This API **never returns pairing tokens**.

## Unmodified TLS Watch primary v4.5 agent protocol

Each primary independently receives the same v4.5 requests using **its own** bearer token:

- `POST <primary>/agent/v1/enroll` — one-time code; primary returns registration ID/name/token.
- `POST <primary>/agent/v1/sync` — locally cached `queued_results` and `last_check_at`; primary responds with **only that agent registration's assignments**.
- `POST <primary>/agent/v1/results/batch` — independently identified cached check results; primary acknowledges accepted / duplicate / rejected result IDs.

There are **no new primary endpoints** and no changes to its group-specific API, monitoring UI, or webhooks. Sites are assigned using the existing **Check Using** control on the relevant primary.

The agent caches each primary separately in `primary_<profile_id>.sqlite3`. Shared local TLS handshakes are fanned out into **separate** signed-by-token API uploads. Certificate data is never accessible to another primary through this agent protocol.

## Agent v4.6.1 local management

All routes require the agent admin's Basic Auth. POST requires `X-TLSWatch-Agent: 1` and JSON request data. Operations are not available to any connected primary.

| Method | Path | JSON request |
| --- | --- | --- |
| GET | `/api/trust` | none; response lists `certificates` (fingerprint, label) |
| POST | `/api/trust/add` | `{"label":"LAN Root","pem":"-----BEGIN CERTIFICATE-----..."}` |
| POST | `/api/trust/delete` | `{"fingerprint":"<lowercase sha256>"}` |
| GET | `/api/security/ui-tls` | none; returns `installed`, `enabled_on_next_start`, `currently_https`, `restart_required` |
| POST | `/api/security/ui-tls` | `{"action":"install","certificate_pem":"...","private_key_pem":"..."}` or `{ "action": "enable" | "disable" | "delete" }` |

The uploaded target PEM extends the OS CA trust for monitored server handshakes and can be removed by fingerprint. This does not disable verification. Admin UI server certificates and private keys are a different setting and apply only after restart. Admin HTTPS requires a matching unencrypted private key and PEM certificate chain. Keep imported keys and CA files backed up securely in the agent data directory.

## v4.6.2 UI update

The primary enrollment form, trusted certificate management, and admin-HTTPS configuration are now collapsible sections. **No API endpoints or payloads changed in v4.6.2**; primary v4.6 remains compatible.

## v4.6.3 — diagnostics

`POST /api/diagnostics`: administrator-only on-demand DNS/TCP/TLS and certificate trust tests. JSON body: `{"host":"service.customer.lan","port":443}`. See [DIAGNOSTICS.md](DIAGNOSTICS.md) for response fields, access rules, policy and limits. All existing primary protocol and local management endpoints are retained.
