# TLS Watch Agent v4.6.3 — October 25, 2026

Agent-only release based on the supplied v4.6.2 Linux/Docker ZIP. Compatible with
Primary v4.6; no primary changes, schema migration or re-pairing required.

- Add a collapsed **Agent Diagnostics** section to the existing authenticated UI.
- Add DNS, single-address TCP, TLS handshake/protocol/cipher, peer identity/issuer,
  validity, SANs, SHA-256 fingerprint, SAN hostname/IP verification, and OpenSSL
  certificate-chain validation with system plus installed target PEM trust.
- Show stage timings, overall duration, sanitized errors and failed trust details
  while keeping untrusted certificates inspectable.
- Add strict host/port input validation, pinned DNS answers, special-address and
  metadata blocking, optional exact hostname/IP/CIDR allowlisting, independent
  concurrency caps and bounded network waits. No subprocesses or application
  requests. Administrator authentication is mandatory even if legacy UI auth is
  disabled; existing origin and custom-header protections apply.
- Preserve multi-primary enrollment/management, independent offline schedules and
  queues, pairing, trusted PEM management, admin HTTPS, LAN defaults and deployment
  scripts. Update the primary-call User-Agent string to the actual release version.
- Add the cryptography dependency for certificate decoding; Docker copies the new
  diagnostics module. Existing configuration and data remain compatible.
- Repair the malformed accordion test page-extraction expression shipped in the
  baseline. Add offline security tests and real local TLS success, trust failure,
  expired certificate, hostname mismatch, IP SAN and wildcard tests.

Upgrade instructions are in README.md; policy, API and limitations are in
DIAGNOSTICS.md. Validation results are in VALIDATION.md. In particular, diagnostics
test the first DNS address, require SANs, and do not perform OCSP/CRL checks.

---

## Earlier release notes (retained from the baseline)

# TLS Watch v4.6 — agent-only release

- Add independent connections to multiple v4.5 primary servers (up to 32).
- Web UI to enroll multiple primaries and inspect individual connectivity / queue metrics.
- Retain independent offline schedules and SQLite result queues for each primary.
- Group same-target checks due together so one handshake can feed independent queues.
- Automatically migrate existing v4.5 single-primary pairing and SQLite cache in place.
- Keep native Linux and Docker deployment options and host network mode.
- Keep LAN UI defaults on new installs; basic username `admin`, password `admin1234` (CHANGE IMMEDIATELY).
- No changes to primary; a future primary change can be released separately as v4.6.

Status: Python syntax / UI JavaScript checks and isolated core unit tests passed in the build environment. Flask/Docker runtime and two-primary live integration not executed in this environment. Test with two non-production primaries before production rollout.

## v4.6.1 (agent only)

- Connected primary controls: Pause/Resume, Re-pair using a new code for the *same agent record*, Retry, Disconnect with undelivered-results safety check.
- Admin Web UI can install/list/delete per-agent trusted target CA or self-signed X.509 PEM certificates. Verified TLS checks now use these trust anchors without relaxing hostname validation.
- Admin Web UI supports uploading a PEM certificate chain + matching private key, then enabling HTTPS on next restart; supports disabling HTTPS and deleting the keypair.
- Docker and native Linux use the same implementation and persistent `/data` or `data/` storage; primary protocol remains compatible with TLS Watch primary v4.5/v4.6.

## v4.6.2 (agent only)

- Add collapsible, keyboard-accessible panels for **Add another primary**, **Trust certificates**, and **Agent Admin UI · HTTPS**.
- Display installed trusted-target certificate count and admin HTTP(S) state in collapsed headings.
- Auto-expand initial pairing panel when no primaries have been configured.
- Preserve compatibility with TLS Watch Primary v4.6 and all v4.6.1 admin APIs and deployment models.
- No schema changes or new dependencies.
