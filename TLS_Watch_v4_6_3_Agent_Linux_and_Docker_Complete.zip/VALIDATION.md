# v4.6.3 validation — October 25, 2026

- Full unittest suite: **31 tests passed** on bundled Python 3.12, Flask 3.1.3,
  cryptography 47.0.0, Windows. Tests use temporary files and local sockets.
- All 16 existing baseline tests passed after repairing the malformed accordion
  test's page extraction; 15 new diagnostic tests passed.
- Real local TLS checks: private CA trust, unknown CA, expired certificate,
  hostname mismatch, IP SAN, single-label wildcard and deep wildcard rejection.
- Security/failure coverage: admin auth, disabled-auth fail-closed behavior,
  origin/custom-header protection, input validation, destination policy and mixed
  DNS responses, concurrency limits, DNS failure/timeout, TCP refusal, TLS failure/
  timeout, sanitized errors and trust-load failures.
- Exact shipped UI JavaScript: Node `--check` passed. HTML rollup structure,
  unique IDs and text-only diagnostic output checked by regression tests.
- Python source parse checks passed for every application/test module.
- Baseline function AST comparison: every existing agent function is unchanged
  except the primary-call User-Agent version identifier. New functionality is
  additive. Existing deployment scripts and Compose files are byte-identical.
- ZIP integrity, required contents, Unix script permissions and source-byte
  comparison checks passed during packaging. No data directory, credentials,
  private keys, generated certificates or local dependencies are included.

Not executed here: Docker build/container startup (Docker unavailable), native
Linux/service startup, live Primary v4.6 end-to-end enrollment/sync, or a browser
visual/interaction test. Existing primary/offline behavior is covered by local
regression tests and baseline source comparison. Target networking and trust
stores depend on the deployed host/container. See DIAGNOSTICS.md for limits.

Reproduce after installing requirements:
`python -m unittest discover -s tests -v`
