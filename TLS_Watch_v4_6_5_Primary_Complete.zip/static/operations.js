/* Operations UI: no persistent browser secrets; all server values use textContent. */
(() => {
  'use strict';
  const by = id => document.getElementById(id);
  let data = null, sites = [], loaded = false;
  const node = (tag,text) => { const n=document.createElement(tag); n.textContent=text; return n; };
  const status = text => { by('opsStatus').textContent=text; };
  const when = value => value?new Date(value).toLocaleString():'Not scheduled';
  const bytes = value => value===undefined?'Unavailable':(value/1073741824).toFixed(2)+' GB';
  const readable = value => String(value||'').replaceAll('_',' ');
  async function call(path,method='GET',body) {
    const options={method,headers:{'X-TLSWatch-Admin':'1'}};
    if(body!==undefined){options.headers['Content-Type']='application/json';options.body=JSON.stringify(body);}
    const r=await fetch(path,options); const d=await r.json(); if(!r.ok)throw Error(d.error||d.detail||'HTTP '+r.status); return d;
  }
  const id = () => Number(by('opsSite').value);
  function selectOptions(target,rows,initial){const sel=by(target),old=sel.value;sel.replaceChildren();if(initial!==undefined){const opt=node('option',initial);opt.value='';sel.appendChild(opt);}rows.forEach(row=>{const opt=node('option',row.name||row.url||row.version);opt.value=row.id;sel.appendChild(opt);});if([...sel.options].some(o=>o.value===old))sel.value=old;}
  function fillSite(){
    const s=sites.find(s=>s.id===id()); if(!s)return;
    by('opsProfile').value=s.profile_id||'';by('opsInterval').value=s.interval_hours;by('opsWarning').value=s.warning_days;by('opsNotify').checked=!!s.notifications_enabled;
    const c=data.alerts.find(a=>a.site_id===s.id)||{};by('opsAck').checked=!!c.acknowledged;by('opsNote').value=c.note||'';
    by('opsSnooze').value=c.snooze_until?new Date(new Date(c.snooze_until).getTime()-new Date(c.snooze_until).getTimezoneOffset()*60000).toISOString().slice(0,16):'';
    by('opsSiteState').textContent=s.url+'\nChecks every '+s.interval_hours+' hour'+(s.interval_hours===1?'':'s')+' · Expiration warning: '+s.warning_days+' days\nNext check: '+when(s.next_check_at)+'\nIncident: '+(c.acknowledged?'Acknowledged':'Not acknowledged')+(c.snooze_until?' · Snoozed until '+when(c.snooze_until):'')+(c.note?'\nNote: '+c.note:'');
  }
  async function load(){
    const [d,inventory,releases]=await Promise.all([call('/api/operations'),call('/api/sites'),call('/api/operations/releases')]);data=d;sites=inventory.sites;
    selectOptions('opsSite',sites);selectOptions('opsProfile',d.profiles,'Custom policy');selectOptions('opsReleaseId',releases.releases);
    by('opsProfiles').textContent=d.profiles.map(p=>p.name+' · Every '+p.interval_hours+' hours · Warning at '+p.warning_days+' days · Notifications '+(p.notifications_enabled?'on':'off')).join('\n')||'No reusable profiles yet.';fillSite();
    const smtp=d.smtp;by('opsSmtpEnabled').checked=smtp.enabled;by('opsSmtpHost').value=smtp.host;by('opsSmtpPort').value=smtp.port;by('opsSmtpMode').value=smtp.mode;by('opsSmtpUser').value=smtp.username;by('opsSmtpSender').value=smtp.sender;by('opsSmtpRecipients').value=smtp.recipients.join(', ');
    by('opsHistoryDays').value=d.retention.history_days;by('opsCheckCap').value=d.retention.checks_per_site;by('opsAuditDays').value=d.retention.audit_days;by('opsDeliveryDays').value=d.retention.delivery_days;
    by('opsMail').textContent=(smtp.password_configured?'SMTP password configured.':'SMTP password not set (needed for authenticated SMTP).')+'\n'+(d.mail.map(mail=>when(mail.created_at)+' · '+readable(mail.event)+' · '+mail.status+' · Attempts: '+mail.attempts+(mail.last_error?' · '+mail.last_error:'')).join('\n')||'No email deliveries yet.');
    const windows=by('opsWindows');windows.replaceChildren();d.maintenance.forEach(w=>{const row=node('p',w.name+' · '+w.starts_at+' → '+w.ends_at+' · '+(w.site_ids_json==='[]'?'All websites':w.site_ids_json));const btn=node('button','Remove');btn.type='button';btn.onclick=()=>perform(()=>call('/api/operations/maintenance/'+w.id,'DELETE'));row.appendChild(btn);windows.appendChild(row);});
    const agents=by('opsAgents');agents.replaceChildren();d.agents.forEach(a=>{const row=node('div','');row.className='ops-agent';row.appendChild(node('h4',a.name+' · v'+(a.version||'unknown')));const h=a.health||{},u=a.update_status||{};row.appendChild(node('pre','Last contact: '+when(a.last_seen_at)+'\nCPU: '+(h.cpu_percent===undefined?'Unavailable':h.cpu_percent+'%')+' · Memory available: '+bytes(h.memory_available_bytes)+' · Disk free: '+bytes(h.disk_free_bytes)+'\nOldest queued result: '+when(h.oldest_pending_at)+(h.queue_blocked?' · Queue limit reached; checks paused':'')+'\nSoftware update: '+(u.status||'idle')+(u.version?' · v'+u.version:'')+(u.message?'\n'+u.message:'')));['stage','install','cancel'].forEach(action=>{const btn=node('button',action==='stage'?'Stage release':action==='install'?'Install & restart native agent':'Cancel pending request');btn.type='button';btn.onclick=()=>{if(action==='install'&&!confirm('Install the selected signed release and restart '+a.name+'? Native agent opt-in is required.'))return;perform(()=>call('/api/operations/agents/'+a.id+'/update','POST',{action,release_id:by('opsReleaseId').value}));};row.appendChild(btn);});agents.appendChild(row);});
    by('opsAudit').textContent=d.audit.map(a=>a.occurred_at+' · '+a.actor+' · '+a.method+' '+a.path+' · '+a.action).join('\n');loaded=true;
  }
  async function perform(fn){try{status('Saving…');await fn();await load();status('Saved.');}catch(e){status(e.message);}}
  function submit(form,fn){by(form).addEventListener('submit',e=>{e.preventDefault();perform(fn);});}
  by('operationsPanel').addEventListener('toggle',()=>{if(by('operationsPanel').open&&!loaded)perform(async()=>{});});
  by('opsRefresh').onclick=()=>perform(async()=>{});
  by('opsSite').onchange=fillSite;
  by('opsProfile').onchange=()=>{const p=data.profiles.find(p=>p.id===Number(by('opsProfile').value));if(p){by('opsProfileName').value=p.name;by('opsProfileHours').value=p.interval_hours;by('opsProfileWarning').value=p.warning_days;by('opsProfileNotify').checked=!!p.notifications_enabled;by('opsInterval').value=p.interval_hours;by('opsWarning').value=p.warning_days;by('opsNotify').checked=!!p.notifications_enabled;}};
  submit('opsPolicy',()=>call('/api/operations/sites/'+id()+'/policy','PUT',{profile_id:by('opsProfile').value?Number(by('opsProfile').value):null,interval_hours:Number(by('opsInterval').value),warning_days:Number(by('opsWarning').value),notifications_enabled:by('opsNotify').checked}));
  submit('opsAlert',()=>call('/api/operations/sites/'+id()+'/alert','PUT',{acknowledged:by('opsAck').checked,snooze_until:by('opsSnooze').value?new Date(by('opsSnooze').value).toISOString():null,note:by('opsNote').value}));
  const profileBody=()=>({name:by('opsProfileName').value,interval_hours:Number(by('opsProfileHours').value),warning_days:Number(by('opsProfileWarning').value),notifications_enabled:by('opsProfileNotify').checked});
  submit('opsProfileForm',()=>call('/api/operations/profiles','POST',profileBody()));
  by('opsProfileEdit').onclick=()=>{if(!by('opsProfile').value)return status('Select a profile first.');perform(()=>call('/api/operations/profiles/'+by('opsProfile').value,'PUT',profileBody()));};
  by('opsProfileDelete').onclick=()=>{if(!by('opsProfile').value)return status('Select a profile first.');if(confirm('Delete this profile and retain assigned websites’ current policies?'))perform(()=>call('/api/operations/profiles/'+by('opsProfile').value,'DELETE'));};
  submit('opsSmtp',()=>call('/api/operations/smtp','PUT',{enabled:by('opsSmtpEnabled').checked,host:by('opsSmtpHost').value,port:Number(by('opsSmtpPort').value),mode:by('opsSmtpMode').value,username:by('opsSmtpUser').value,sender:by('opsSmtpSender').value,recipients:by('opsSmtpRecipients').value.split(',').map(s=>s.trim()).filter(Boolean)}));
  by('opsSmtpTest').onclick=()=>perform(()=>call('/api/operations/smtp/test','POST',{}));
  submit('opsMaintenance',()=>call('/api/operations/maintenance','POST',{name:by('opsMaintenanceName').value,starts_at:new Date(by('opsMaintenanceStart').value).toISOString(),ends_at:new Date(by('opsMaintenanceEnd').value).toISOString(),site_ids:by('opsMaintenanceGlobal').checked?[]:[id()]}));
  submit('opsRetention',()=>call('/api/operations/retention','PUT',{history_days:Number(by('opsHistoryDays').value),checks_per_site:Number(by('opsCheckCap').value),audit_days:Number(by('opsAuditDays').value),delivery_days:Number(by('opsDeliveryDays').value)}));
  submit('opsRelease',async()=>{const file=by('opsReleaseFile').files[0];if(!file||file.size>2200000)throw Error('Choose a signed release JSON smaller than 2.2 MB');return call('/api/operations/releases','POST',JSON.parse(await file.text()));});
})();
