# TLS Watch Primary v4.6.5

This is the complete primary component. Read the included UPGRADE.md before replacing an existing installation. FEATURE_GUIDE.md describes the new controls, limits and defaults; REMOTE_UPGRADE_TEST.md covers signed agent updates. Earlier usage documentation is retained below for deployment context; the v4.6.5 guides take precedence for new policy/retention behavior.

---

# TLS Watch v4.6 — Bulk Inventory Management (Primary)

This is the **primary-only v4.6 release**, paired with the separately released **v4.6 multi-primary Docker/Linux agent**. It builds directly on the final v4.5 primary (group website search, agent inventory filter and authenticated LAN defaults). There are no database changes.

## New: bulk actions in Live Inventory

Use the new checkboxes on website rows or the header checkbox to select all **visible / filtered** websites. Selected websites remain selected when changing group tabs, searches or agent/status filters; the toolbar displays how many are hidden by the current filter. Choose an action and click **Apply to selected**:

- Refresh certificate checks immediately (paused remote-agent targets are skipped; resume them first).
- Add to one or more groups **without removing** existing group memberships.
- Remove from selected groups, leaving other memberships intact.
- Reassign to the primary server or an enabled named remote agent.
- Pause or resume scheduled checks.
- Delete selected websites and their history (requires confirmation; irreversible).

The certificate details and history buttons are **blacked out/disabled** on checked rows, since they apply only to one website; those options are also disabled in the bulk action selector. Uncheck a website to restore those actions.

Bulk actions use one transaction after validating every website and group/agent. Actions are protected by the existing dashboard Basic authentication, **not** by read-only API keys. The maximum bulk selection per request is 500 sites. Existing per-website controls and agent integrations still work.

### Upgrade from v4.5

Stop the primary, back up `data/certificates.sqlite3`, extract the **complete primary** package over your installation, preserve `data/` and `.venv/`, and restart `START_TLS_WATCH.bat`. Hard-refresh the browser. The v4.6 agent package does not need to change for this update.

**Default LAN access remains enabled** (`0.0.0.0:8080`) with Basic authentication defaults `admin` / `admin1234`. **Change the default password immediately** and use HTTPS/VPN when connecting from outside a protected LAN.

---

# TLS Watch v4.5 — Distributed HTTPS certificate monitoring

## Group editor search + LAN-ready defaults (v4.5 build)

In **Live Inventory → + New group / Edit group**, use **Search websites** to narrow the ALL-site membership checklist by hostname or URL. Selections made before filtering remain selected even when hidden. **Select matches** and **Clear matches** affect only the visible entries when searching; saving includes every checked website. Search resets each time the modal opens. No DB schema change or remote-agent protocol change is required.

**Both the primary and agent start LAN-ready by default:** Primary listens on `0.0.0.0:8080`, Agent on `0.0.0.0:8899`; dashboard/setup HTTP Basic credentials default to **admin / admin1234**. **Change these credentials before exposing either service beyond a trusted, firewalled LAN. Basic auth is NOT encrypted over HTTP; use HTTPS reverse proxy or VPN for real deployments. Never port-forward either development Flask service onto the public Internet.**

Overrides: primary `BIND_HOST`, `PORT`, `APP_USERNAME`, `APP_PASSWORD` via environment or Windows starter; agent `AGENT_UI_BIND`, `AGENT_UI_PORT`, `AGENT_UI_USERNAME`, `AGENT_UI_PASSWORD` in `.env` (existing agent `.env` is preserved on upgrades). If you previously customized `START_TLS_WATCH.bat` with your own password, **keep that value when replacing the batch file**, or set `APP_USERNAME`/`APP_PASSWORD` as machine environment variables before launch. The primary's web/API host binding is independent of the agent's outbound certificate check networking.

**Primary:** Python 3.11+, Flask, SQLite (Windows or Linux). **Remote agent:** Docker on Linux or native Linux, with autonomous offline checking and durable backfill.

## Monitoring-location filtering (v4.5)

A **Monitoring location** dropdown has been added to **Live Inventory**, next to the existing website/group search and status filters. Select **All monitoring locations**, **Primary server**, or a remote agent by its configured name. Counts next to each location show the number of assigned websites; disabled/offline agents remain in the list. This filter combines with text search, group tabs/This Group scope, status filters, and sorting. The selection is preserved as certificate data refreshes. The top four dashboard cards continue to represent the complete inventory.

**Upgrade v4.5 primary only:** Stop Flask, back up `data/certificates.sqlite3`, overwrite the existing application files from the primary v4.5 ZIP, keep `.venv/` and `data/`, restart `START_TLS_WATCH.bat`, then reload the browser (Ctrl+F5). **No database migration is needed for this change.** The existing v4.5 Docker/Linux remote agents remain compatible and do not need an update.

## What's new in v4.5 — offline resilience

- A paired **v4.5 remote agent synchronizes its full assigned website inventory** from the primary. It keeps the inventory, latest check schedule, and resulting check history in local SQLite (`agent_cache.sqlite3`).
- Once synchronized, a remote agent **runs scheduled certificate checks even if the primary is down**. It records each completed result with the **actual UTC check timestamp**, schedules the following calendar day's randomized check locally, and enqueues the result before attempting any upload.
- When the primary becomes reachable again, the agent **automatically replays results in chronological batches**. Primary response ACKs are idempotent (`agent_id` + `result_id`) and are persisted in the primary SQLite database. If the response is lost after the primary committed a result, retrying produces `duplicate` instead of a second history record / webhook event.
- The primary imports delayed results using the agent's **original check time**, updates certificate/check history, and applies relevant webhook transitions. **Out-of-order late uploads** are added to history without overriding a newer current result or generating reverse-order alerts.
- Primary **Monitoring agents** now reports last sync, last agent check, and most recently reported pending queue depth. Agent UI shows assignment count, queued result count, rejected uploads, last check, and connection/sync state.
- v4.4 agents continue working against v4.5 primary using legacy leased `/agent/v1/poll` and `/agent/v1/result` APIs. To gain offline checking, update the agent to v4.5.

**Limitations:** An agent must have synchronized with the primary at least once to know what to monitor offline. Changes to assignments, pauses, and deletions made while the primary is unreachable cannot reach an offline agent until reconnection. Its revoked credentials cannot be discovered offline. Previously queued results for reassigned/deleted websites are retained locally with a **rejected** status instead of silently discarded. Primary dashboard data remains stale during an outage until replay completes. Cached results are stored persistently but are not a replacement for disk backups. Results older than 365 days cannot be backfilled.

### Upgrade an existing primary (Windows)

1. **Stop the primary**, then back up `data/certificates.sqlite3` (and its WAL files if present, only while running; safest is after shutdown).
2. Replace the application files with this v4.5 package, **retaining your `.venv/` and `data/` directories**.
3. Run `START_TLS_WATCH.bat`. The v4.5 SQLite schema additions are applied automatically. Existing websites, groups, API key and webhook configuration remain unchanged.
4. Stop the old agent and install the **v4.5 Linux/Docker agent** separately at the remote location. Preserve the agent's `data/agent.json` pairing file / Docker volume. The new local SQLite database is created at first startup and synchronized with the primary.
5. After pairing/sync, use the agent setup/status UI on port 8899 to verify **Assigned websites**, **Queued results**, and **Last inventory sync**.

### Networking and storage

The remote agent initiates outgoing HTTPS calls to the primary; the primary never opens connections into the remote LAN. Use an HTTPS endpoint for the primary (prefer VPN or HTTPS reverse proxy with a trusted CA). The agent connects to the **real LAN DNS and routes** of its Linux environment for private targets. It never needs the remote LAN's HTTPS targets to be publicly reachable. The primary's `ALLOW_PRIVATE_TARGETS=true` default remains unchanged. Agent results, pairing credentials and internal URL inventory are sensitive: protect `agent.json`, `agent_cache.sqlite3` and the primary's database.

The primary and remote agent must be upgraded separately. **The primary server must keep running to handle API/webhook/reporting functions**, while the v4.5 agent performs its assigned TLS checks on its own during primary outages. A reconnected agent processes queued results at a bounded rate (15 results per poll by default).

See `api.md` for the new authenticated agent synchronization and batch-upload endpoints.

---

# TLS Watch — Existing features from v4.3 / v4.4

**Python 3.11+ · Flask · SQLite · no Docker required.** This version is an in-place update of the **v4.2** certificate monitor. It retains the certificate details viewer, daily randomized checks, persistent site list, pause/delete controls, CSV export, and the corrected Healthy Certificates count.

## Windows installation / upgrade

1. If TLS Watch is currently running, stop it using `Ctrl+C`.
2. Extract the ZIP contents into your existing `F:\Code\TLS_Watch_Flask\` directory, replacing files. **Do not delete `.venv` or `data/`.** The site's database and certificate history stay in `data/certificates.sqlite3`.
3. Double-click `START_TLS_WATCH.bat` to run. If this is a new install, the batch file creates a virtual environment and installs requirements. If an existing `.venv` already works, it will reuse it.
4. Open <http://127.0.0.1:8080/> (or your LAN IP on port 8080). The **Live Inventory** now has group tabs (beginning with **ALL**), a **+ New group** button, and a **This Group / All Websites** search-scope selector. Expand **API access & outbound webhooks** for integration settings.
5. Leave the Python window open for periodic certificate checks and scheduled webhook sends. Closing the browser does not stop the service.

For manual startup, activate your Python venv, `python -m pip install -r requirements.txt`, then `python app.py`.

## New in v4.3: history, bulk inventory import/export, multi-destination webhooks and stale monitoring

**These changes build on v4.2 without replacing your existing database, API key, website list, groups, or configured default webhook.** The migration runs automatically when you restart TLS Watch. Take a backup of `data/certificates.sqlite3` before upgrading.

- **Certificate history:** Each different observed leaf certificate is retained (issuer, issue/expiration, first/last observed and original PEM). Select **History** in a website's Actions column to compare historical versions and download past PEMs. A renewal can generate `certificate_renewed`, `certificate_issuer_changed`, or `certificate_expiration_shortened` events. On startup, v4.3 captures the most recent v4.2 certificate as the first historical snapshot; older versions that v4.2 did not store cannot be reconstructed.
- **Check history:** Saves each successful/failed TLS attempt including timestamp, trust verification and errors. The 1,000 most recent checks per website are retained. This begins when v4.3 is installed; earlier individual checks are not recoverable.
- **Bulk import/backup:** Use **Import CSV/JSON** or export **Inventory CSV** / **Backup JSON** from the Live Inventory panel. CSV header: `URL,Groups,Paused`; separate multiple groups with semicolons. JSON uses `{"groups":["Production"], "websites":[{"url":"https://example.com","paused":false,"groups":["Production"]}]}`. Import creates new groups/sites, merges imported memberships into existing sites, applies the imported paused state and preserves existing certificate/history records. Export deliberately **excludes credentials and private secrets**.
- **Multiple webhook destinations:** The existing webhook stays the **Default webhook** for all sites, unchanged. Under **Additional group-specific webhooks** add/edit/delete independent destinations, each with its own URL, events, signing secret, TLS transport exceptions, and optional group selections. No groups selected means ALL. Each event is sent once per matching destination; multiple memberships do not duplicate delivery. A deleted group's scoped webhook **fails closed** rather than reverting to ALL.
- **Stale monitoring detection:** An active website without a successful **certificate retrieval** for more than 24h is flagged WARNING; more than 48h is CRITICAL. Paused sites are excluded. Stale sites enter **Needs Attention** independently of certificate expiry and appear on the API with `stale_status` and `last_successful_at`. Two new webhook events are `monitoring_stale_warning` and `monitoring_stale_critical`. The configured daily randomized scheduler sometimes produces intervals longer than 24 hours even when working correctly, so a 24h stale warning alone is not proof of a system failure.
- **Read-only API:** `GET /api/v1/certificates/{siteId}/history` and scoped `GET /api/v1/groups/{groupId}/certificates/{siteId}/history`; `/api/v1/summary` adds `stale_warning` and `stale_critical` counters. Existing group/expiry queries continue working.
- **Private certificate targets remain ON by default** (`ALLOW_PRIVATE_TARGETS=true`). The outbound webhook HTTP/private/self-signed exceptions remain independent and disabled by default per destination.

See [`api.md`](api.md) and [`TLS_Watch_v4_3.postman_collection.json`](TLS_Watch_v4_3.postman_collection.json) for the complete API and webhook reference.

## New in v4.2: persistent inventory groups

- **ALL** is the permanent first tab, containing every monitored website; it cannot be renamed or deleted.
- Click **+ New group**, enter a name, then check any websites from the **entire ALL inventory**. A site may belong to **multiple groups** simultaneously (e.g. `Production`, `Customer A`, and `Renewals`). Group assignments are stored in the existing SQLite database.
- On any group tab, click **Edit group** to rename it, select/deselect any websites, or delete the group. Deleting a **group never deletes the websites** or alters their certificate check schedules.
- In the **Actions** column, click the new grid/groups icon on a website to add/remove membership in **multiple groups** at once.
- The search-scope selector beside the search field provides **All Websites** and **This Group**. Choosing a group tab defaults the scope to **This Group**, but you can choose All Websites without changing the current tab. The separate status filter still offers active, paused, and Needs Attention.
- Adding a new URL while viewing a group automatically assigns that new URL to the visible group. The website still appears in ALL, and automatic certificate checks are shared across groups.
- Group membership does not change the global dashboard counters or duplicate automatic checks. In v4.3, group membership **does** determine which additional group-scoped webhooks can receive events.

### Group-aware API

All existing `/api/v1/...` GET endpoints keep working and now accept `?group=<id>` (or the group name, case-insensitively). The group listing reports stable numeric IDs and per-group site counts. A missing/deleted group returns HTTP **404**, rather than silently defaulting to ALL.

```http
GET /api/v1/groups
GET /api/v1/summary?group=2
GET /api/v1/certificates?group=2&range=0-30
GET /api/v1/certificates/expiring?group=2&within=60
GET /api/v1/certificates/needs-attention?group=2
GET /api/v1/certificates/123?group=2
```

There are also equivalent group-scoped paths, e.g. `GET /api/v1/groups/2/certificates?range=90%2B` and `GET /api/v1/groups/2/certificates/needs-attention`. Group API requests require the **same read-only API key**, and return only the same certificates as the equivalent all-sites API intersected with the group's membership. The Postman collection includes the new requests and a `groupId` variable. See [api.md](api.md).

**Security change:** Monitored private/internal HTTPS targets are **enabled by default** (`ALLOW_PRIVATE_TARGETS=true`). Only run TLS Watch in trusted environments; allowing private targets increases the reach of server-initiated network connections. Outbound webhook HTTP/private/self-signed allowances remain separate opt-ins and are unchanged.

### API key (read-only)

Open the integrations accordion and click **Generate / rotate API key**. Copy the key when shown: TLS Watch stores **only its SHA-256 hash**, and the actual key is not retrievable later. Rotating immediately invalidates the previous key; **Revoke** disables remote queries. The key permits **GET only** on `/api/v1/...` routes. It cannot edit websites, settings, or webhook configuration.

Supply either HTTP header:

```http
X-API-Key: tlsw_PASTE_YOUR_KEY
```

or:

```http
Authorization: Bearer tlsw_PASTE_YOUR_KEY
```

#### API endpoints

| Method and path | Result |
|---|---|
| `GET /api/v1/summary` | Summary counters: total, healthy (>90 days), expiring ≤60, needs attention |
| `GET /api/v1/certificates` | All certificate/site records |
| `GET /api/v1/certificates?range=expired` | Certificates that have expired (`days_left < 0`) |
| `GET /api/v1/certificates?range=0-30` | 0–30 days remaining |
| `GET /api/v1/certificates?range=31-60` | 31–60 days remaining |
| `GET /api/v1/certificates?range=61-90` | 61–90 days remaining |
| `GET /api/v1/certificates?range=90%2B` | More than 90 days remaining (green/healthy) |
| `GET /api/v1/certificates/expiring?within=30` | All certificates with `days_left ≤ 30`, including expired |
| `GET /api/v1/certificates/expiring?within=60` | All certificates with `days_left ≤ 60`, including expired |
| `GET /api/v1/certificates/expiring?within=90` | All certificates with `days_left ≤ 90`, including expired |
| `GET /api/v1/certificates/needs-attention` | Sites with **check failure**, **TLS trust/hostname verification failure**, **≤30 days** remaining, or **>24 hours without a successful certificate retrieval** |
| `GET /api/v1/certificates/123` | Certificate/site record by database ID |

**Healthy and Needs Attention can overlap**, exactly as in the dashboard: e.g., a certificate expiring in 150 days but failing trust verification is counted as healthy by **expiration** and also needs attention for **validation**.

Day ranges use **days remaining at the last check**, not a constantly recalculated countdown. Records expose issuer, issued/expiry dates, days remaining, check timestamps, paused status, TLS validation and latest errors. PEM and secrets are **not** returned by these endpoints.

Windows PowerShell example:

```powershell
$headers = @{ 'X-API-Key' = 'tlsw_PASTE_YOUR_KEY' }
Invoke-RestMethod -Headers $headers -Uri 'http://127.0.0.1:8080/api/v1/certificates/needs-attention'
Invoke-RestMethod -Headers $headers -Uri 'http://127.0.0.1:8080/api/v1/certificates?range=90%2B'
```

The `90+` filter is URL-encoded `%2B` above; the API also accepts a literal plus sign as a convenience.

### Outbound webhooks

Expand the same integrations accordion:

1. Enter a webhook URL (HTTPS by default, or HTTP for local testing). For the included standalone **TLS Webhook Viewer** on the same PC, use `http://127.0.0.1:8888/webhook`.
2. Local HTTP: check **Allow HTTP destinations** and **Allow localhost and private network addresses**. Self-signed HTTPS: check **Accept self-signed / untrusted HTTPS certificates**. All three opt-ins default to off and apply only to outbound webhooks.
3. Select which events should be sent; set **Enable webhook delivery**.
4. Click **Save webhook**. On the first save, TLS Watch generates an HMAC signing secret and displays it **once**. Copy it to the receiving service. You can rotate the signing secret, which invalidates the previous one.
5. Click **Send test** and examine **Recent webhook deliveries**. A test event is delivered even if the `test` type is not selected in your event preferences.

Webhook triggers (checkboxes):

| Event name | When it occurs |
|---|---|
| `expiration_90` | Observed crossing to ≤90 days |
| `expiration_60` | Observed crossing to ≤60 days |
| `expiration_30` | Observed crossing to ≤30 days |
| `certificate_expired` | Observed crossing from unexpired to expired |
| `tls_invalid` | Trust/hostname validation first fails |
| `check_failed` | First failure after a working/unknown check |
| `recovered` | Prior failed/untrusted check succeeds and validates |
| `certificate_changed` | Leaf certificate PEM differs from the previously captured certificate |
| `needs_attention` | Site newly enters Needs Attention state (including stale >24h) |
| `attention_cleared` | Site leaves Needs Attention (valid TLS, no check error, and >30 days) |

Events are **transition-based**, rather than sent every day for the same condition. On an initial observation, only the most urgent applicable expiration threshold is emitted. If multiple thresholds are crossed between subsequent checks, each crossed threshold is emitted (according to selected event types). Failures that prevent retrieval of a new certificate preserve the previously observed certificate.

Every webhook is a JSON `POST` with headers:

```http
Content-Type: application/json
X-TLSWatch-Event: expiration_30
X-TLSWatch-Delivery: <unique-event-id>
X-TLSWatch-Timestamp: 2026-10-24T12:00:00Z
X-TLSWatch-Signature: sha256=<64-character-hex-digest>
```

Example body:

```json
{
  "event_id": "849c4a7c-8d7e-49e0-9160-ef0c2ac8a5b9",
  "event": "expiration_30",
  "occurred_at": "2026-10-24T12:00:00Z",
  "site": {
    "id": 3,
    "url": "https://example.com",
    "hostname": "example.com",
    "port": 443,
    "issuer": "Example CA",
    "issued_at": "2026-08-01T00:00:00Z",
    "expires_at": "2026-11-15T00:00:00Z",
    "days_left": 22,
    "last_checked_at": "2026-10-24T12:00:00Z",
    "tls_verified": true,
    "needs_attention": true
  },
  "previous": {"days_left": 31, "last_error": null, "tls_verified": true}
}
```

The actual `site` object also includes the other standard certificate fields. Verify the signature by computing **HMAC-SHA256(signing_secret, exact UTF-8 request body bytes)** and comparing to the hex digest after `sha256=` with a constant-time comparison. Keep delivery IDs to ignore duplicates. The event ID is stable across retries.

Delivery details:

- The event payload and delivery state are stored in SQLite, surviving Python restarts.
- Delivery is attempted automatically by the in-process scheduler (about every 10 seconds).
- A successful delivery requires HTTP **2xx**. Other responses / TLS / network errors are retried twice (after about 1 minute and then 5 minutes); after three attempts it is marked failed.
- Failed attempts appear in **Recent webhook deliveries** with the error. Sending to a new URL or disabling webhooks cancels pending deliveries to the former destination. Delivery history is retained.
- Outbound URLs default to **HTTPS, public addresses, and standard CA/hostname verification**. HTTP, private/localhost destinations, and self-signed/untrusted HTTPS certificates each require a separate explicit opt-in. Redirects are never followed and target IPs are vetted and pinned. Self-signed mode disables outbound webhook TLS identity checks; HTTP transmits payloads in cleartext.
- These webhook transport settings are **independent** of `ALLOW_PRIVATE_TARGETS`, which still controls monitored HTTPS certificate sites only.
- A rotated signing secret or target URL can invalidate already-in-progress requests; rotate receiver secrets carefully.

### Postman collection (ready to import)

The package includes **[`TLS_Watch_v4.postman_collection.json`](TLS_Watch_v4.postman_collection.json)**, a Postman Collection v2.1 with every read-only API endpoint (including 30/60/90-day expiration filters and **Needs Attention**) and an **optional** folder for local administrative requests and webhook testing.

1. In Postman select **Import → Files** and choose `TLS_Watch_v4.postman_collection.json`.
2. In the imported collection's **Variables**, keep `baseUrl` as `http://127.0.0.1:8080` for checks on this PC, or change to your secure HTTPS endpoint for remote access.
3. Copy the API key generated in the dashboard into the `apiKey` variable. Set `siteId` from a record returned by **All certificates**.
4. Run the requests in **Read-only monitoring API — X-API-Key**. The `90+` request already URL-encodes its plus sign as `%2B`.
5. **Optional admin folder**: only for local/dashboard-authorized access; it does *not* accept the API key. Fill `adminUsername` / `adminPassword` if dashboard Basic authentication is configured, and `webhookUrl` for webhook requests. Avoid invoking the destructive **Revoke** or **Rotate** operations unintentionally.

The collection intentionally ships with **no active API keys, usernames, passwords, or webhook signing secrets**. Keep those values private when sharing or exporting Postman collections.

**Detailed API and webhook specification:** See [`api.md`](api.md) for the Postman setup, request/response schemas, filter boundaries, HMAC validation examples, event semantics, retry behavior, and remote-access guidance.

## Network and security

By default TLS Watch binds to **all local interfaces** at `0.0.0.0:8080`. API keys authenticate `/api/v1` but cannot make the service reachable over the network by themselves. For remote use, configure a trusted reverse proxy providing **HTTPS** and firewall rules; the reverse proxy can forward to `127.0.0.1:8080`. The built-in Flask development server should **not** be published directly to the Internet.

For use from another PC on your LAN, change `APP_USERNAME` and `APP_PASSWORD` and use a proper HTTPS reverse proxy and production WSGI hosting. When no UI credentials are configured, **non-local dashboard/admin requests are denied**; the read-only v1 API continues to accept valid API keys remotely, subject to your network routing and firewall. Do not send Basic credentials or API keys over plain public HTTP.

Environment variables:

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `8080` | HTTP listen port |
| `BIND_HOST` | `0.0.0.0` | Listen address (keep loopback behind a proxy) |
| `APP_USERNAME` / `APP_PASSWORD` | `admin` / `admin1234` | Optional HTTP Basic credentials for dashboard/admin |
| `APP_TIMEZONE` | `America/New_York` | Timezone for per-site randomized checks |
| `DB_PATH` | `data/certificates.sqlite3` | Database path (also stores API-key hash and webhook settings/events) |
| `TLS_TIMEOUT_SECONDS` | `7` | TLS connection timeout |
| `MAX_CHECK_WORKERS` | `6` | Max concurrent certificate checks |
| `ALLOW_PRIVATE_TARGETS` | `true` | Allow internal monitored HTTPS sites; webhook options are configured separately in the UI |

Keep **one Python process** running. Each active site gets its first certificate check when added, then a new independently randomized time on the following local calendar day; overdue checks run after restart. Paused sites skip scheduled checks. The browser can be closed without stopping the server.

## Validation

Run automated tests once Flask is installed:

```bash
python -m pip install pytest
python -m pytest -q
```

The pure helper tests also exercise signed webhook POST delivery against a local TLS listener, URL validation, thresholds, and event deduplication. The existing certificate-monitoring suite and JavaScript dashboard count tests are included.

## TLS Watch v4.3 local HTTP webhook test

Run the separate `TLS_Webhook_Viewer` Flask app on `127.0.0.1:8888`. In TLS Watch, save:

- URL: `http://127.0.0.1:8888/webhook`
- **Allow HTTP destinations:** ON
- **Allow localhost and private network addresses:** ON
- **Accept self-signed / untrusted HTTPS certificates:** OFF (not needed for HTTP)

Then click **Send test** and open `http://127.0.0.1:8888/`. The full API and transport documentation is in `api.md`.

---

# TLS Watch v4.4 — Distributed Remote Agents

v4.4 extends the existing Python/Flask primary with **outbound-only remote agents**. The central primary continues to own the SQLite database, website groups, randomized daily schedule, X.509 history, GET APIs, webhooks, and alerts. Sites are monitored once per day, **from the chosen execution location**.

## How remote checks work

- A remote agent makes **outbound** HTTPS requests to the primary; it needs no inbound network exposure on the branch/customer LAN.
- The primary authenticates each agent with a separate, randomly generated bearer token. Pairing uses a one-time code valid for 15 minutes. Agents do **not** receive the primary API key or webhook secrets.
- An agent polls approximately every 15 seconds for due work, makes the TLS connection **from its own LAN**, and sends the observed PEM and verification status back to the primary.
- The primary parses certificate issuer/validity from the returned PEM, calculates days remaining, records check/certificate history and triggers existing event webhooks.
- Leases prevent concurrent delivery; failed or interrupted tasks are retried after a four-minute lease timeout. Late or duplicate results are rejected. If an agent is offline, assigned websites remain pending; the primary will *not* silently check them from another network.
- Reassign a website to `Primary server (local)` from its new Actions > monitoring agent button to run checks on the primary again.

## Primary installation (Windows/Python; no Docker needed)

Update the primary exactly as prior versions: stop it, **back up `data/certificates.sqlite3`**, extract these files over your existing TLS Watch directory, **preserve `data/` and `.venv/`**, then run `START_TLS_WATCH.bat`. Open `http://localhost:8080`.

Open **Monitoring agents**, expand the accordion, choose a descriptive name (e.g. `Branch-A`), click **Create & generate pairing code**, and copy the code shown. To add websites, select the remote agent from **Check using**. For an existing website, click the new **monitoring agent** icon under Actions.

v4.4 retains `ALLOW_PRIVATE_TARGETS=true` by default, and retains all v4.3 feature behavior for centrally monitored sites.

## Remote installation (Docker)

Copy the **agent/** folder to the machine on the other LAN and run:

```sh
cd agent
docker compose up -d --build
```

Open **http://localhost:8899** *on the Docker host*. The Compose file makes the setup UI available on **0.0.0.0:8899** using HTTP Basic authentication. Change default credentials and restrict the port to your trusted LAN. Enter:

- **Primary URL**: The primary's externally reachable HTTPS origin, e.g. `https://tlswatch.example.net` (not `localhost:8080` unless the container itself hosts the primary).
- **One-time pairing code**: The code created in the primary UI.
- **Optional custom primary CA**: Paste the signing CA PEM if your *primary's HTTPS endpoint* uses a private PKI. HTTPS verification remains on. For a trusted test lab only, HTTP can be explicitly enabled.

Click **Connect to primary**. Within 15–30 seconds its status should show ONLINE at the primary. An assigned site receives its first check almost immediately, assuming the remote LAN can resolve and reach it.

### Connectivity and security

The **remote agent must reach the primary's HTTPS URL** through an authenticated VPN/reverse proxy, a private routed network, or a securely published HTTPS service. Do **not** expose Flask's development server directly to the Internet. A TLS-terminating reverse proxy should forward `/agent/v1/` to the Flask app and pass its `Authorization: Bearer ...` header without replacing it. Other dashboard routes should remain restricted or protected with `APP_USERNAME` + `APP_PASSWORD`.

The agent connects to internal hosts on their configured TLS ports using the **agent container's DNS/network**. A hostname like `192.168.1.20` works when the agent can route to that address; `127.0.0.1` inside Docker refers to the **container**, not the Docker host. The certificate is validated against the hostname entered in TLS Watch; self-signed/untrusted server certificates can still be inspected but are flagged as untrusted (the agent does not globally disable their verification).

The agent saves its pairing token in a Docker-managed persistent volume (`tlswatch-agent-data`), with file permissions 0600 where supported. Back up the primary SQLite database separately. The agent setup UI uses Basic authentication by default; **change its default credentials** and use HTTPS/VPN when the network is not fully trusted. Agent token revocation: **Disable** or **Delete** the agent from the primary; reconnecting requires a fresh pairing code. The primary list marks agents offline after ~90 seconds without a heartbeat.

Note: To deploy the agent on a Linux/Windows host **without** Docker, install Flask and run `python agent.py` with `AGENT_DATA_DIR` set to a writable directory. Its UI listens on 8899; protect/bind its exposure appropriately.

## Testing and deployment notes

Use `python -m pytest tests/test_agents.py -q` in the primary's Python environment to test pairing, authorization, leased tasks, certificate/result storage, and reassignment. Existing test files remain included. This is a single-primary-process SQLite design; keep `use_reloader=False` and do not run multiple scheduler-enabled Flask workers against the same database.

**Backup scope note:** JSON/CSV inventory exports now include the *name* of each assigned monitoring agent for reference. They intentionally do not include agent bearer credentials or pairing codes. Importing a backup does not automatically re-pair agents or reassign websites to potentially unrelated agents on a different primary; create/pair agents and assign sites in the dashboard after restore.
