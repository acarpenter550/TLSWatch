"""Administrator-approved distribution of pinned-key signed agent packages."""
import json
import os
import uuid
from flask import jsonify
import updates


def migrate(con):
    con.executescript('''CREATE TABLE IF NOT EXISTS agent_releases (
      id TEXT PRIMARY KEY, version TEXT NOT NULL, package_json TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS agent_update_commands (
      agent_id INTEGER PRIMARY KEY REFERENCES monitoring_agents(id) ON DELETE CASCADE,
      command_id TEXT NOT NULL, release_id TEXT NOT NULL REFERENCES agent_releases(id),
      action TEXT NOT NULL, created_at TEXT NOT NULL);
    ''')


def register(m):
    app=m.app

    @app.get('/api/operations/releases')
    def releases():
        with m.db() as con:
            return jsonify({'releases':[dict(r) for r in con.execute('SELECT id,version,created_at FROM agent_releases ORDER BY created_at DESC LIMIT 20')],
                            'signing_key_configured':bool(os.environ.get('UPDATE_PUBLIC_KEY'))})

    @app.post('/api/operations/releases')
    def release_add():
        package=m.json_body()
        try:
            updates.verify(package,os.environ.get('UPDATE_PUBLIC_KEY',''))
            rid=package['manifest']['sha256']
            with m.db() as con:
                con.execute('INSERT OR IGNORE INTO agent_releases VALUES (?,?,?,?)',
                            (rid,package['manifest']['version'],json.dumps(package),m.utc_iso(m.utcnow())))
            return jsonify({'ok':True,'id':rid,'version':package['manifest']['version']})
        except Exception:
            return m.error(400,'Invalid release, missing pinned public key, or signature verification failed')

    @app.post('/api/operations/agents/<int:aid>/update')
    def request_update(aid):
        body=m.json_body() or {}
        action=body.get('action','stage')
        if action not in ('stage','install','cancel'): return m.error(400,'Choose stage, install or cancel')
        with m.db() as con:
            agent=con.execute('SELECT * FROM monitoring_agents WHERE id=? AND enabled=1',(aid,)).fetchone()
            if not agent: return m.error(404,'Enabled agent not found')
            if action=='cancel':
                con.execute('DELETE FROM agent_update_commands WHERE agent_id=?',(aid,))
                return jsonify({'ok':True})
            rid=body.get('release_id')
            if not isinstance(rid,str): return m.error(400,'Select a release')
            release=con.execute('SELECT * FROM agent_releases WHERE id=?',(rid,)).fetchone()
            if not release: return m.error(404,'Release not found')
            try: agent_version=updates.version_tuple(agent['version'])
            except ValueError: agent_version=(0,0,0)
            if agent_version<(4,6,5):
                return m.error(409,'Agent v4.6.5 bootstrap required; manually upgrade older agents first')
            if updates.version_tuple(release['version'])<agent_version: return m.error(409,'Downgrades are blocked')
            command=uuid.uuid4().hex
            con.execute('INSERT OR REPLACE INTO agent_update_commands VALUES (?,?,?,?,?)',(aid,command,rid,action,m.utc_iso(m.utcnow())))
        return jsonify({'ok':True,'command_id':command})

    @app.post('/agent/v1/update')
    def download_update():
        aid=m.authenticated_agent_id()
        body=m.json_body() or {}
        with m.db() as con:
            command=con.execute('SELECT * FROM agent_update_commands WHERE agent_id=? AND command_id=?',(aid,body.get('command_id'))).fetchone()
            if not command: return m.error(404,'No update authorized for this agent')
            row=con.execute('SELECT package_json FROM agent_releases WHERE id=?',(command['release_id'],)).fetchone()
        response=jsonify(json.loads(row[0]))
        response.headers['Cache-Control']='no-store'
        return response


def sync_command(con,aid,status):
    if isinstance(status,dict) and len(json.dumps(status))<=2000:
        # Restrict reflected fields to a public status schema.
        clean={k:str(status[k])[:200] for k in ('status','version','command_id','message') if k in status}
        con.execute('UPDATE monitoring_agents SET update_status_json=? WHERE id=?',(json.dumps(clean),aid))
        if clean.get('status') in ('installed','staged','failed','blocked'):
            con.execute('DELETE FROM agent_update_commands WHERE agent_id=? AND command_id=?',(aid,clean.get('command_id')))
    row=con.execute('SELECT c.command_id,c.action,c.release_id,r.version FROM agent_update_commands c JOIN agent_releases r ON r.id=c.release_id WHERE c.agent_id=?',(aid,)).fetchone()
    return dict(row) if row else None
