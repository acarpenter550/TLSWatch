# Baseline comparison

Source: `TLS_Watch_v4_6_Primary_Complete_Bulk_Agent_Overview.zip`

SHA-256: `68b444e03060087a2d2b8054308b56ba2a45e08fb093879feb098e08f237d365`

| File | Status |
|---|---|
| .dockerignore | Added |
| .env.example | Added |
| DEFERRED.md | Added |
| Dockerfile | Added |
| FEATURE_GUIDE.md | Added |
| README.md | Updated |
| RELEASE_NOTES.md | Added |
| REMOTE_UPGRADE_TEST.md | Added |
| START_TLS_WATCH.bat | Unchanged |
| TLS_Watch_v4_3.postman_collection.json | Unchanged |
| TLS_Watch_v4_5.postman_collection.json | Unchanged |
| TLS_Watch_v4_6.postman_collection.json | Unchanged |
| UPGRADE.md | Added |
| VALIDATION.md | Added |
| VERSION | Updated |
| api.md | Updated |
| app.py | Updated |
| compose.yaml | Added |
| integrations.py | Updated |
| operations.py | Added |
| release_routes.py | Added |
| requirements-dev.txt | Added |
| requirements.txt | Unchanged |
| start_tls_watch.sh | Updated |
| static/app.js | Updated |
| static/index.html | Updated |
| static/operations.html | Added |
| static/operations.js | Added |
| static/styles.css | Updated |
| tests/conftest.py | Unchanged |
| tests/test_agent_filter.cjs | Unchanged |
| tests/test_agents.py | Unchanged |
| tests/test_api_webhooks.py | Unchanged |
| tests/test_app.py | Unchanged |
| tests/test_bulk_actions.py | Unchanged |
| tests/test_dashboard_stats.cjs | Unchanged |
| tests/test_group_filters.cjs | Unchanged |
| tests/test_group_modal_search.cjs | Unchanged |
| tests/test_groups.py | Unchanged |
| tests/test_integrations.py | Unchanged |
| tests/test_offline_sync.py | Updated |
| tests/test_postman_collection.py | Unchanged |
| tests/test_v43_features.py | Unchanged |
| tests/test_v465_chain.py | Added |
| tests/test_v465_integration.py | Added |
| tests/test_v465_operations.py | Added |
| tests/test_v465_ui.py | Added |
| tlsprobe.py | Added |
| tools/sign_agent_release.py | Added |
| updates.py | Added |
