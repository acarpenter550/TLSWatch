#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
if [[ -f .env ]]; then set -a; source .env; set +a; fi
export BIND_HOST="${BIND_HOST:-0.0.0.0}"
export PORT="${PORT:-8080}"
export APP_USERNAME="${APP_USERNAME:-admin}"
export APP_PASSWORD="${APP_PASSWORD:-admin1234}"
export ALLOW_PRIVATE_TARGETS="${ALLOW_PRIVATE_TARGETS:-true}"
if [ ! -f .venv/bin/python ]; then
  python3 -m venv .venv
fi
if [ ! -f .venv/tls_watch_ready.txt ]; then
  .venv/bin/python -m pip install -r requirements.txt
  touch .venv/tls_watch_ready.txt
fi
echo 'Open http://localhost:8080 or http://YOUR-LAN-IP:8080; keep running for scheduled checks.'
exec .venv/bin/python app.py
