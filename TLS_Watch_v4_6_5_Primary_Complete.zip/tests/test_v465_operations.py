"""Policies, notification suppression/delivery, retention, audit and health."""
from datetime import timedelta
import json
from unittest.mock import MagicMock
import pytest
import app as m
import operations as ops

HEADER={'X-TLSWatch-Admin':'1'}


@pytest.fixture
def env(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'DB_PATH',tmp_path/'primary.sqlite3')
    monkeypatch.setattr(m,'AUTH_USER','')
    monkeypatch.setattr(m,'AUTH_PASSWORD','')
    monkeypatch.setattr(m,'enqueue',lambda sid: True)
    m.init_db()
    client=m.app.test_client()
    client.post('/api/sites',json={'urls':'https://one.example\nhttps://two.example'})
    sites=client.get('/api/sites').json['sites']
    return client,[s['id'] for s in sites]


def test_policy_profiles_propagation_and_migration(env):
    c,ids=env
    r=c.post('/api/operations/profiles',json={'name':'Hourly production','interval_hours':1,'warning_days':45},headers=HEADER)
    assert r.status_code==200,r.json
    pid=r.json['id']
    for sid in ids:
        assert c.put(f'/api/operations/sites/{sid}/policy',json={'profile_id':pid},headers=HEADER).status_code==200
    assert c.put(f'/api/operations/profiles/{pid}',json={'name':'Production','interval_hours':6,'warning_days':60,'notifications_enabled':False},headers=HEADER).status_code==200
    m.init_db()
    sites=c.get('/api/sites').json['sites']
    assert all(s['interval_hours']==6 and s['warning_days']==60 and s['notifications_enabled']==0 for s in sites)
    assert c.delete(f'/api/operations/profiles/{pid}',headers=HEADER).status_code==200
    assert all(s['interval_hours']==6 and s['profile_id'] is None for s in c.get('/api/sites').json['sites'])


@pytest.mark.parametrize('hours',[1,6,12,24])
def test_policy_interval_schedule_and_validation(env,hours):
    c,ids=env
    assert c.put(f'/api/operations/sites/{ids[0]}/policy',json={'interval_hours':hours},headers=HEADER).status_code==200
    row=next(s for s in c.get('/api/sites').json['sites'] if s['id']==ids[0])
    now=m.utcnow()
    assert m.parse_datetime(m.next_scheduled_check(row,now))-now.replace(microsecond=0)==timedelta(hours=hours)
    assert c.put(f'/api/operations/sites/{ids[0]}/policy',json={'interval_hours':2},headers=HEADER).status_code==400
    assert c.put(f'/api/operations/sites/{ids[0]}/policy',json={'warning_days':True},headers=HEADER).status_code==400


def smtp_config():
    return {'enabled':True,'host':'smtp.example','port':587,'mode':'starttls','username':'operator','sender':'watch@example.com','recipients':['ops@example.com']}


def transition(sid,before_days=100,after_days=20):
    with m.db() as con:
        before=dict(con.execute('SELECT * FROM sites WHERE id=?',(sid,)).fetchone())
        before.update(days_left=before_days,tls_verified=1)
        after={**before,'days_left':after_days}
        m.queue_events(con,before,after)


def test_ack_snooze_maintenance_and_monitoring_not_paused(env):
    c,ids=env;sid=ids[0]
    assert c.put('/api/operations/smtp',json=smtp_config(),headers=HEADER).status_code==200
    future=m.utc_iso(m.utcnow()+timedelta(hours=2))
    assert c.put(f'/api/operations/sites/{sid}/alert',json={'acknowledged':True,'note':'ticket 123'},headers=HEADER).status_code==200
    transition(sid)
    with m.db() as con: assert con.execute('SELECT COUNT(*) FROM mail_outbox').fetchone()[0]==0
    c.put(f'/api/operations/sites/{sid}/alert',json={'snooze_until':future},headers=HEADER)
    transition(sid)
    with m.db() as con: assert con.execute('SELECT COUNT(*) FROM mail_outbox').fetchone()[0]==0
    c.put(f'/api/operations/sites/{sid}/alert',json={},headers=HEADER)
    window=c.post('/api/operations/maintenance',json={'name':'Change','starts_at':m.utc_iso(m.utcnow()-timedelta(minutes=1)),'ends_at':future,'site_ids':[sid]},headers=HEADER)
    assert window.status_code==200,window.json
    transition(sid)
    with m.db() as con:
        assert con.execute('SELECT paused FROM sites WHERE id=?',(sid,)).fetchone()[0]==0
        assert con.execute('SELECT COUNT(*) FROM mail_outbox').fetchone()[0]==0
    c.delete('/api/operations/maintenance/'+str(window.json['id']),headers=HEADER)
    transition(sid)
    with m.db() as con: assert con.execute('SELECT COUNT(*) FROM mail_outbox').fetchone()[0]>0


def test_recovery_clears_ack_and_notifies(env):
    c,ids=env;sid=ids[0]
    c.put('/api/operations/smtp',json=smtp_config(),headers=HEADER)
    c.put(f'/api/operations/sites/{sid}/alert',json={'acknowledged':True},headers=HEADER)
    transition(sid,20,100)
    with m.db() as con:
        assert con.execute('SELECT acknowledged FROM alert_controls WHERE site_id=?',(sid,)).fetchone()[0]==0
        assert con.execute("SELECT COUNT(*) FROM mail_outbox WHERE event='attention_cleared'").fetchone()[0]==1


def test_queued_delivery_suppressed_at_send_time(env,monkeypatch):
    c,ids=env;sid=ids[0]
    c.put('/api/operations/smtp',json=smtp_config(),headers=HEADER)
    transition(sid)
    c.put(f'/api/operations/sites/{sid}/alert',json={'acknowledged':True},headers=HEADER)
    sender=MagicMock();monkeypatch.setattr(ops,'send_mail',sender)
    ops.deliver_mail();sender.assert_not_called()
    with m.db() as con: assert con.execute("SELECT COUNT(*) FROM mail_outbox WHERE status='suppressed'").fetchone()[0]==1


def test_smtp_tls_retry_and_secret_redaction(env,monkeypatch):
    c,_=env
    monkeypatch.setenv('SMTP_PASSWORD','do-not-disclose')
    c.put('/api/operations/smtp',json=smtp_config(),headers=HEADER)
    assert c.post('/api/operations/smtp/test',json={},headers=HEADER).status_code==200
    smtp=MagicMock(); smtp.return_value.__enter__.return_value=smtp
    monkeypatch.setattr(ops.smtplib,'SMTP',smtp)
    ops.deliver_mail()
    smtp.starttls.assert_called_once();smtp.login.assert_called_once_with('operator','do-not-disclose');smtp.send_message.assert_called_once()
    assert 'do-not-disclose' not in c.get('/api/operations').get_data(as_text=True)
    c.post('/api/operations/smtp/test',json={},headers=HEADER)
    monkeypatch.setattr(ops,'send_mail',MagicMock(side_effect=RuntimeError('do-not-disclose')))
    ops.deliver_mail()
    with m.db() as con:
        row=con.execute('SELECT * FROM mail_outbox ORDER BY id DESC LIMIT 1').fetchone()
        assert row['status']=='pending' and row['attempts']==1
        assert 'do-not-disclose' not in row['last_error']


def test_retention_keeps_pending_and_current_certificate(env):
    c,ids=env
    assert c.put('/api/operations/retention',json={'history_days':1,'checks_per_site':10,'audit_days':30,'delivery_days':1},headers=HEADER).status_code==200
    old=m.utc_iso(m.utcnow()-timedelta(days=400))
    with m.db() as con:
        con.execute('INSERT INTO check_history(site_id,checked_at,success) VALUES (?,?,0)',(ids[0],old))
        con.execute("INSERT INTO mail_outbox(site_id,event,payload,next_attempt_at,created_at) VALUES (?,'test','{}',?,?)",(ids[0],old,old))
        con.execute("INSERT INTO mail_outbox(site_id,event,payload,next_attempt_at,created_at,status) VALUES (?,'test','{}',?,?,'delivered')",(ids[0],old,old))
        con.execute("UPDATE sites SET certificate_pem='current' WHERE id=?",(ids[0],))
        for fingerprint,pem in [('a','current'),('b','old')]:
            con.execute('INSERT INTO certificate_history(site_id,fingerprint,certificate_pem,first_seen_at,last_seen_at) VALUES (?,?,?,?,?)',(ids[0],fingerprint,pem,old,old))
    ops.housekeeping()
    with m.db() as con:
        assert con.execute('SELECT COUNT(*) FROM check_history').fetchone()[0]==0
        assert con.execute('SELECT status FROM mail_outbox').fetchall()[0][0]=='pending'
        assert con.execute('SELECT certificate_pem FROM certificate_history').fetchall()[0][0]=='current'


def test_admin_guard_audit_has_no_request_secrets(env):
    c,ids=env
    assert c.put(f'/api/operations/sites/{ids[0]}/policy',json={}).status_code==403
    c.put(f'/api/operations/sites/{ids[0]}/alert',json={'note':'sensitive operator text'},headers=HEADER)
    audit=c.get('/api/operations').json['audit']
    assert audit and 'sensitive operator text' not in json.dumps(audit)
    assert any('alert' in a['path'] for a in audit)


def test_agent_health_validation():
    clean=ops.sanitize_health({'cpu_percent':10.5,'disk_free_bytes':12345,'environment':'secret','queue_blocked':True})
    assert clean=={'cpu_percent':10.5,'disk_free_bytes':12345,'queue_blocked':True}
    for value in (True,float('nan'),-1,101):
        with pytest.raises(ValueError): ops.sanitize_health({'cpu_percent':value})


def test_snooze_end_resumes_one_notification_for_active_incident(env):
    c,ids=env;sid=ids[0]
    c.put('/api/operations/smtp',json=smtp_config(),headers=HEADER)
    c.put(f'/api/operations/sites/{sid}/alert',json={'snooze_until':m.utc_iso(m.utcnow()+timedelta(hours=1))},headers=HEADER)
    with m.db() as con:
        con.execute("UPDATE sites SET last_error='network failure' WHERE id=?",(sid,))
        con.execute('UPDATE alert_controls SET snooze_until=? WHERE site_id=?',(m.utc_iso(m.utcnow()-timedelta(seconds=1)),sid))
    ops.tick();ops.tick()
    with m.db() as con:
        assert con.execute("SELECT COUNT(*) FROM mail_outbox WHERE event='needs_attention'").fetchone()[0]==1
        assert con.execute('SELECT COUNT(*) FROM deferred_alerts').fetchone()[0]==0


def test_v46_schema_migrates_without_losing_inventory(tmp_path,monkeypatch):
    path=tmp_path/'legacy.sqlite3'
    with m.sqlite3.connect(path) as con:
        # SQL_SCHEMA is the unchanged v4.6 baseline; v4.6.5 additions are in migrate().
        con.executescript(m.SQL_SCHEMA)
        con.execute('INSERT INTO sites(url,hostname,port,created_at) VALUES (?,?,?,?)',('https://legacy.example','legacy.example',443,m.utc_iso(m.utcnow())))
        con.execute('INSERT INTO monitoring_agents(name,created_at,token_hash) VALUES (?,?,?)',('Preserved agent',m.utc_iso(m.utcnow()),'existing-token-hash'))
    monkeypatch.setattr(m,'DB_PATH',path)
    m.init_db();m.init_db()
    with m.db() as con:
        site=con.execute('SELECT * FROM sites').fetchone()
        assert site['hostname']=='legacy.example' and site['interval_hours']==24 and site['warning_days']==30
        assert con.execute('SELECT token_hash FROM monitoring_agents').fetchone()[0]=='existing-token-hash'
        assert con.execute("SELECT name FROM sqlite_master WHERE name='audit_log'").fetchone()
