"""v4.5 primary: replay from offline agents and idempotent result uploads."""
import app as monitor
from datetime import datetime, timedelta, timezone
import pytest
from cryptography import x509
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(monitor, "DB_PATH", tmp_path / "db.sqlite3")
    monkeypatch.setattr(monitor, "AUTH_USER", "")
    monkeypatch.setattr(monitor, "AUTH_PASSWORD", "")
    monitor.init_db()
    return monitor.app.test_client()


def setup(client):
    created = client.post('/api/agents', json={'name': 'Lab remote'})
    assert created.status_code == 201
    paired = client.post('/agent/v1/enroll',json={'enrollment_code':created.json['enrollment_code']})
    assert paired.status_code == 200
    agent_id=created.json['id']
    added=client.post('/api/sites',json={'urls':'https://lab.example.local','agent_id':agent_id})
    assert added.status_code==201
    site_id=client.get('/api/sites').json['sites'][0]['id']
    headers={'Authorization':'Bearer '+paired.json['agent_token']}
    return agent_id,site_id,headers


def pem():
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'lab.example.local')])
    now=datetime.now(timezone.utc)
    cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
          .serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(days=3))
          .not_valid_after(now+timedelta(days=88)).sign(key,hashes.SHA256()))
    return cert.public_bytes(serialization.Encoding.PEM).decode('ascii')


def iso(value):
    return value.isoformat(timespec='seconds').replace('+00:00','Z')


def test_delayed_batch_is_durable_and_idempotent(client):
    agent,site,headers=setup(client)
    sync=client.post('/agent/v1/sync',json={'version':'4.5.0','queued_results':0},headers=headers)
    assert sync.status_code==200 and sync.json['assignments'][0]['site_id']==site
    assert sync.json['timezone']
    when=datetime.now(timezone.utc)-timedelta(hours=9)
    items=[{'result_id':'offline-check-1','site_id':site,'checked_at':iso(when),
            'next_check_at':iso(when+timedelta(days=1)), 'success':True,
            'certificate_pem':pem(),'tls_verified':False,'verify_error':'unknown CA'},
           {'result_id':'offline-check-2','site_id':site,'checked_at':iso(when+timedelta(minutes=4)),
            'next_check_at':iso(when+timedelta(days=1,minutes=4)), 'success':False,
            'error':'Network unreachable'}]
    result=client.post('/agent/v1/results/batch',json={'results':items},headers=headers)
    assert result.status_code==200,result.json
    assert [r['status'] for r in result.json['outcomes']]==['accepted','accepted']
    retry=client.post('/agent/v1/results/batch',json={'results':items},headers=headers)
    assert [r['status'] for r in retry.json['outcomes']]==['duplicate','duplicate']
    with monitor.db() as con:
        assert con.execute('SELECT COUNT(*) FROM check_history WHERE site_id=?',(site,)).fetchone()[0]==2
        assert con.execute('SELECT COUNT(*) FROM agent_result_receipts').fetchone()[0]==2
        current=con.execute('SELECT * FROM sites WHERE id=?',(site,)).fetchone()
        assert current['last_error']=='Network unreachable'
        assert current['last_checked_at']==items[-1]['checked_at']
        assert current['next_check_at']==items[-1]['next_check_at']
    late={**items[0],'result_id':'offline-check-3','checked_at':iso(when-timedelta(days=1))}
    r=client.post('/agent/v1/results/batch',json={'results':[late]},headers=headers)
    assert r.json['outcomes'][0]['status']=='accepted'
    with monitor.db() as con:
        assert con.execute('SELECT last_checked_at FROM sites WHERE id=?',(site,)).fetchone()[0]==items[-1]['checked_at']
        assert con.execute('SELECT COUNT(*) FROM check_history WHERE site_id=?',(site,)).fetchone()[0]==3


def test_reassigned_site_is_rejected_without_processing(client,monkeypatch):
    agent,site,headers=setup(client)
    # Reassignment correctly schedules a new local probe. Isolate the test's
    # assertion about rejecting the old agent instead of racing that probe.
    monkeypatch.setattr(monitor,'enqueue',lambda site_id: True)
    changed=client.put(f'/api/sites/{site}/agent',json={'agent_id':None})
    assert changed.status_code==200
    r=client.post('/agent/v1/results/batch',json={'results':[{
        'result_id':'from-wrong-agent','site_id':site,'checked_at':iso(datetime.now(timezone.utc)),
        'success':False,'error':'timeout'}]},headers=headers)
    assert r.status_code==200
    assert r.json['outcomes'][0]['status']=='rejected'
    with monitor.db() as con:
        assert con.execute('SELECT COUNT(*) FROM check_history WHERE site_id=?',(site,)).fetchone()[0]==0
