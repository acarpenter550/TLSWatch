"""Keep pre-existing test-client fixtures independent of secure LAN deployment defaults."""
import os
os.environ.setdefault("APP_USERNAME", "")
os.environ.setdefault("APP_PASSWORD", "")
