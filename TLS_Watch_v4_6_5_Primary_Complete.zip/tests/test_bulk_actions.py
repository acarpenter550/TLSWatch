"""v4.6 bulk inventory actions: run with pytest when Flask is installed."""
import sqlite3
import pytest
import app as monitor


@pytest.fixture
def bulk_setup(monkeypatch, tmp_path):
    monkeypatch.setattr(monitor, 'DB_PATH', tmp_path / 'bulk.sqlite3')
    monkeypatch.setattr(monitor, 'AUTH_USER', '')
    monkeypatch.setattr(monitor, 'AUTH_PASSWORD', '')
    dispatched = []
    monkeypatch.setattr(monitor, 'enqueue', lambda site_id: dispatched.append(site_id) or True)
    monitor.init_db()
    with monitor.db() as con:
        ids = []
        for idx in range(4):
            cur = con.execute('''INSERT INTO sites (url,hostname,port,created_at,paused)
                VALUES (?,?,?,?,?)''', (f'https://test{idx}.example',f'test{idx}.example',443,
                                      monitor.utc_iso(monitor.utcnow()), 1 if idx == 3 else 0))
            ids.append(cur.lastrowid)
        gs = []
        for name in ('Production', 'Staging'):
            cur = con.execute('INSERT INTO groups(name,created_at) VALUES (?,?)',
                              (name, monitor.utc_iso(monitor.utcnow())))
            gs.append(cur.lastrowid)
        agent = con.execute('INSERT INTO monitoring_agents(name,enabled,created_at) VALUES (?,1,?)',
                            ('Remote A', monitor.utc_iso(monitor.utcnow()))).lastrowid
        con.execute('INSERT INTO site_groups(site_id,group_id) VALUES (?,?)', (ids[0],gs[1]))
        con.execute('UPDATE sites SET agent_id=? WHERE id=?',(agent,ids[3]))
    return monitor.app.test_client(), ids, gs, agent, dispatched


def test_bulk_groups_are_additive_and_removable(bulk_setup):
    client, ids, gs, agent, dispatched = bulk_setup
    r = client.post('/api/sites/bulk', json={'site_ids':ids[:2], 'action':'groups_add', 'group_ids':[gs[0]]})
    assert r.status_code == 200 and r.json['affected'] == 2
    with monitor.db() as con:
        memberships = con.execute('SELECT site_id,group_id FROM site_groups ORDER BY site_id,group_id').fetchall()
        assert {(r['site_id'],r['group_id']) for r in memberships} == {(ids[0],gs[0]),(ids[0],gs[1]),(ids[1],gs[0])}
    r = client.post('/api/sites/bulk', json={'site_ids':ids[:2], 'action':'groups_remove', 'group_ids':[gs[0]]})
    assert r.status_code == 200
    with monitor.db() as con:
        assert [(r['site_id'],r['group_id']) for r in con.execute('SELECT * FROM site_groups')] == [(ids[0],gs[1])]


def test_bulk_check_skips_paused_remote_and_can_reassign(bulk_setup):
    client, ids, gs, agent, dispatched = bulk_setup
    r = client.post('/api/sites/bulk', json={'site_ids':ids, 'action':'check'})
    assert r.status_code == 200
    assert r.json['affected'] == 3 and r.json['skipped_site_ids'] == [ids[3]]
    assert dispatched == ids[:3]
    r = client.post('/api/sites/bulk', json={'site_ids':ids[:2], 'action':'agent', 'agent_id':agent})
    assert r.status_code == 200 and r.json['affected'] == 2
    with monitor.db() as con:
        assert con.execute('SELECT agent_id FROM sites WHERE id=?',(ids[0],)).fetchone()['agent_id'] == agent
    r = client.post('/api/sites/bulk', json={'site_ids':ids[:2], 'action':'agent', 'agent_id':None})
    assert r.status_code == 200 and r.json['affected'] == 2
    with monitor.db() as con:
        assert con.execute('SELECT agent_id FROM sites WHERE id=?',(ids[0],)).fetchone()['agent_id'] is None


def test_pause_resume_and_delete(bulk_setup):
    client, ids, gs, agent, dispatched = bulk_setup
    assert client.post('/api/sites/bulk', json={'site_ids':ids[:2], 'action':'pause'}).json['affected'] == 2
    with monitor.db() as con:
        assert all(con.execute('SELECT paused FROM sites WHERE id=?',(i,)).fetchone()['paused'] for i in ids[:2])
    assert client.post('/api/sites/bulk', json={'site_ids':ids[:2], 'action':'resume'}).json['affected'] == 2
    with monitor.db() as con:
        assert all(not con.execute('SELECT paused FROM sites WHERE id=?',(i,)).fetchone()['paused'] for i in ids[:2])
    assert client.post('/api/sites/bulk', json={'site_ids':ids[:2], 'action':'delete'}).json['affected'] == 2
    with monitor.db() as con:
        assert con.execute('SELECT COUNT(*) FROM sites').fetchone()[0] == 2


def test_bulk_validation_avoids_partial_mutations(bulk_setup):
    client, ids, gs, agent, dispatched = bulk_setup
    cases = [
        {'site_ids':[ids[0], 98989], 'action':'delete'},
        {'site_ids':[ids[0]], 'action':'groups_add', 'group_ids':[gs[0],98989]},
        {'site_ids':[ids[0]], 'action':'agent', 'agent_id':99999},
        {'site_ids':[ids[0], ids[0]], 'action':'bogus'},
        {'site_ids':[], 'action':'delete'},
        {'site_ids':[ids[0]], 'action':'groups_remove', 'group_ids':[]},
    ]
    for payload in cases:
        assert client.post('/api/sites/bulk', json=payload).status_code == 400
    with monitor.db() as con:
        assert con.execute('SELECT COUNT(*) FROM sites').fetchone()[0] == 4
        assert con.execute('SELECT COUNT(*) FROM site_groups').fetchone()[0] == 1
    # Read-only v1 endpoints do not expose bulk mutation.
    assert client.post('/api/v1/certificates', json=cases[0]).status_code == 405
