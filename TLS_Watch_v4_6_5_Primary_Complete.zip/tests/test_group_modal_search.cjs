// Regression coverage for the group editor's search and selection preservation.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const js = fs.readFileSync(path.join(__dirname, '..', 'static','app.js'),'utf8');
const html = fs.readFileSync(path.join(__dirname, '..', 'static','index.html'),'utf8');
assert.match(html,/id="groupWebsiteSearch"/);
assert.match(html,/id="groupMatchCount"/);
assert.match(html,/id="groupNoMatches"/);
const snippet = (begin,end) => {
  const i=js.indexOf(begin), j=js.indexOf(end,i);
  assert(i>=0&&j>i,`missing source functions: ${begin}`);
  return js.substring(i,j);
};
const urls=[ 'https://a.example.org', 'https://branch.local:8443', 'https://api.example.org' ];
const rows=urls.map((url,i)=>({
  dataset:{searchValue:url.toLowerCase()}, hidden:false,
  input:{checked:i===0,value:String(i+1)},
  querySelector(){return this.input;}
}));
const nodes={
  groupWebsiteSearch:{value:''},
  groupMatchCount:{textContent:''},
  groupNoMatches:{hidden:true},
  groupSelectAll:{textContent:'Select all'},
  groupSelectNone:{textContent:'Clear selection'},
  groupSelectionCount:{textContent:''},
  groupSiteChecklist:{querySelectorAll(sel){
    if (sel==='.group-check-row') return rows;
    if (sel==='input:checked') return rows.map(r=>r.input).filter(x=>x.checked);
    if (sel==='input[type=checkbox]') return rows.map(r=>r.input);
    throw new Error('Unexpected selector '+sel);
  }}
};
const ctx=vm.createContext({$:id=>nodes[id]});
vm.runInContext(snippet('function selectionCount()','function buildCheckbox(')
   + snippet('function setVisibleGroupCheckboxes(checked)','$(\'groupSelectAll\')'),ctx);
ctx.filterGroupWebsites(); ctx.selectionCount();
assert.equal(nodes.groupMatchCount.textContent,'Showing 3 of 3 websites');
assert.equal(nodes.groupSelectionCount.textContent,'1 selected');
// Filtering does not change any checked state.
nodes.groupWebsiteSearch.value='EXAMPLE.ORG'; ctx.filterGroupWebsites();
assert.equal(nodes.groupMatchCount.textContent,'Showing 2 of 3 websites');
assert.equal(rows[1].hidden,true);
ctx.setVisibleGroupCheckboxes(true);
assert.equal(nodes.groupSelectionCount.textContent,'2 selected');
assert.equal(rows[1].input.checked,false);
// Hidden checked rows must survive a different filter.
nodes.groupWebsiteSearch.value='branch'; ctx.filterGroupWebsites();
ctx.setVisibleGroupCheckboxes(true);
assert.equal(nodes.groupSelectionCount.textContent,'3 selected');
ctx.setVisibleGroupCheckboxes(false);
assert.equal(nodes.groupSelectionCount.textContent,'2 selected');
assert.equal(rows[0].input.checked,true);
assert.equal(rows[2].input.checked,true);
nodes.groupWebsiteSearch.value='nothing-matches';ctx.filterGroupWebsites();
assert.equal(nodes.groupMatchCount.textContent,'Showing 0 of 3 websites');
assert.equal(nodes.groupNoMatches.hidden,false);
assert.equal(nodes.groupSelectionCount.textContent,'2 selected');
nodes.groupWebsiteSearch.value='';ctx.filterGroupWebsites();
assert.equal(nodes.groupMatchCount.textContent,'Showing 3 of 3 websites');
assert.equal(nodes.groupNoMatches.hidden,true);
// Save uses all checked inputs, not just currently-visible inputs.
assert.match(js,/const site_ids = \[\.\.\.\$\('groupSiteChecklist'\)\.querySelectorAll\('input:checked'\)\]/);
console.log('Group editor search, counts, visible-only bulk selection and preservation: PASS');
