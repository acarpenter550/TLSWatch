"""Real TLS chain capture/path validation against local TLS servers."""
from datetime import datetime,timedelta,timezone
import socket
import ssl
import threading
import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
import tlsprobe


@pytest.mark.parametrize('mode',['complete','missing_intermediate','expired_intermediate'])
def test_complete_chain_validation_and_failure_reasons(tmp_path,mode):
    now=datetime.now(timezone.utc)
    keys=[rsa.generate_private_key(public_exponent=65537,key_size=2048) for _ in range(3)]
    names=[x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,n)]) for n in ('Test Root','Test Intermediate','service.example')]
    def make(index,issuer,key,ca,expired=False):
        b=(x509.CertificateBuilder().subject_name(names[index]).issuer_name(issuer).public_key(keys[index].public_key())
           .serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(days=3))
           .not_valid_after(now+timedelta(days=-1 if expired else 30))
           .add_extension(x509.BasicConstraints(ca=ca,path_length=None),True))
        if not ca: b=b.add_extension(x509.SubjectAlternativeName([x509.DNSName('service.example')]),False)
        return b.sign(key,hashes.SHA256()).public_bytes(serialization.Encoding.PEM)
    root=make(0,names[0],keys[0],True)
    intermediate=make(1,names[0],keys[0],True,mode=='expired_intermediate')
    leaf=make(2,names[1],keys[1],False)
    (tmp_path/'chain.pem').write_bytes(leaf+(intermediate if mode!='missing_intermediate' else b''))
    (tmp_path/'key.pem').write_bytes(keys[2].private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(tmp_path/'chain.pem',tmp_path/'key.pem')
    listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen();listener.settimeout(.1)
    stop=threading.Event()
    def serve():
        while not stop.is_set():
            try: raw,_=listener.accept()
            except socket.timeout: continue
            except OSError: return
            try:
                raw.settimeout(2)
                with ctx.wrap_socket(raw,server_side=True): pass
            except OSError: raw.close()
    thread=threading.Thread(target=serve,daemon=True);thread.start()
    try:
        result=tlsprobe.inspect('service.example',[(socket.AF_INET,listener.getsockname())],2,root.decode())
        details=result['tls_details']
        assert details['chain_capture_supported']
        assert len(details['presented_chain'])==(1 if mode=='missing_intermediate' else 2)
        if mode=='complete':
            assert result['tls_verified'] and len(details['verified_chain'])==3
            assert 'Test Root' in details['verified_chain'][-1]['subject']
        else:
            assert not result['tls_verified'] and result['verify_error']
        if mode=='expired_intermediate': assert not details['presented_chain'][1]['currently_valid']
        assert details['protocol'].startswith('TLS') and details['cipher'][0]
    finally:
        stop.set();thread.join(3);listener.close()
