// Execute the actual v4.5.1 inventory filter code without browser dependencies.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root,'static','index.html'),'utf8');
const source = fs.readFileSync(path.join(root,'static','app.js'),'utf8');
assert.match(html, /id="agentFilter"/, 'Agent dropdown must be rendered');
assert.match(source, /'searchBox', 'searchScope', 'agentFilter', 'statusFilter', 'sortSelect'/, 'Agent change event must be wired');
function extract(start, end) {
 const a=source.indexOf(start),b=source.indexOf(end,a);
 assert(a>=0&&b>a,`missing ${start}`);
 return source.slice(a,b);
}
const form = { searchBox:'', searchScope:'all', agentFilter:'all', statusFilter:'all', sortSelect:'name' };
const sites=[
  {id:1,url:'https://one.example',issuer:'Good',last_error:null,agent_id:null,group_ids:[3],days_left:200,paused:false},
  {id:2,url:'https://two.example',issuer:'Warn',last_error:null,agent_id:2,group_ids:[3,4],days_left:40,paused:false},
  {id:3,url:'https://three.example',issuer:'Good',last_error:'connection failed',agent_id:2,group_ids:[4],days_left:10,paused:false},
  {id:4,url:'https://four.example',issuer:'Trusted',last_error:null,agent_id:5,group_ids:[3],days_left:180,paused:true},
  {id:5,url:'https://five.example',issuer:'Good',last_error:null,agent_id:null,group_ids:[],days_left:180,paused:false}
];
const agents=[{id:2,name:'Branch A',enabled:false,status:'offline'},{id:5,name:'Production LAN',enabled:true,status:'online'},{id:9,name:'Empty Agent',enabled:true,status:'offline'}];
let options=[{value:'all'}];
const selector={value:'all',options,replaceChildren(...items){this.options=[...items];},add(item){this.options.push(item);}};
const context=vm.createContext({state:{sites,agents,activeGroup:'all'}, $:id=>id==='agentFilter'?selector:{value:form[id]}, Option:function(text,value){return {text,value}}, attention:s=> !!s.last_error || s.days_left<=30});
vm.runInContext(extract('function visibleSites()', 'function renderTable()')+extract('function renderAgentFilter()', '// v4.4: agent enrollment'),context);
const ids=()=>Array.from(vm.runInContext('visibleSites().map(s=>s.id)',context));
assert.deepEqual(ids(),[5,4,1,3,2].sort((a,b)=>sites[a-1].url.localeCompare(sites[b-1].url))); // by URL
selector.value='primary';assert.deepEqual(ids(),[5,1]);
selector.value='agent:2';assert.deepEqual(ids(),[3,2]);
selector.value='agent:5';assert.deepEqual(ids(),[4]);
selector.value='agent:9';assert.deepEqual(ids(),[]);
selector.value='agent:2';form.searchScope='group';context.state.activeGroup='3';assert.deepEqual(ids(),[2]);
form.searchBox='Warn';assert.deepEqual(ids(),[2]);
form.searchBox='';form.statusFilter='attention';assert.deepEqual(ids(),[]);
context.state.activeGroup='4';assert.deepEqual(ids(),[3]);
form.statusFilter='all';selector.value='all';form.searchBox='Trusted';assert.deepEqual(ids(),[]);
form.searchScope='all';assert.deepEqual(ids(),[4]);
form.searchBox='';selector.value='primary';assert.deepEqual(ids(),[5,1]);
selector.value='all';vm.runInContext('renderAgentFilter()',context);
assert.deepEqual(selector.options.map(v=>v.value),['all','primary','agent:2','agent:5','agent:9']);
assert.equal(selector.options[0].text,'All monitoring locations (5)');
assert.equal(selector.options[1].text,'Primary server (2)');
assert.equal(selector.options[2].text,'Branch A (2)');
assert.equal(selector.options[4].text,'Empty Agent (0)');
assert.equal(selector.value,'all');
selector.value='agent:2';vm.runInContext('renderAgentFilter()',context);
assert.equal(selector.value,'agent:2','Selection must survive refresh');
context.state.agents=agents.filter(a=>a.id!==2);vm.runInContext('renderAgentFilter()',context);
assert.equal(selector.value,'all','Removed agent should reset filter');
console.log('Agent dropdown: primary, remote, disabled, group, text, statuses, counts and refresh: PASS');
