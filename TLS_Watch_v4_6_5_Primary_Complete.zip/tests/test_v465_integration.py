"""Both real applications, isolated stores and the actual enrollment/sync APIs.

Use the complete release (primary/ and agent/ siblings) for these tests.
The primary HTTP transport is bridged through Flask's client; TLS is separately
exercised against real local servers in both suites.
"""
import base64
from datetime import datetime,timedelta,timezone
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
from unittest.mock import MagicMock
import zipfile
import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import ed25519,rsa
from cryptography.x509.oid import NameOID
import app as m
import updates

AGENT_DIR=Path(__file__).resolve().parents[2]/'agent'
if not (AGENT_DIR/'agent.py').exists():
    pytest.skip('Complete primary/agent release required for cross-application integration tests',allow_module_level=True)
sys.path.insert(0,str(AGENT_DIR))
import agent as a
import agent_operations as ao
REAL_PRIMARY_CALL=a.primary_call

H={'X-TLSWatch-Admin':'1'}


@pytest.fixture
def env(tmp_path,monkeypatch):
    monkeypatch.setattr(m,'DB_PATH',tmp_path/'primary.sqlite3')
    monkeypatch.setattr(m,'AUTH_USER','');monkeypatch.setattr(m,'AUTH_PASSWORD','')
    monkeypatch.setattr(m,'enqueue',lambda sid: True)
    m.init_db(); c=m.app.test_client()
    data=tmp_path/'agent_data';data.mkdir()
    for key,name in [('DATA_DIR',''),('CONFIG_FILE','agent.json'),('LEGACY_CACHE_FILE','agent_cache.sqlite3'),('TRUST_DIR','trusted_targets'),('TRUST_INDEX','trusted_targets/index.json')]: monkeypatch.setattr(a,key,data/name)
    a.config={'schema_version':2,'primaries':[]};a.primary_states.clear();a.local_inflight.clear();a.syncing.clear();a.next_polls.clear()
    def bridge(settings,path,payload):
        headers={'Authorization':'Bearer '+settings.get('token','')}
        response=c.post(path,json=payload,headers=headers)
        if response.status_code>=400: raise OSError('Primary request failed: '+str(response.status_code))
        return response.json
    monkeypatch.setattr(a,'primary_call',bridge)
    created=c.post('/api/agents',json={'name':'Remote fixture'}).json
    enrolled=c.post('/agent/v1/enroll',json={'enrollment_code':created['enrollment_code']}).json
    pid=a.profile_id();profile={'profile_id':pid,'agent_id':created['id'],'agent_name':'Remote fixture','primary_url':'https://primary.example','token':enrolled['agent_token']}
    a.config['primaries']=[profile];a.primary_states[pid]=a.default_state();a.init_cache(pid)
    c.post('/api/sites',json={'urls':'https://service.example','agent_id':created['id']})
    sid=c.get('/api/sites').json['sites'][0]['id']
    return c,profile,sid,data


def cert_report(days=60):
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    now=datetime.now(timezone.utc)
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'service.example')])
    cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
          .serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(days=1)).not_valid_after(now+timedelta(days=days))
          .add_extension(x509.SubjectAlternativeName([x509.DNSName('service.example')]),False).sign(key,hashes.SHA256()))
    pem=cert.public_bytes(serialization.Encoding.PEM).decode()
    return {'success':True,'certificate_pem':pem,'tls_verified':False,'verify_error':'self signed',
            'tls_details':{'protocol':'TLSv1.3','cipher':['TLS_AES_256_GCM_SHA384','TLSv1.3',256],
                           'trust_verified':False,'trust_error':'self signed','chain_capture_supported':True,
                           'presented_chain':[{'pem':pem,'subject':'forged label ignored'}]}}


def due(profile):
    with a.cache_db(profile['profile_id']) as con: return dict(con.execute('SELECT * FROM inventory').fetchone())


def test_policy_offline_outage_replay_and_chain_persistence(env,monkeypatch):
    c,p,sid,data=env
    c.put(f'/api/operations/sites/{sid}/policy',json={'interval_hours':1,'warning_days':45},headers=H)
    a.poll_one(p)
    site=due(p);assert site['interval_hours']==1
    monkeypatch.setattr(a,'check_certificate',lambda *args:cert_report())
    a.run_local_check([(p['profile_id'],site)])
    stats=a.cache_stats(p['profile_id']);assert stats['queued_results']==1
    local=due(p)
    assert a.datetime.fromisoformat(local['next_check_at'].replace('Z','+00:00'))-a.datetime.fromisoformat(local['last_checked_at'].replace('Z','+00:00'))==timedelta(hours=1)
    real_call=a.primary_call
    monkeypatch.setattr(a,'primary_call',lambda *args:(_ for _ in ()).throw(OSError('offline')))
    a.poll_one(p);assert a.cache_stats(p['profile_id'])['queued_results']==1
    monkeypatch.setattr(a,'primary_call',real_call)
    a.poll_one(p)
    assert a.cache_stats(p['profile_id'])['queued_results']==0
    details=c.get(f'/api/sites/{sid}/certificate').json['tls_details']
    assert details['protocol']=='TLSv1.3' and 'forged' not in details['presented_chain'][0]['subject']
    with m.db() as con:
        assert con.execute('SELECT COUNT(*) FROM check_history').fetchone()[0]==1
        assert con.execute('SELECT COUNT(*) FROM agent_result_receipts').fetchone()[0]==1
        assert con.execute('SELECT tls_details_json FROM check_history').fetchone()[0]
    a.poll_one(p)
    with m.db() as con: assert con.execute('SELECT COUNT(*) FROM check_history').fetchone()[0]==1


def test_policy_change_while_observation_is_pending(env,monkeypatch):
    c,p,sid,_=env;a.poll_one(p)
    monkeypatch.setattr(a,'check_certificate',lambda *args:{'success':False,'error':'DNS failure'})
    a.run_local_check([(p['profile_id'],due(p))])
    c.put(f'/api/operations/sites/{sid}/policy',json={'interval_hours':6},headers=H)
    headers={'Authorization':'Bearer '+p['token']}
    snapshot=c.post('/agent/v1/sync',json={'version':a.VERSION},headers=headers).json['assignments']
    a.reconcile_assignments(p['profile_id'],snapshot)
    row=due(p)
    assert row['interval_hours']==6
    assert m.parse_datetime(row['next_check_at'])-m.parse_datetime(row['last_checked_at'])==timedelta(hours=6)
    assert a.cache_stats(p['profile_id'])['queued_results']==1


def test_queue_count_and_bytes_pause_without_deleting_pending(env,monkeypatch):
    _,p,_,_=env;a.poll_one(p)
    monkeypatch.setenv('AGENT_QUEUE_MAX_RESULTS','10')
    with a.cache_db(p['profile_id']) as con:
        for n in range(10): con.execute('INSERT INTO outbox(result_id,site_id,checked_at,payload_json,created_at) VALUES (?,?,?,?,?)',(str(n),1,a.stamp(),'{}',a.stamp()))
    submit=MagicMock();monkeypatch.setattr(a.check_pool,'submit',submit)
    a.schedule_due();submit.assert_not_called()
    assert a.cache_stats(p['profile_id'])['queue_blocked'] is True
    with a.cache_db(p['profile_id']) as con:
        assert con.execute('SELECT COUNT(*) FROM outbox').fetchone()[0]==10
        con.execute('DELETE FROM outbox')
        con.execute('INSERT INTO outbox(result_id,site_id,checked_at,payload_json,created_at) VALUES (?,?,?,?,?)',('large',1,a.stamp(),'x'*900000,a.stamp()))
    monkeypatch.setenv('AGENT_QUEUE_MAX_BYTES','1000000')
    a.schedule_due();submit.assert_not_called()


def test_health_and_legacy_agent_compatibility(env):
    c,p,sid,_=env;a.poll_one(p)
    agent=c.get('/api/agents').json['agents'][0]
    assert agent['version']=='4.6.5' and agent['health']['disk_free_bytes']>0
    headers={'Authorization':'Bearer '+p['token']}
    old=c.post('/agent/v1/sync',json={'version':'4.6.2','queued_results':0},headers=headers)
    assert old.status_code==200 and old.json['assignments'][0]['interval_hours']==24
    assert c.post('/agent/v1/sync',json={'health':{'cpu_percent':500}},headers=headers).status_code==400


def test_certificate_changes_and_duplicate_replay_events(env,monkeypatch):
    c,p,sid,_=env;a.poll_one(p)
    report=cert_report(30);monkeypatch.setattr(a,'check_certificate',lambda *args:report)
    a.run_local_check([(p['profile_id'],due(p))]);a.flush_outbox(p)
    # A distinct observation timestamp prevents current-state replacement ties.
    with m.db() as con: con.execute('UPDATE sites SET last_checked_at=? WHERE id=?',(m.utc_iso(m.utcnow()-timedelta(seconds=2)),sid))
    report=cert_report(120)
    a.run_local_check([(p['profile_id'],due(p))]);a.flush_outbox(p)
    with m.db() as con:
        assert con.execute('SELECT COUNT(*) FROM certificate_history').fetchone()[0]==2
        assert con.execute('SELECT COUNT(*) FROM check_history').fetchone()[0]==2


def release_package():
    data=io.BytesIO()
    with zipfile.ZipFile(data,'w',zipfile.ZIP_DEFLATED) as z:
        for name in updates.RUNTIME:
            path=AGENT_DIR/name
            if path.is_file(): z.writestr(name,path.read_bytes())
    raw=data.getvalue();key=ed25519.Ed25519PrivateKey.generate()
    public=base64.b64encode(key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)).decode()
    manifest={'version':'4.6.5','component':'agent','size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    package={'manifest':manifest,'signature':base64.b64encode(key.sign(updates.signed_bytes(manifest))).decode(),'archive':base64.b64encode(raw).decode()}
    return key,public,package


def test_signed_remote_stage_install_and_ack(env,monkeypatch,tmp_path):
    c,p,_,data=env;_,public,package=release_package()
    monkeypatch.setenv('UPDATE_PUBLIC_KEY',public);monkeypatch.setenv('AGENT_UPDATE_PUBLIC_KEY',public)
    a.poll_one(p)
    upload=c.post('/api/operations/releases',json=package,headers=H)
    assert upload.status_code==200,upload.json
    rid=upload.json['id']
    assert c.post(f'/api/operations/agents/{p["agent_id"]}/update',json={'release_id':rid},headers=H).status_code==200
    a.poll_one(p);assert ao.update_state(data)['status']=='staged'
    a.poll_one(p)
    with m.db() as con: assert con.execute('SELECT COUNT(*) FROM agent_update_commands').fetchone()[0]==0
    monkeypatch.setenv('AGENT_ALLOW_REMOTE_UPDATES','1')
    monkeypatch.setenv('AGENT_UPDATE_LAUNCHER','1')
    restart=MagicMock();monkeypatch.setattr(ao,'request_restart',restart)
    assert c.post(f'/api/operations/agents/{p["agent_id"]}/update',json={'release_id':rid,'action':'install'},headers=H).status_code==200
    a.poll_one(p);restart.assert_called_once();assert (data/'pending_update.json').exists()
    root=tmp_path/'runtime';root.mkdir()
    for name in updates.RUNTIME:
        path=AGENT_DIR/name
        if path.exists(): shutil.copy2(path,root/name)
    (root/'.env').write_text('preserved-secret')
    assert updates.apply_pending(root,data,public)
    assert (root/'.env').read_text()=='preserved-secret'
    assert ao.update_state(data)['status']=='installed'
    a.poll_one(p)
    with m.db() as con: assert con.execute('SELECT COUNT(*) FROM agent_update_commands').fetchone()[0]==0


def test_update_signature_tamper_and_enrollment_scope(env,monkeypatch):
    c,p,_,data=env;_,public,package=release_package()
    monkeypatch.setenv('UPDATE_PUBLIC_KEY',public)
    changed=json.loads(json.dumps(package));changed['manifest']['version']='4.6.6'
    assert c.post('/api/operations/releases',json=changed,headers=H).status_code==400
    with pytest.raises(ValueError): updates.verify(changed,public)
    with pytest.raises(ValueError): updates.verify(package,public,'4.6.6')
    c.post('/api/operations/releases',json=package,headers=H);a.poll_one(p)
    cmd=c.post(f'/api/operations/agents/{p["agent_id"]}/update',json={'release_id':package['manifest']['sha256']},headers=H).json['command_id']
    assert c.post('/agent/v1/update',json={'command_id':cmd}).status_code==401
    second=c.post('/api/agents',json={'name':'Other'}).json
    token=c.post('/agent/v1/enroll',json={'enrollment_code':second['enrollment_code']}).json['agent_token']
    assert c.post('/agent/v1/update',json={'command_id':cmd},headers={'Authorization':'Bearer '+token}).status_code==404


def test_native_update_opt_in_and_docker_block(env,monkeypatch):
    c,p,_,data=env;_,public,package=release_package()
    monkeypatch.setenv('UPDATE_PUBLIC_KEY',public);monkeypatch.setenv('AGENT_UPDATE_PUBLIC_KEY',public)
    c.post('/api/operations/releases',json=package,headers=H);a.poll_one(p)
    for allow,deployment in [('0','native'),('1','docker')]:
        monkeypatch.setenv('AGENT_ALLOW_REMOTE_UPDATES',allow);monkeypatch.setenv('AGENT_DEPLOYMENT',deployment)
        c.post(f'/api/operations/agents/{p["agent_id"]}/update',json={'release_id':package['manifest']['sha256'],'action':'install'},headers=H)
        a.poll_one(p)
        assert ao.update_state(data)['status']=='blocked'
        assert not (data/'pending_update.json').exists()


def test_two_primaries_share_probe_but_keep_queues_and_uploads_separate(env,monkeypatch):
    c,p,sid,data=env
    second_db=data.parent/'second.sqlite3';first_db=m.DB_PATH
    monkeypatch.setattr(m,'DB_PATH',second_db);m.init_db()
    other=c.post('/api/agents',json={'name':'Second primary remote'}).json
    token=c.post('/agent/v1/enroll',json={'enrollment_code':other['enrollment_code']}).json['agent_token']
    c.post('/api/sites',json={'urls':'https://service.example','agent_id':other['id']})
    monkeypatch.setattr(m,'DB_PATH',first_db)
    q={'profile_id':a.profile_id(),'agent_id':other['id'],'agent_name':'Second','primary_url':'https://second.example','token':token}
    a.config['primaries'].append(q);a.primary_states[q['profile_id']]=a.default_state();a.init_cache(q['profile_id'])
    def route(settings,path,payload):
        previous=m.DB_PATH
        m.DB_PATH=second_db if settings['primary_url']==q['primary_url'] else first_db
        try:
            response=c.post(path,json=payload,headers={'Authorization':'Bearer '+settings['token']})
            if response.status_code>=400: raise OSError('Transport failure')
            return response.json
        finally: m.DB_PATH=previous
    monkeypatch.setattr(a,'primary_call',route)
    a.poll_one(p);a.poll_one(q)
    probe=MagicMock(return_value=cert_report());monkeypatch.setattr(a,'check_certificate',probe)
    a.run_local_check([(p['profile_id'],due(p)),(q['profile_id'],due(q))]);probe.assert_called_once()
    a.flush_outbox(p)
    assert a.cache_stats(q['profile_id'])['queued_results']==1
    with m.db() as con: assert con.execute('SELECT COUNT(*) FROM check_history').fetchone()[0]==1
    a.flush_outbox(q)
    monkeypatch.setattr(m,'DB_PATH',second_db)
    with m.db() as con: assert con.execute('SELECT COUNT(*) FROM check_history').fetchone()[0]==1


def test_signed_update_rejects_traversal_and_rolls_back(env,monkeypatch,tmp_path):
    _,_,_,data=env;key,public,package=release_package()
    raw=base64.b64decode(package['archive'])
    modified=io.BytesIO(raw)
    with zipfile.ZipFile(modified,'a') as z: z.writestr('../outside.py','print("bad")')
    raw=modified.getvalue()
    manifest={**package['manifest'],'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    malicious={'manifest':manifest,'signature':base64.b64encode(key.sign(updates.signed_bytes(manifest))).decode(),'archive':base64.b64encode(raw).decode()}
    with pytest.raises(ValueError,match='Unsafe'): updates.verify(malicious,public)
    root=tmp_path/'rollback';root.mkdir()
    for name in updates.RUNTIME:
        path=AGENT_DIR/name
        if path.is_file(): shutil.copy2(path,root/name)
    (root/'VERSION').write_text('4.6.4\n')
    snapshots={f.name:f.read_bytes() for f in root.iterdir()}
    updates.atomic_json(data/'pending_update.json',package)
    original=Path.replace
    def broken_replace(self,target):
        if self.name=='agent.py.update-tmp': raise OSError('injected disk error')
        return original(self,target)
    monkeypatch.setattr(Path,'replace',broken_replace)
    with pytest.raises(OSError): updates.apply_pending(root,data,public)
    assert all((root/name).read_bytes()==content for name,content in snapshots.items())


def test_actual_http_primary_agent_sync_and_replay(env,monkeypatch):
    """Exercise urllib transport, real listener, bearer auth and result ingestion."""
    import threading
    from werkzeug.serving import make_server
    c,p,sid,_=env
    server=make_server('127.0.0.1',0,m.app,threaded=True)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    original_url=p['primary_url']
    p['primary_url']='http://127.0.0.1:'+str(server.server_port)
    monkeypatch.setattr(a,'primary_call',REAL_PRIMARY_CALL)
    monkeypatch.setattr(a,'check_certificate',lambda *args:cert_report())
    try:
        a.poll_one(p)
        assert due(p)['hostname']=='service.example'
        a.run_local_check([(p['profile_id'],due(p))])
        a.poll_one(p)
        assert a.cache_stats(p['profile_id'])['queued_results']==0
        with m.db() as con:
            assert con.execute('SELECT COUNT(*) FROM check_history').fetchone()[0]==1
            assert con.execute('SELECT version FROM monitoring_agents WHERE id=?',(p['agent_id'],)).fetchone()[0]=='4.6.5'
    finally:
        server.shutdown();thread.join(3);server.server_close();p['primary_url']=original_url


def test_multi_primary_update_statuses_remain_independent(env,monkeypatch):
    _,p,_,data=env;_,public,package=release_package()
    monkeypatch.setenv('AGENT_UPDATE_PUBLIC_KEY',public)
    second={**p,'profile_id':a.profile_id(),'primary_url':'https://second.example','token':'second-token'}
    a.config['primaries'].append(second)
    calls=MagicMock(return_value=package);monkeypatch.setattr(a,'primary_call',calls)
    one={'command_id':'1'*32,'action':'stage','version':'4.6.5','release_id':package['manifest']['sha256']}
    two={**one,'command_id':'2'*32}
    ao.receive_update(a,p,one);ao.receive_update(a,second,two)
    assert ao.update_state(data,p['profile_id'])['command_id']==one['command_id']
    assert ao.update_state(data,second['profile_id'])['command_id']==two['command_id']
    ao.receive_update(a,p,one)
    assert calls.call_count==2
