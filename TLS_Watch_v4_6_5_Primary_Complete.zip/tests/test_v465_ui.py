from html.parser import HTMLParser
from pathlib import Path
import re
import app


def test_operations_ui_ids_and_form_bindings():
    class Parser(HTMLParser):
        def __init__(self): super().__init__();self.ids=[]
        def handle_starttag(self,tag,attrs):
            value=dict(attrs).get('id')
            if value:self.ids.append(value)
    page=(app.BASE/'static/index.html').read_text(encoding='utf-8')
    script=(app.BASE/'static/operations.js').read_text(encoding='utf-8')
    parser=Parser();parser.feed(page)
    assert len(parser.ids)==len(set(parser.ids))
    referenced=set(re.findall(r"by\('([^']+)'\)",script))
    assert referenced<=set(parser.ids),referenced-set(parser.ids)
    assert 'innerHTML' not in script
    assert 'X-TLSWatch-Admin' in script
    assert 'v4.6.5' in page
    assert '<details class="panel ops-panel" id="operationsPanel">' in page
