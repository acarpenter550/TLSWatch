"""v4.6.5 monitoring policies, notification controls, SMTP, retention and audit."""
from __future__ import annotations
import json
import os
import smtplib
import ssl
import threading
import uuid
import time
from datetime import timedelta
from email.message import EmailMessage
from flask import jsonify, request, g

M = None
MAIL_LOCK = threading.Lock()
LAST_HOUSEKEEPING = 0


def migrate(con):
    columns = {
        'sites': {'interval_hours':'INTEGER NOT NULL DEFAULT 24', 'warning_days':'INTEGER NOT NULL DEFAULT 30',
                  'notifications_enabled':'INTEGER NOT NULL DEFAULT 1', 'profile_id':'INTEGER',
                  'tls_details_json':'TEXT'},
        'monitoring_agents': {'health_json':'TEXT', 'update_status_json':'TEXT'},
        'check_history': {'tls_details_json':'TEXT'},
    }
    for table, fields in columns.items():
        existing={r[1] for r in con.execute('PRAGMA table_info('+table+')')}
        for name, kind in fields.items():
            if name not in existing: con.execute(f'ALTER TABLE {table} ADD COLUMN {name} {kind}')
    con.executescript('''
    CREATE TABLE IF NOT EXISTS monitoring_profiles (
      id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE,
      interval_hours INTEGER NOT NULL, warning_days INTEGER NOT NULL, notifications_enabled INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS alert_controls (
      site_id INTEGER PRIMARY KEY REFERENCES sites(id) ON DELETE CASCADE,
      acknowledged INTEGER NOT NULL DEFAULT 0, snooze_until TEXT, note TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS maintenance_windows (
      id INTEGER PRIMARY KEY, name TEXT NOT NULL, starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
      site_ids_json TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY, occurred_at TEXT NOT NULL, actor TEXT NOT NULL,
      method TEXT NOT NULL, path TEXT NOT NULL, action TEXT NOT NULL, details_json TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS operations_settings (key TEXT PRIMARY KEY, value_json TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS mail_outbox (
      id INTEGER PRIMARY KEY, site_id INTEGER REFERENCES sites(id) ON DELETE CASCADE,
      event TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
      attempts INTEGER NOT NULL DEFAULT 0, next_attempt_at TEXT NOT NULL, created_at TEXT NOT NULL,
      delivered_at TEXT, last_error TEXT);
    CREATE INDEX IF NOT EXISTS idx_mail_pending ON mail_outbox(status,next_attempt_at);
    CREATE TABLE IF NOT EXISTS deferred_alerts (
      site_id INTEGER PRIMARY KEY REFERENCES sites(id) ON DELETE CASCADE, created_at TEXT NOT NULL);
    ''')
    con.execute("INSERT OR IGNORE INTO operations_settings VALUES ('retention', ?)",
                (json.dumps({'history_days':365,'checks_per_site':1000,'audit_days':365,'delivery_days':30}),))
    con.execute("INSERT OR IGNORE INTO operations_settings VALUES ('smtp', ?)",
                (json.dumps({'enabled':False,'host':'','port':587,'mode':'starttls','username':'','sender':'','recipients':[]}),))
    con.execute("UPDATE mail_outbox SET status='pending' WHERE status='sending'")


def settings(con, key):
    row=con.execute('SELECT value_json FROM operations_settings WHERE key=?',(key,)).fetchone()
    return json.loads(row[0])


def save(con,key,value):
    con.execute('INSERT OR REPLACE INTO operations_settings VALUES (?,?)',(key,json.dumps(value)))


def audit(con, action, details=None):
    user=(request.authorization.username if request.authorization else None) if request else None
    con.execute('INSERT INTO audit_log(occurred_at,actor,method,path,action,details_json) VALUES (?,?,?,?,?,?)',
                (M.utc_iso(M.utcnow()),user or 'local administrator',request.method if request else 'SYSTEM',
                 request.path if request else '',action,json.dumps(details or {})))


def interval_next(site, now):
    hours=int(dict(site).get('interval_hours',24))
    # Fixed cadence avoids daily-calendar randomness delaying a 24-hour policy.
    return M.utc_iso(now+timedelta(hours=hours))


def suppressed(con, site_id, now=None):
    now=now or M.utc_iso(M.utcnow())
    site=con.execute('SELECT notifications_enabled FROM sites WHERE id=?',(site_id,)).fetchone()
    if not site or not site[0]: return True
    control=con.execute('SELECT * FROM alert_controls WHERE site_id=?',(site_id,)).fetchone()
    if control and (control['acknowledged'] or (control['snooze_until'] and control['snooze_until']>now)): return True
    for row in con.execute('SELECT site_ids_json FROM maintenance_windows WHERE starts_at<=? AND ends_at>?',(now,now)):
        ids=json.loads(row[0])
        if not ids or site_id in ids: return True
    return False


def notification_transition(con,before,after):
    # Existing recovery/expiry events are preserved; add profile-defined threshold.
    events=list(dict.fromkeys(M.classify_events(before,after)))
    threshold=after.get('warning_days',30)
    if (after.get('days_left') is not None and after['days_left']<=threshold and
            (before.get('days_left') is None or before['days_left']>threshold)):
        events.append('profile_expiration_warning')
    recovered=M.site_needs_attention(before) and not M.site_needs_attention(after)
    if recovered:
        # Acknowledgments clear on recovery; subsequent incidents can alert again.
        con.execute('UPDATE alert_controls SET acknowledged=0 WHERE site_id=?',(after['id'],))
        con.execute('DELETE FROM deferred_alerts WHERE site_id=?',(after['id'],))
        if 'attention_cleared' not in events: events.append('attention_cleared')
    if suppressed(con,after['id']):
        if M.site_needs_attention(after): defer(con,after['id'])
        return True
    cfg=settings(con,'smtp')
    if cfg['enabled'] and events:
        unique=list(dict.fromkeys(events))
        payload={**M.site_public_record(after),'events':unique}
        con.execute('''INSERT INTO mail_outbox(site_id,event,payload,next_attempt_at,created_at)
            VALUES (?,?,?,?,?)''',(after['id'],unique[0],json.dumps(payload),M.utc_iso(M.utcnow()),M.utc_iso(M.utcnow())))
    return False


def send_mail(cfg,event,payload):
    message=EmailMessage()
    message['Subject']='TLS Watch: '+event.replace('_',' ')+' — '+payload.get('hostname','notification')
    message['From']=cfg['sender']
    message['To']=', '.join(cfg['recipients'])
    fields=[('Events',', '.join(payload.get('events',[event])).replace('_',' ')),
            ('Website',payload.get('url') or payload.get('hostname','TLS Watch')),
            ('Certificate expires',payload.get('expires_at','Not yet observed')),
            ('Days remaining',payload.get('days_left','Unknown')),
            ('TLS trust','Verified' if payload.get('tls_verified') else 'Not verified'),
            ('Last error',payload.get('last_error') or payload.get('verify_error') or 'None'),
            ('Last check',payload.get('last_checked_at','Not applicable'))]
    message.set_content('\n'.join(label+': '+str(value) for label,value in fields))
    # Password stays in the service environment, never in API/DB/audit output.
    secret=os.environ.get('SMTP_PASSWORD','')
    client=smtplib.SMTP_SSL if cfg['mode']=='tls' else smtplib.SMTP
    options={'host':cfg['host'],'port':cfg['port'],'timeout':10}
    if cfg['mode']=='tls': options['context']=ssl.create_default_context()
    with client(**options) as smtp:
        if cfg['mode']=='starttls': smtp.starttls(context=ssl.create_default_context())
        if cfg['username']: smtp.login(cfg['username'],secret)
        smtp.send_message(message)


def deliver_mail():
    if not MAIL_LOCK.acquire(False): return
    try:
        with M.db() as con:
            con.execute('BEGIN IMMEDIATE')
            cfg=settings(con,'smtp')
            if not cfg['enabled']: return
            row=con.execute("SELECT * FROM mail_outbox WHERE status='pending' AND next_attempt_at<=? ORDER BY id LIMIT 1",(M.utc_iso(M.utcnow()),)).fetchone()
            if not row: return
            if row['site_id'] and suppressed(con,row['site_id']):
                con.execute("UPDATE mail_outbox SET status='suppressed' WHERE id=?",(row['id'],))
                return
            con.execute("UPDATE mail_outbox SET status='sending',attempts=attempts+1 WHERE id=?",(row['id'],))
        try:
            send_mail(cfg,row['event'],json.loads(row['payload']))
            with M.db() as con:
                con.execute("UPDATE mail_outbox SET status='delivered',delivered_at=?,last_error=NULL WHERE id=?",(M.utc_iso(M.utcnow()),row['id']))
        except Exception:
            # SMTP exceptions can contain usernames, server banners or mail content.
            attempts=row['attempts']+1
            with M.db() as con:
                con.execute("UPDATE mail_outbox SET status=?,last_error=?,next_attempt_at=? WHERE id=?",
                            ('failed' if attempts>=3 else 'pending','SMTP delivery failed; check server, TLS and credentials',M.utc_iso(M.utcnow()+timedelta(seconds=60*attempts)),row['id']))
    finally: MAIL_LOCK.release()


def housekeeping():
    with M.db() as con:
        cfg=settings(con,'retention')
        cutoff=M.utc_iso(M.utcnow()-timedelta(days=cfg['history_days']))
        con.execute('DELETE FROM check_history WHERE checked_at<?',(cutoff,))
        # Keep the current leaf and every version recently observed.
        con.execute('''DELETE FROM certificate_history WHERE last_seen_at<? AND NOT EXISTS
            (SELECT 1 FROM sites s WHERE s.id=certificate_history.site_id AND s.certificate_pem=certificate_history.certificate_pem)''',(cutoff,))
        con.execute('DELETE FROM audit_log WHERE occurred_at<?',(M.utc_iso(M.utcnow()-timedelta(days=cfg['audit_days'])),))
        older=M.utc_iso(M.utcnow()-timedelta(days=cfg['delivery_days']))
        con.execute("DELETE FROM mail_outbox WHERE created_at<? AND status NOT IN ('pending','sending')",(older,))
        con.execute("DELETE FROM webhook_deliveries WHERE created_at<? AND status NOT IN ('pending','sending')",(older,))
        # Replay IDs must outlive any supported offline spool; do not expire receipts.


def tick():
    global LAST_HOUSEKEEPING
    with M.db() as con:
        for row in con.execute('SELECT s.* FROM deferred_alerts d JOIN sites s ON s.id=d.site_id LIMIT 100').fetchall():
            site=dict(row)
            if not M.site_needs_attention(site):
                con.execute('DELETE FROM deferred_alerts WHERE site_id=?',(site['id'],))
            elif not suppressed(con,site['id']):
                M.queue_specific_event(con,site,'needs_attention')
                con.execute('DELETE FROM deferred_alerts WHERE site_id=?',(site['id'],))
    if time.monotonic()-LAST_HOUSEKEEPING>3600:
        housekeeping()
        LAST_HOUSEKEEPING=time.monotonic()


def queue_named(con,site,event):
    if suppressed(con,site['id']):
        if M.site_needs_attention(site): defer(con,site['id'])
        return True
    if settings(con,'smtp')['enabled']:
        con.execute('INSERT INTO mail_outbox(site_id,event,payload,next_attempt_at,created_at) VALUES (?,?,?,?,?)',
                    (site['id'],event,json.dumps(M.site_public_record(site)),M.utc_iso(M.utcnow()),M.utc_iso(M.utcnow())))
    return False


def defer(con,sid):
    con.execute('INSERT OR IGNORE INTO deferred_alerts VALUES (?,?)',(sid,M.utc_iso(M.utcnow())))


def sanitize_health(value):
    if value is None: return {}
    if not isinstance(value,dict) or len(json.dumps(value))>4000: raise ValueError('Invalid agent health')
    output={}
    for key in ('disk_free_bytes','memory_total_bytes','memory_available_bytes'):
        if key in value: output[key]=integer(value[key],0,2**60,key)
    if 'cpu_percent' in value:
        number=value['cpu_percent']
        if type(number) not in (int,float) or not 0<=number<=100: raise ValueError('Invalid CPU percentage')
        output['cpu_percent']=number
    if value.get('oldest_pending_at'): output['oldest_pending_at']=utc_input(value['oldest_pending_at'])
    if 'queue_blocked' in value:
        if type(value['queue_blocked']) is not bool: raise ValueError('Invalid queue flag')
        output['queue_blocked']=value['queue_blocked']
    if isinstance(value.get('queue_limits'),dict):
        output['queue_limits']={k:integer(v,1,2**31-1,k) for k,v in value['queue_limits'].items() if k in ('rows','bytes','days')}
    return output


def integer(value, low, high, name):
    if type(value) is not int or not low<=value<=high: raise ValueError(f'{name} must be {low}–{high}')
    return value


def policy(body):
    hours=body.get('interval_hours',24)
    if type(hours) is not int or hours not in (1,6,12,24): raise ValueError('Interval must be 1, 6, 12 or 24 hours')
    days=integer(body.get('warning_days',30),1,365,'Warning days')
    enabled=body.get('notifications_enabled',True)
    if type(enabled) is not bool: raise ValueError('notifications_enabled must be boolean')
    return hours,days,int(enabled)


def utc_input(value):
    if not isinstance(value,str) or len(value)>50: raise ValueError('An ISO timestamp with timezone is required')
    dt=M.parse_datetime(value)
    if dt.tzinfo is None: raise ValueError('Timestamp must include a timezone')
    return M.utc_iso(dt)


def register(module):
    global M
    M=module
    app=M.app

    @app.before_request
    def operations_request_guard():
        if request.path.startswith('/api/operations') and request.method!='GET':
            if request.headers.get('X-TLSWatch-Admin')!='1': return M.error(403,'Missing administrator request header')
            if request.method in ('POST','PUT','PATCH') and (not request.is_json or not isinstance(request.get_json(silent=True),dict)):
                return M.error(400,'Send a JSON object')
        if request.method in ('POST','PUT','PATCH','DELETE') and not request.path.startswith('/agent/'):
            g.audit_write=True

    @app.after_request
    def audit_mutation(response):
        if getattr(g,'audit_write',False) and 200<=response.status_code<300:
            # Never log bodies, headers, query strings or response secrets.
            with M.db() as con: audit(con,'administrator_change',{'status':response.status_code})
        if request.path.startswith('/api/operations'): response.headers['Cache-Control']='no-store'
        return response

    @app.get('/api/operations')
    def overview():
        with M.db() as con:
            data={'profiles':[dict(r) for r in con.execute('SELECT * FROM monitoring_profiles ORDER BY name')],
                  'maintenance':[dict(r) for r in con.execute('SELECT * FROM maintenance_windows ORDER BY starts_at DESC LIMIT 200')],
                  'alerts':[dict(r) for r in con.execute('SELECT * FROM alert_controls')],
                  'smtp':settings(con,'smtp'),'retention':settings(con,'retention'),
                  'audit':[dict(r) for r in con.execute('SELECT * FROM audit_log ORDER BY id DESC LIMIT 100')],
                  'mail':[dict(r) for r in con.execute('SELECT id,site_id,event,status,attempts,created_at,last_error FROM mail_outbox ORDER BY id DESC LIMIT 50')]}
            data['agents']=[{'id':r['id'],'name':r['name'],'version':r['version'],
                            'last_seen_at':r['last_seen_at'],'health':json.loads(r['health_json'] or '{}'),
                            'update_status':json.loads(r['update_status_json'] or '{}')} for r in con.execute('SELECT * FROM monitoring_agents')]
        data['smtp']['password_configured']=bool(os.environ.get('SMTP_PASSWORD'))
        data['version']=M.VERSION
        return jsonify(data)

    @app.post('/api/operations/profiles')
    @app.put('/api/operations/profiles/<int:pid>')
    def profile_save(pid=None):
        body=M.json_body() or {}
        try:
            name=body.get('name','')
            if not isinstance(name,str) or not 1<=len(name.strip())<=80: raise ValueError('Profile name must be 1–80 characters')
            values=policy(body)
            with M.db() as con:
                if pid:
                    if not con.execute('SELECT 1 FROM monitoring_profiles WHERE id=?',(pid,)).fetchone(): return M.error(404,'Profile not found')
                    con.execute('UPDATE monitoring_profiles SET name=?,interval_hours=?,warning_days=?,notifications_enabled=? WHERE id=?',(name.strip(),*values,pid))
                    con.execute('UPDATE sites SET interval_hours=?,warning_days=?,notifications_enabled=?,next_check_at=CASE WHEN paused=1 THEN NULL ELSE ? END WHERE profile_id=?',(*values,M.utc_iso(M.utcnow()),pid))
                else:
                    if con.execute('SELECT COUNT(*) FROM monitoring_profiles').fetchone()[0]>=200: raise ValueError('Profile limit reached')
                    pid=con.execute('INSERT INTO monitoring_profiles(name,interval_hours,warning_days,notifications_enabled) VALUES (?,?,?,?)',(name.strip(),*values)).lastrowid
            return jsonify({'ok':True,'id':pid})
        except (ValueError,M.sqlite3.IntegrityError) as exc: return M.error(400,str(exc))

    @app.delete('/api/operations/profiles/<int:pid>')
    def profile_delete(pid):
        with M.db() as con:
            con.execute('UPDATE sites SET profile_id=NULL WHERE profile_id=?',(pid,))
            con.execute('DELETE FROM monitoring_profiles WHERE id=?',(pid,))
        return jsonify({'ok':True})

    @app.put('/api/operations/sites/<int:sid>/policy')
    def site_policy(sid):
        body=M.json_body() or {}
        try:
            with M.db() as con:
                if not con.execute('SELECT 1 FROM sites WHERE id=?',(sid,)).fetchone(): return M.error(404,'Site not found')
                pid=body.get('profile_id')
                if pid is not None:
                    integer(pid,1,2**31-1,'Profile ID')
                    row=con.execute('SELECT * FROM monitoring_profiles WHERE id=?',(pid,)).fetchone()
                    if not row: raise ValueError('Profile not found')
                    values=(row['interval_hours'],row['warning_days'],row['notifications_enabled'])
                else: values=policy(body)
                con.execute('UPDATE sites SET interval_hours=?,warning_days=?,notifications_enabled=?,profile_id=?,next_check_at=CASE WHEN paused=1 THEN NULL ELSE ? END WHERE id=?',(*values,pid,M.utc_iso(M.utcnow()),sid))
            return jsonify({'ok':True})
        except ValueError as exc: return M.error(400,str(exc))

    @app.put('/api/operations/sites/<int:sid>/alert')
    def control_alert(sid):
        body=M.json_body() or {}
        try:
            acknowledged=body.get('acknowledged',False)
            if type(acknowledged) is not bool: raise ValueError('acknowledged must be boolean')
            until=utc_input(body['snooze_until']) if body.get('snooze_until') else None
            if until and not M.utc_iso(M.utcnow())<until<=M.utc_iso(M.utcnow()+timedelta(days=365)): raise ValueError('Snooze must end within the next year')
            note=body.get('note','')
            if not isinstance(note,str) or len(note)>500: raise ValueError('Note must be at most 500 characters')
            with M.db() as con:
                if not con.execute('SELECT 1 FROM sites WHERE id=?',(sid,)).fetchone(): return M.error(404,'Site not found')
                con.execute('INSERT OR REPLACE INTO alert_controls VALUES (?,?,?,?,?)',(sid,int(acknowledged),until,note,M.utc_iso(M.utcnow())))
                if acknowledged or until: defer(con,sid)
            return jsonify({'ok':True})
        except ValueError as exc: return M.error(400,str(exc))

    @app.post('/api/operations/maintenance')
    def maintenance_add():
        body=M.json_body() or {}
        try:
            name=body.get('name','')
            if not isinstance(name,str) or not 1<=len(name.strip())<=80: raise ValueError('Maintenance name required (1–80 characters)')
            starts,ends=utc_input(body.get('starts_at')),utc_input(body.get('ends_at'))
            if starts>=ends or M.parse_datetime(ends)-M.parse_datetime(starts)>timedelta(days=366): raise ValueError('Maintenance must have an end after its start, within one year')
            ids=body.get('site_ids',[])
            if not isinstance(ids,list) or len(ids)>20000 or any(type(i) is not int or i<1 for i in ids): raise ValueError('site_ids must be a list of positive IDs; empty applies globally')
            with M.db() as con:
                M.require_existing_ids(con,'sites',ids)
                rid=con.execute('INSERT INTO maintenance_windows(name,starts_at,ends_at,site_ids_json,created_at) VALUES (?,?,?,?,?)',(name.strip(),starts,ends,json.dumps(ids),M.utc_iso(M.utcnow()))).lastrowid
            return jsonify({'ok':True,'id':rid})
        except ValueError as exc: return M.error(400,str(exc))

    @app.delete('/api/operations/maintenance/<int:wid>')
    def maintenance_remove(wid):
        with M.db() as con: con.execute('DELETE FROM maintenance_windows WHERE id=?',(wid,))
        return jsonify({'ok':True})

    @app.put('/api/operations/smtp')
    def smtp_save():
        body=M.json_body() or {}
        try:
            cfg={key:body.get(key) for key in ('enabled','host','port','mode','username','sender','recipients')}
            if type(cfg['enabled']) is not bool: raise ValueError('enabled must be boolean')
            integer(cfg['port'],1,65535,'SMTP port')
            if cfg['mode'] not in ('tls','starttls'): raise ValueError('Choose TLS or STARTTLS')
            for key in ('host','username','sender'):
                if not isinstance(cfg[key],str) or len(cfg[key])>253 or any(ord(c)<32 for c in cfg[key]): raise ValueError('Invalid SMTP '+key)
            addresses=cfg['recipients']
            if not isinstance(addresses,list) or len(addresses)>25 or any(not isinstance(a,str) or len(a)>254 or '@' not in a or any(c.isspace() for c in a) or any(ord(c)<32 for c in a) for a in addresses): raise ValueError('Provide up to 25 recipient email addresses')
            if cfg['enabled'] and (not cfg['host'] or '@' not in cfg['sender'] or not addresses): raise ValueError('SMTP host, sender and recipients required')
            with M.db() as con: save(con,'smtp',cfg)
            return jsonify({'ok':True})
        except ValueError as exc: return M.error(400,str(exc))

    @app.post('/api/operations/smtp/test')
    def smtp_test():
        with M.db() as con:
            if not settings(con,'smtp')['enabled']: return M.error(400,'Configure and enable SMTP first')
            con.execute('INSERT INTO mail_outbox(site_id,event,payload,next_attempt_at,created_at) VALUES (NULL,?,?,?,?)',('test',json.dumps({'hostname':'TLS Watch test notification'}),M.utc_iso(M.utcnow()),M.utc_iso(M.utcnow())))
        return jsonify({'ok':True,'message':'Test email queued; see delivery status'})

    @app.put('/api/operations/retention')
    def retention_save():
        body=M.json_body() or {}
        try:
            cfg={key:integer(body.get(key),low,high,key) for key,low,high in (('history_days',1,3650),('checks_per_site',10,100000),('audit_days',30,3650),('delivery_days',1,365))}
            with M.db() as con: save(con,'retention',cfg)
            return jsonify({'ok':True})
        except ValueError as exc: return M.error(400,str(exc))
