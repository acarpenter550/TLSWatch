# TLS Watch Agent 4.6 — multi-primary remote agent

**Agent-only release.** The primary application stays at **TLS Watch v4.5** until a primary-side change is requested. This v4.6 agent speaks the **unchanged primary v4.5 agent protocol** and requires no primary upgrade. The agent runs natively on Linux (including Proxmox LXC) or with Docker on a Linux host.

## What's new

A single remote agent can enroll with **up to 32 independent TLS Watch primaries**. Each primary controls the websites assigned to its enrollment and receives only its own results. The agent's local dashboard lists every primary separately, with connection status, last contact/sync, assigned websites, queued/rejected offline results, and last check/error.

- **Independent pairing and identities.** To connect another primary, create an agent in that primary's *Monitoring Agents* panel, generate a one-time code, then enter its URL and code in the agent's **Add another primary** form. An existing enrollment is not replaced.
- **Independent durable queues.** Pairing tokens are stored in `data/agent.json` (or Docker `/data/agent.json`), with **one SQLite database per primary** (`primary_<profile_id>.sqlite3`). A primary outage doesn't interrupt tests or result uploads for any other primary.
- **Offline autonomous scheduling.** A primary supplies its assigned sites on initial sync. From then on, the agent keeps locally randomized daily schedules, checking and queueing results even if that primary cannot be reached. When it reconnects, queued observations are uploaded oldest-first. Result IDs are unique and the v4.5 primary deduplicates replays.
- **Shared physical checks when due together.** When multiple primaries have a check **due at the same scheduling scan** for the same hostname and port, the agent performs a single TLS handshake and writes a **separate timestamped result, next check time, and unique ID to each primary's outbox**. It never shares its authentication tokens or inventory between primaries. This is a best-effort coalescing optimization, not a guarantee that checks scheduled at different times will be merged.
- **Safe disconnect.** Removing a primary is blocked while a check or sync is in progress. If results are pending, disconnect requires separate explicit confirmation that those undelivered results will be permanently discarded. Other profiles are untouched. A disconnected agent registration remains in the primary's own dashboard until it is removed there.
- **Backward-compatible migration.** Existing v4.5 `agent.json` and `agent_cache.sqlite3` are converted on first startup to one v4.6 primary profile. The v4.5 SQLite data is **copied using SQLite's backup API** (including committed WAL changes), preserving cached schedules/results. Original v4.5 cache files remain available for rollback. The v4.6 configuration is then saved atomically.

### Example MSP/customer deployment

```text
            Single customer-LAN TLS Watch Agent 4.6
                       (native Linux or Docker)
                         /           \
             MSP Primary v4.5     Customer Primary v4.5
               45 assignments      12 assignments
               local queue A       local queue B
               token A             token B
```

Assignments on both primaries are kept separate, even if they happen to use the same numeric website IDs. A primary can only receive results for its own agent registration. **There is no agent endpoint that lets one primary retrieve the other primary's inventory.**

## Installation: native Linux / Proxmox LXC (recommended)

Requirements: Linux with Python 3.10+, `python3-venv`, outbound internet/LAN connectivity and working local DNS/routing.

```bash
unzip TLS_Watch_Agent_v4_6_Linux_Docker.zip -d tlswatch-agent
cd tlswatch-agent
chmod +x install_linux.sh start_agent.sh install_user_service.sh
./install_linux.sh
./start_agent.sh
```

For startup via systemd user service:

```bash
./install_user_service.sh
sudo loginctl enable-linger YOUR_LINUX_USERNAME
```

The installer only copies `.env.example` to `.env` when `.env` does not already exist; it does not overwrite an existing v4.5 `.env`. The agent data directory is `./data/` unless `AGENT_DATA_DIR` is configured.

## Installation: Docker on Linux

```bash
cp .env.example .env    # if upgrading, preserve and edit your existing .env
chmod 600 .env
docker compose up -d --build
docker compose logs -f tls-watch-agent
```

The default `compose.yaml` uses **`network_mode: host`** on Linux: TLS checks use the Docker host's real network stack, DNS, routing and VPN connections. A Docker instance inside a Proxmox LXC shares the LXC network, not the Proxmox hypervisor's network. The persistent named Docker volume stores all profiles and queues. Never use `docker compose down -v` if you want to preserve them.

For Docker platforms without Linux host networking, `compose.bridge.yaml` is provided. Bridge networking **does not** make a container's localhost equal the host's localhost, and DNS/routes may differ. Prefer host mode for LAN scanning.

## Access and pairing

The Web UI defaults to **port 8899 on all local network interfaces**:

`http://AGENT-LAN-IP:8899`

Initial Basic Auth credentials, as requested for TLS Watch builds:

- Username: `admin`
- Password: `admin1234`

**Change those values in `.env` immediately**, and protect port 8899 with a trusted LAN firewall, VPN or HTTPS reverse proxy. HTTP Basic authentication does **not** encrypt credentials. If you use a reverse proxy, terminate TLS at the proxy; it does not change the agent's TLS scanning behavior.

For each primary, create a separate agent registration under **Monitoring Agents** on that primary, and enter its pairing code on the agent Web UI. Enter a primary URL that is actually reachable **from the agent**, never `localhost` unless the primary runs on the same machine. Use HTTPS with a publicly trusted or custom PEM CA. HTTP primary communication is a clearly labeled, opt-in testing exception; tokens and certificate results are unencrypted over HTTP.

Existing primary-side controls for **Check Using** continue to assign/reassign sites. You may assign different sites from each primary to the same agent. Website groups and webhooks remain primary-side features, unchanged.

## Native and Docker configuration

Edit `.env` and restart:

| Variable | Default | Description |
|---|---|---|
| `AGENT_UI_BIND` | `0.0.0.0` | Web UI accessible on LAN interfaces. For local-only UI use `127.0.0.1`. Does not affect outbound TLS checks. |
| `AGENT_UI_PORT` | `8899` | Web UI listening port. |
| `AGENT_UI_USERNAME` | `admin` | Initial Web UI username; change before wider exposure. |
| `AGENT_UI_PASSWORD` | `admin1234` | Initial Web UI password; change before wider exposure. |
| `POLL_SECONDS` | `15` | Independent poll interval for each primary (clamped 5–60 s). |
| `AGENT_WORKERS` | `3` | Simultaneous TLS check workers (clamped 1–8). |
| `TLS_TIMEOUT_SECONDS` | `8` | Per-socket TLS connect timeout (clamped 3–30 s). |
| `AGENT_DATA_DIR` | `./data` native / `/data` Docker | Durable agent pairing and SQLite queue storage. |

### Migrating from v4.5

1. Stop the **v4.5** agent process or Docker container; don't run v4.5 and v4.6 against the same volume.
2. Back up `data/` or the complete Docker volume **including its SQLite files** and your existing `.env`.
3. Replace the agent application files. Keep `.env` and its full original `data/` directory/volume.
4. Start v4.6. The existing primary connection appears under Connected primary servers and retains its site inventory and queued observations. Add the second primary using a new pairing code.
5. Only after validating the migrated instance, consider removing obsolete v4.5 backups. The migration leaves the original `agent_cache.sqlite3` intact.

**Do not use the old v4.5 Disconnect action before upgrading**: it deletes stored results and pairing details.

## Monitoring limitations and recovery

- Each primary must synchronize assignments at least once before its sites can be tested during outages. An agent cannot discover primary-side assignment changes while that primary is down.
- If you remove a site from a primary while offline, that primary may reject results from the old assignment when it reconnects. Rejections remain visible in the per-primary queue statistics.
- A single failed target can legitimately produce multiple failure records if two different primaries have independently scheduled checks at different times.
- Pending results use the v4.5 primary's 365-day timestamp acceptance window; don't rely on an indefinitely offline cache.
- If a primary fails DNS or token authentication, other primaries still connect and sync separately. Each is retried on its own polling cycle.
- `localhost` as a **target** refers to the agent machine (native Linux or Linux host Docker). Use LAN IP/FQDN for other servers.

## Verification

After `./install_linux.sh`:

```bash
.venv/bin/python -m unittest discover -s tests -v
```

The tests cover multi-primary cache isolation, offline queue replay, shared-handshake coalescing, and v4.5 migration. The v4.5 primary API is deliberately unchanged; **primary-side upgrades are not required**. Validate with two test primaries before production use.
