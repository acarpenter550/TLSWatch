# TLS Watch v4.6 — agent-only release

- Add independent connections to multiple v4.5 primary servers (up to 32).
- Web UI to enroll multiple primaries and inspect individual connectivity / queue metrics.
- Retain independent offline schedules and SQLite result queues for each primary.
- Group same-target checks due together so one handshake can feed independent queues.
- Automatically migrate existing v4.5 single-primary pairing and SQLite cache in place.
- Keep native Linux and Docker deployment options and host network mode.
- Keep LAN UI defaults on new installs; basic username `admin`, password `admin1234` (CHANGE IMMEDIATELY).
- No changes to primary; a future primary change can be released separately as v4.6.

Status: Python syntax / UI JavaScript checks and isolated core unit tests passed in the build environment. Flask/Docker runtime and two-primary live integration not executed in this environment. Test with two non-production primaries before production rollout.
