#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "$(readlink -f -- "$0")")" && pwd)"
cd "$ROOT"
if [[ ! -f "$ROOT/.env" ]]; then
  echo 'Missing .env; first run ./install_linux.sh' >&2
  exit 1
fi
if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
  echo 'Missing Python virtual environment; first run ./install_linux.sh' >&2
  exit 1
fi
set -a
# .env is administrator-controlled. Values containing shell metacharacters
# must be quoted in a shell-compatible way when used for native Linux.
source "$ROOT/.env"
set +a
export AGENT_DATA_DIR="${AGENT_DATA_DIR:-$ROOT/data}"
mkdir -p "$AGENT_DATA_DIR"
exec "$ROOT/.venv/bin/python" "$ROOT/agent.py"
