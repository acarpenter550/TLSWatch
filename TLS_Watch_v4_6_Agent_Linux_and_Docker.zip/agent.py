"""TLS Watch Remote Agent 4.6: multi-primary, independently durable certificate monitoring.

Each enrolled primary owns its own token, assignment cache, and result outbox.
All remote communication is initiated by this agent. The primary 4.5 protocol
(/agent/v1/enroll, /sync, /results/batch) is unchanged.
"""
from __future__ import annotations

import hmac
import json
import os
import secrets
import socket
import sqlite3
import ssl
import threading
import time
import urllib.error
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager, closing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from flask import Flask, jsonify, render_template_string, request

VERSION = "4.6.0"
DATA_DIR = Path(os.environ.get("AGENT_DATA_DIR", str(Path(__file__).resolve().parent / "data")))
CONFIG_FILE = DATA_DIR / "agent.json"  # v4.5 legacy is auto-migrated
LEGACY_CACHE_FILE = DATA_DIR / "agent_cache.sqlite3"
PORT = int(os.environ.get("AGENT_UI_PORT", "8899"))
UI_BIND = os.environ.get("AGENT_UI_BIND", "0.0.0.0").strip()
UI_USERNAME = os.environ.get("AGENT_UI_USERNAME", "admin").strip()
UI_PASSWORD = os.environ.get("AGENT_UI_PASSWORD", "admin1234")
POLL_SECONDS = max(5, min(60, int(os.environ.get("POLL_SECONDS", "15"))))
TLS_TIMEOUT = max(3, min(30, int(os.environ.get("TLS_TIMEOUT_SECONDS", "8"))))
WORKERS = max(1, min(8, int(os.environ.get("AGENT_WORKERS", "3"))))
MAX_PRIMARIES = 32

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200_000
lock = threading.RLock()
config: dict = {"schema_version": 2, "primaries": []}
primary_states: dict[str, dict] = {}
local_inflight: set[tuple[str, int]] = set()
syncing: set[str] = set()
next_polls: dict[str, float] = {}
check_pool = ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix="tls-check")
network_pool = ThreadPoolExecutor(max_workers=10, thread_name_prefix="tls-primary")
stop_event = threading.Event()


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def profile_id() -> str:
    return uuid.uuid4().hex


def cache_path(pid: str) -> Path:
    if not isinstance(pid, str) or len(pid) != 32 or any(c not in "0123456789abcdef" for c in pid):
        raise ValueError("Invalid primary profile ID")
    return DATA_DIR / ("primary_" + pid + ".sqlite3")


def atomic_config(new: dict) -> None:
    """On-disk config is replaced atomically; avoids partial credentials after crashes."""
    global config
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = CONFIG_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(new, indent=2), encoding="utf-8")
    os.chmod(temp, 0o600)
    temp.replace(CONFIG_FILE)
    config = new


def load_config() -> None:
    """Upgrade a paired v4.5 agent in place without losing its offline queue."""
    global config
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(DATA_DIR, 0o700)
    if not CONFIG_FILE.exists():
        config = {"schema_version": 2, "primaries": []}
        return
    raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("Invalid agent configuration")
    if raw.get("schema_version") == 2 and isinstance(raw.get("primaries"), list):
        checked = set()
        for item in raw["primaries"]:
            pid = item.get("profile_id")
            cache_path(pid)
            if pid in checked or not item.get("token") or not item.get("primary_url"):
                raise ValueError("Invalid or duplicate primary profile")
            checked.add(pid)
        config = raw
    elif raw.get("token") and raw.get("primary_url"):
        pid = profile_id()
        new = {"schema_version": 2, "primaries": [{**raw, "profile_id": pid}]}
        # SQLite backup() captures any committed WAL changes, including queued results.
        # Original files are retained for rollback; v4.5 may be stopped before upgrade.
        if LEGACY_CACHE_FILE.exists():
            dest = cache_path(pid)
            with closing(sqlite3.connect(LEGACY_CACHE_FILE, timeout=30)) as src, closing(sqlite3.connect(dest, timeout=30)) as out:
                src.backup(out)
                out.commit()
            os.chmod(dest, 0o600)
        else:
            init_cache(pid)
        atomic_config(new)
    else:
        # An unpaired v4.5 installation can upgrade without enrollment.
        atomic_config({"schema_version": 2, "primaries": []})
    for profile in config["primaries"]:
        init_cache(profile["profile_id"])
        primary_states.setdefault(profile["profile_id"], default_state())


def default_state() -> dict:
    return {"last_contact": None, "last_sync": None, "last_error": None,
            "last_result": None, "checks": 0, "running": 0,
            "timezone": "America/New_York"}


def profiles() -> list[dict]:
    with lock:
        return [dict(p) for p in config["primaries"]]


def profile_by_id(pid: str) -> dict | None:
    with lock:
        return next((dict(p) for p in config["primaries"] if p["profile_id"] == pid), None)


def still_active(settings: dict) -> bool:
    current = profile_by_id(settings["profile_id"])
    return current is not None and hmac.compare_digest(current["token"], settings["token"])


def primary_url(raw: str, allow_http: bool) -> str:
    value = raw.strip().rstrip("/")
    parsed = urlsplit(value)
    if (parsed.scheme != "https" and not (parsed.scheme == "http" and allow_http)) or not parsed.hostname:
        raise ValueError("Use HTTPS, or explicitly allow HTTP on a trusted network")
    if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ("", "/"):
        raise ValueError("Primary URL must contain only the scheme, hostname and optional port")
    if parsed.port is not None and not 1 <= parsed.port <= 65535:
        raise ValueError("Invalid primary port")
    return value


def make_context(settings: dict) -> ssl.SSLContext:
    context = ssl.create_default_context()
    if settings.get("ca_pem"):
        context.load_verify_locations(cadata=settings["ca_pem"])
    return context


class RejectRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError("Primary redirected request; refusing to forward agent credentials")


def primary_call(settings: dict, path: str, data: dict) -> dict:
    payload = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(settings["primary_url"] + path, payload,
            {"Content-Type": "application/json", "User-Agent": "TLSWatch-Agent/4.6"}, method="POST")
    if path != "/agent/v1/enroll":
        req.add_header("Authorization", "Bearer " + settings["token"])
    try:
        opener = urllib.request.build_opener(RejectRedirect(), urllib.request.HTTPSHandler(context=make_context(settings)))
        with opener.open(req, timeout=18) as response:
            limit = 8_000_000 if path == "/agent/v1/sync" else 200_000
            raw = response.read(limit + 1)
            if len(raw) > limit:
                raise ValueError("Primary response exceeded size limit")
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise ValueError("Primary response must be a JSON object")
            return result
    except urllib.error.HTTPError as exc:
        error = exc.read(2000).decode("utf-8", "replace")
        raise RuntimeError(f"Primary returned HTTP {exc.code}: {error[:400]}") from exc


def tls_handshake(host: str, dest: tuple, verify: bool):
    family, address = dest
    ctx = ssl.create_default_context() if verify else ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    with socket.socket(family, socket.SOCK_STREAM) as sock:
        sock.settimeout(TLS_TIMEOUT)
        sock.connect(address)
        with ctx.wrap_socket(sock, server_hostname=host) as channel:
            return None if verify else channel.getpeercert(binary_form=True)


def check_certificate(host: str, port: int) -> dict:
    # Resolve/connect from the remote agent's LAN. No HTTP request or page download.
    addresses = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    if not addresses:
        raise OSError("Hostname has no resolved addresses")
    last_error = None
    der, chosen = None, None
    for family, _, _, _, sockaddr in addresses:
        try:
            der = tls_handshake(host, (family, sockaddr), False)
            if der:
                chosen = (family, sockaddr)
                break
        except (OSError, ssl.SSLError) as exc:
            last_error = exc
    if der is None or chosen is None:
        raise OSError(str(last_error or "Server did not present a certificate"))
    if len(der) > 30_000:
        raise ValueError("Certificate exceeds maximum supported length")
    pem = ssl.DER_cert_to_PEM_cert(der)
    verify_error = None
    verified = True
    try:
        tls_handshake(host, chosen, True)
    except (OSError, ssl.SSLError) as exc:
        verified = False
        verify_error = str(exc)[:600]
    return {"success": True, "certificate_pem": pem, "tls_verified": verified,
            "verify_error": verify_error}


# Per-primary SQLite inventories and result queues.
CACHE_SCHEMA = """
CREATE TABLE IF NOT EXISTS inventory (
 site_id INTEGER PRIMARY KEY, url TEXT NOT NULL, hostname TEXT NOT NULL,
 port INTEGER NOT NULL, paused INTEGER NOT NULL DEFAULT 0,
 next_check_at TEXT, last_checked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_local_due ON inventory(paused,next_check_at);
CREATE TABLE IF NOT EXISTS outbox (
 result_id TEXT PRIMARY KEY,site_id INTEGER NOT NULL,checked_at TEXT NOT NULL,
 payload_json TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',
 rejected_reason TEXT,created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_outbox_pending ON outbox(status,checked_at);
"""


def init_cache(pid: str) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    path = cache_path(pid)
    with closing(sqlite3.connect(path, timeout=20)) as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(CACHE_SCHEMA)
        con.commit()
    os.chmod(path, 0o600)


@contextmanager
def cache_db(pid: str):
    path = cache_path(pid)
    if not path.exists():
        with lock:
            if not path.exists():
                init_cache(pid)
    con = sqlite3.connect(path, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=20000")
    try:
        yield con
        con.commit()
    except BaseException:
        con.rollback()
        raise
    finally:
        con.close()


def next_random_check(now: datetime, tz: str) -> str:
    try:
        zone = ZoneInfo(tz)
    except (ZoneInfoNotFoundError, ValueError):
        zone = timezone.utc
    date = now.astimezone(zone).date() + timedelta(days=1)
    start = datetime(date.year, date.month, date.day, tzinfo=zone).astimezone(timezone.utc)
    later = date + timedelta(days=1)
    end = datetime(later.year, later.month, later.day, tzinfo=zone).astimezone(timezone.utc)
    seconds = max(1, int((end - start).total_seconds()))
    return (start + timedelta(seconds=secrets.randbelow(seconds))).isoformat(timespec="seconds").replace("+00:00", "Z")


def cache_stats(pid: str) -> dict:
    with cache_db(pid) as con:
        total = con.execute("SELECT COUNT(*) FROM inventory").fetchone()[0]
        pending = con.execute("SELECT COUNT(*) FROM outbox WHERE status='pending'").fetchone()[0]
        rejected = con.execute("SELECT COUNT(*) FROM outbox WHERE status='rejected'").fetchone()[0]
        last = con.execute("SELECT MAX(last_checked_at) FROM inventory").fetchone()[0]
        earliest = con.execute("SELECT MIN(checked_at) FROM outbox WHERE status='pending'").fetchone()[0]
        reject = con.execute("SELECT rejected_reason FROM outbox WHERE status='rejected' ORDER BY created_at DESC LIMIT 1").fetchone()
    return {"assigned_sites": total, "queued_results": pending, "rejected_results": rejected,
            "last_local_check": last, "oldest_pending_at": earliest,
            "last_rejection": reject[0] if reject else None}


def reconcile_assignments(pid: str, assignments: list[dict]) -> None:
    if not isinstance(assignments, list) or len(assignments) > 20000:
        raise ValueError("Invalid primary assignment snapshot")
    seen = set()
    with cache_db(pid) as con:
        con.execute("BEGIN IMMEDIATE")
        for item in assignments:
            if not isinstance(item, dict):
                raise ValueError("Invalid assignment")
            site_id = item.get("site_id")
            if (type(site_id) is not int or site_id < 1 or site_id in seen or
                not isinstance(item.get("hostname"), str) or not item["hostname"] or
                not isinstance(item.get("url"), str) or not item["url"] or
                type(item.get("port")) is not int or not 1 <= item["port"] <= 65535 or
                item.get("paused") not in (0, 1)):
                raise ValueError("Invalid site assignment from primary")
            seen.add(site_id)
            prior = con.execute("SELECT * FROM inventory WHERE site_id=?", (site_id,)).fetchone()
            remote_last = item.get("last_checked_at")
            # Retain local schedule while offline observations are still ahead
            # of the primary's recorded time, preventing double-checking.
            same_target = bool(prior and prior["hostname"] == item["hostname"] and prior["port"] == item["port"])
            protect_local = (same_target and prior["last_checked_at"] and
                             (not remote_last or prior["last_checked_at"] > remote_last))
            next_at = prior["next_check_at"] if protect_local else item.get("next_check_at")
            if not next_at and not item["paused"]:
                next_at = stamp()
            last_at = prior["last_checked_at"] if protect_local else remote_last
            con.execute("""INSERT INTO inventory
                (site_id,url,hostname,port,paused,next_check_at,last_checked_at)
                VALUES (?,?,?,?,?,?,?) ON CONFLICT(site_id) DO UPDATE SET
                url=excluded.url,hostname=excluded.hostname,port=excluded.port,
                paused=excluded.paused,next_check_at=excluded.next_check_at,
                last_checked_at=excluded.last_checked_at""",
                (site_id, item["url"], item["hostname"], item["port"], int(item["paused"]),
                 next_at if not item["paused"] else None, last_at))
        if seen:
            placeholders = ",".join("?" for _ in seen)
            con.execute(f"DELETE FROM inventory WHERE site_id NOT IN ({placeholders})", tuple(sorted(seen)))
        else:
            con.execute("DELETE FROM inventory")
        # Already checked results are deliberately retained for the primary to
        # ACK or reject if the website was reassigned during disconnection.


def flush_outbox(settings: dict) -> None:
    pid = settings["profile_id"]
    with cache_db(pid) as con:
        rows = con.execute("""SELECT result_id,payload_json FROM outbox WHERE status='pending'
                 ORDER BY checked_at,result_id LIMIT 15""").fetchall()
    if not rows:
        return
    selected, size = [], 20
    for row in rows:
        estimated = len(row["payload_json"].encode("utf-8")) + 2
        if selected and size + estimated > 350_000:
            break
        selected.append(row)
        size += estimated
    result_data = [json.loads(row["payload_json"]) for row in selected]
    reply = primary_call(settings, "/agent/v1/results/batch", {"results": result_data})
    outcomes = reply.get("outcomes", [])
    if not isinstance(outcomes, list) or len(outcomes) != len(selected):
        raise RuntimeError("Primary returned incomplete outbox acknowledgment")
    expected = {r["result_id"] for r in selected}
    if {r.get("result_id") for r in outcomes} != expected:
        raise RuntimeError("Primary acknowledged unexpected results")
    if not still_active(settings):
        return
    with cache_db(pid) as con:
        for outcome in outcomes:
            rid = outcome["result_id"]
            result = outcome.get("status")
            if result in ("accepted", "duplicate"):
                con.execute("DELETE FROM outbox WHERE result_id=?", (rid,))
            elif result == "rejected":
                con.execute("UPDATE outbox SET status='rejected',rejected_reason=? WHERE result_id=?",
                            (str(outcome.get("reason", "Rejected by primary"))[:400], rid))
            else:
                raise RuntimeError("Unrecognized result acknowledgment status")


def run_local_check(jobs: list[tuple[str, dict]]) -> None:
    """One physical TLS handshake can be fanned out to multiple due primary jobs.

    Each primary independently gets its own result ID, timestamp, schedule,
    and outbox entry; no identity or access token is shared between them.
    """
    try:
        site = jobs[0][1]
        try:
            report = check_certificate(site["hostname"], int(site["port"]))
        except Exception as exc:
            report = {"success": False, "error": f"{type(exc).__name__}: {exc}"[:800]}
        now = datetime.now(timezone.utc)
        checked = now.isoformat(timespec="seconds").replace("+00:00", "Z")
        for pid, site in jobs:
            with lock:
                profile = next((p for p in config["primaries"] if p["profile_id"] == pid), None)
                tz = primary_states.get(pid, {}).get("timezone", "UTC")
            if not profile:
                continue
            next_at = next_random_check(now, tz)
            payload = {"result_id": uuid.uuid4().hex, "site_id": site["site_id"],
                       "checked_at": checked, "next_check_at": next_at, **report}
            try:
                with cache_db(pid) as con:
                    con.execute("BEGIN IMMEDIATE")
                    # Never overwrite a newer assignment/schedule after a
                    # concurrent primary inventory synchronization.
                    exists = con.execute("SELECT hostname,port FROM inventory WHERE site_id=?",
                                         (site["site_id"],)).fetchone()
                    if not exists or exists["hostname"] != site["hostname"] or exists["port"] != site["port"]:
                        continue
                    con.execute("""INSERT INTO outbox
                        (result_id,site_id,checked_at,payload_json,created_at) VALUES (?,?,?,?,?)""",
                        (payload["result_id"], site["site_id"], checked, json.dumps(payload), checked))
                    con.execute("UPDATE inventory SET last_checked_at=?,next_check_at=? WHERE site_id=?",
                                (checked, next_at, site["site_id"]))
                with lock:
                    s = primary_states.setdefault(pid, default_state())
                    s["checks"] += 1
                    s["last_result"] = {"site": site["url"], "success": report["success"], "at": checked}
            except Exception as exc:
                with lock:
                    primary_states.setdefault(pid, default_state())["last_error"] = (
                        f"Could not cache result for {site['url']}: {exc}"[:500])
    finally:
        with lock:
            for pid, site in jobs:
                local_inflight.discard((pid, site["site_id"]))
                s = primary_states.get(pid)
                if s:
                    s["running"] = max(0, s["running"] - 1)


def schedule_due() -> None:
    """Scan all independently persisted inventories and coalesce matching due TLS targets."""
    with lock:
        # A shared handshake may count as two profile jobs; using the number
        # of per-primary running checks is conservative but never oversubscribes.
        active_slots = WORKERS - sum(s["running"] for s in primary_states.values())
        if active_slots <= 0:
            return
        active = list(config["primaries"])
        due = []
        for profile in active:
            pid = profile["profile_id"]
            with cache_db(pid) as con:
                rows = con.execute("""SELECT * FROM inventory WHERE paused=0 AND next_check_at IS NOT NULL
                    AND next_check_at<=? ORDER BY next_check_at LIMIT ?""",
                    (stamp(), max(WORKERS * 4, 12))).fetchall()
            for row in rows:
                site = dict(row)
                if (pid, site["site_id"]) not in local_inflight:
                    due.append((pid, site))
        due.sort(key=lambda item: item[1]["next_check_at"] or "")
        by_target: dict[tuple[str, int], list[tuple[str, dict]]] = {}
        for pid, site in due:
            key = (site["hostname"].casefold(), int(site["port"]))
            by_target.setdefault(key, []).append((pid, site))
        for grouped in list(by_target.values())[:active_slots]:
            for pid, site in grouped:
                local_inflight.add((pid, site["site_id"]))
                primary_states.setdefault(pid, default_state())["running"] += 1
            check_pool.submit(run_local_check, grouped)


def poll_one(settings: dict) -> None:
    pid = settings["profile_id"]
    try:
        if not still_active(settings):
            return
        # Flush first so that previous observations advance the primary clock.
        flush_outbox(settings)
        stats = cache_stats(pid)
        reply = primary_call(settings, "/agent/v1/sync",
                             {"version": VERSION, "queued_results": stats["queued_results"],
                              "last_check_at": stats["last_local_check"]})
        if not still_active(settings):
            return
        reconcile_assignments(pid, reply["assignments"])
        with lock:
            state = primary_states.setdefault(pid, default_state())
            state.update(last_contact=stamp(), last_sync=stamp(), last_error=None,
                         timezone=reply.get("timezone", "UTC"))
    except Exception as exc:
        with lock:
            primary_states.setdefault(pid, default_state())["last_error"] = (
                f"Primary connection/sync failed: {exc}"[:500])
    finally:
        with lock:
            syncing.discard(pid)


def scheduler_step(now: float | None = None):
    now = time.monotonic() if now is None else now
    with lock:
        for settings in list(config["primaries"]):
            pid = settings["profile_id"]
            if pid in syncing or next_polls.get(pid, 0) > now:
                continue
            syncing.add(pid)
            next_polls[pid] = now + POLL_SECONDS
            network_pool.submit(poll_one, dict(settings))
    # Independent of connectivity to all primaries.
    schedule_due()


def polling_loop() -> None:
    while not stop_event.is_set():
        try:
            scheduler_step()
        except Exception as exc:
            print(f"TLS Watch scheduler failure: {exc}", flush=True)
        stop_event.wait(2)

@app.before_request
def protect_setup():
    if UI_USERNAME and UI_PASSWORD:
        credentials = request.authorization
        if (not credentials or credentials.type.lower() != "basic"
                or not hmac.compare_digest(credentials.username or "", UI_USERNAME)
                or not hmac.compare_digest(credentials.password or "", UI_PASSWORD)):
            return ("Authentication required", 401,
                    {"WWW-Authenticate": 'Basic realm="TLS Watch Agent"'})
    if request.method == "POST":
        origin = request.headers.get("Origin", "")
        if origin:
            parsed = urlsplit(origin)
            if parsed.scheme not in ("http", "https") or parsed.netloc != request.host:
                return jsonify({"error": "Invalid origin"}), 403
        # A non-simple custom header prevents cross-origin form-based CSRF
        # against a browser's cached HTTP Basic authentication credentials.
        if request.headers.get("X-TLSWatch-Agent") != "1":
            return jsonify({"error": "Missing agent UI request header"}), 403


PAGE = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TLS Watch Agent v4.6</title>
<style>
:root{color-scheme:dark;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#0d1622;color:#eff5ff}*{box-sizing:border-box}body{margin:0;padding:22px}main{max-width:1040px;margin:auto}h1{font-size:1.6rem;margin:0}h2{font-size:1.12rem;margin:0 0 12px}p,small{color:#afc4dc;line-height:1.5}header{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;border-bottom:1px solid #324054;padding-bottom:18px}.pill{background:#214839;color:#9df0c7;border-radius:20px;padding:5px 12px;font-size:.85rem}.box{background:#162436;border:1px solid #30445a;border-radius:14px;padding:22px;margin:20px 0}.stats{display:flex;flex-wrap:wrap;gap:16px;margin-top:8px}.stat{border:1px solid #3b5065;padding:10px 16px;border-radius:10px;min-width:120px}.stat b{display:block;font-size:1.35rem}.stat span{color:#b5c8dd;font-size:.85rem}label{display:block;margin:14px 0 6px;font-weight:600;font-size:.9rem}input:not([type=checkbox]),textarea{width:100%;background:#0e1b2c;color:white;border:1px solid #405772;border-radius:8px;padding:12px;font:inherit}textarea{height:90px}.checkbox{width:auto;vertical-align:middle;margin-right:8px}button{background:#2bb88b;color:#041c13;border:0;padding:11px 16px;border-radius:8px;font-weight:700;cursor:pointer;margin:7px 7px 0 0}button.secondary{background:#304a61;color:#f1f5fa}button.danger{background:#64343d;color:#fff}button:disabled{opacity:.6;cursor:not-allowed}td,th{padding:10px 12px;text-align:left;vertical-align:top;border-bottom:1px solid #30445a}th{color:#afc4dc;font-weight:600;font-size:.84rem}table{border-collapse:collapse;width:100%}.scroller{overflow-x:auto}.muted{color:#a9bfd8}.ok{color:#95f1c3}.bad{color:#ffc4bf}.warning{padding:12px;border-left:4px solid #e9b65d;background:#362f20;color:#ffe5aa;border-radius:6px;margin:14px 0}code{padding:2px 5px;background:#0d1c2c}.tiny{font-size:.78rem}.wrap{overflow-wrap:anywhere;word-break:break-word;max-width:280px}#feedback{min-height:22px;white-space:pre-wrap}footer{margin:25px 0;color:#9eb7d0}@media(max-width:700px){body{padding:12px}.box{padding:14px}table{font-size:.86rem}td,th{padding:8px}.stats{gap:7px}.stat{min-width:90px;padding:8px}}
</style></head><body><main>
<header><div><h1>TLS Watch · Remote Agent</h1><small>v4.6.0 · Multiple independent primaries · Offline queues</small></div><span class="pill" id="overall">Loading…</span></header>
<div class="warning" id="defaultWarn" hidden>Default admin credentials are enabled. Change AGENT_UI_USERNAME and AGENT_UI_PASSWORD in .env before allowing untrusted users to reach this interface. Use HTTPS/VPN; Basic authentication on HTTP is not encrypted.</div>
<section class="box"><h2>Local monitoring summary</h2><div class="stats"><div class="stat"><b id="primaryCount">0</b><span>Primaries</span></div><div class="stat"><b id="assignedTotal">0</b><span>Assignments</span></div><div class="stat"><b id="queuedTotal">0</b><span>Queued results</span></div><div class="stat"><b id="checksTotal">0</b><span>Checks this run</span></div></div><p class="tiny">Each primary controls only its own assignments. Shared target checks are reused when concurrently due, but results and credentials remain isolated per primary.</p></section>
<section class="box"><h2>Connected primary servers</h2><div class="scroller"><table><thead><tr><th>Primary / Agent</th><th>Connection</th><th>Sites</th><th>Queue</th><th>Last contact</th><th>Management</th></tr></thead><tbody id="rows"><tr><td colspan="6">No primary connected yet.</td></tr></tbody></table></div><p id="managementFeedback" role="status"></p></section>
<section class="box"><h2>Add another primary</h2><p>Create a monitoring agent and 15-minute pairing code on the desired primary (TLS Watch v4.5+). Add it here without disturbing the other primaries.</p>
<form id="pair"><label for="url">Primary URL (reachable from this machine)</label><input id="url" type="url" placeholder="https://monitor.customer.example:8080" required><label for="code">One-time pairing code</label><input id="code" type="password" autocomplete="off" required><label><input id="allow" class="checkbox" type="checkbox">Allow plain HTTP to primary (trusted lab networks only)</label><label for="ca">Additional trusted CA certificate for the primary (PEM; optional)</label><textarea id="ca" spellcheck="false" placeholder="-----BEGIN CERTIFICATE-----"></textarea><div><button type="submit" id="connect">Connect to primary</button></div><p id="feedback" role="status"></p></form></section>
<footer>Monitoring probes originate from this Linux machine's real network interfaces and routes. Connections to all primaries are outbound. Local assignments and result queues survive agent restarts and primary outages. Keep the /data volume or native data/ directory.</footer>
</main><script>
const byId=id=>document.getElementById(id);
async function call(path,options={}){const r=await fetch(path,options);let data={};try{data=await r.json();}catch(e){}if(!r.ok)throw Error(data.error||'HTTP '+r.status);return data;}
const posted=data=>({method:'POST',headers:{'Content-Type':'application/json','X-TLSWatch-Agent':'1'},body:JSON.stringify(data)});
function addCell(row,value,css=''){const td=document.createElement('td');td.textContent=value;td.className=css;row.appendChild(td);return td;}
async function refresh(){try{const d=await call('/api/state');byId('overall').textContent=d.primaries.length+' primary connection(s)';byId('primaryCount').textContent=d.primaries.length;byId('assignedTotal').textContent=d.assigned_sites;byId('queuedTotal').textContent=d.queued_results;byId('checksTotal').textContent=d.checks;byId('defaultWarn').hidden=!d.default_credentials;
const body=byId('rows');body.replaceChildren();if(!d.primaries.length){const tr=document.createElement('tr');addCell(tr,'No primary connected yet.').colSpan=6;body.appendChild(tr);}
for(const p of d.primaries){const tr=document.createElement('tr');const first=addCell(tr,p.agent_name||'Unnamed');first.appendChild(document.createElement('br'));const small=document.createElement('small');small.textContent=p.primary_url;small.className='wrap';first.appendChild(small);addCell(tr,p.connection,p.connection==='Connected'?'ok':'bad');addCell(tr,String(p.assigned_sites));addCell(tr,String(p.queued_results)+' pending / '+p.rejected_results+' rejected');addCell(tr,p.last_contact||'Never');const tools=document.createElement('td');const detail=document.createElement('details');const summary=document.createElement('summary');summary.textContent='Details';detail.appendChild(summary);const paragraph=document.createElement('p');paragraph.className='tiny wrap';paragraph.textContent='Last sync: '+(p.last_sync||'Never')+' | Last check: '+(p.last_local_check||'Never')+' | Last error: '+(p.last_error||'None');detail.appendChild(paragraph);tools.appendChild(detail);
const remove=document.createElement('button');remove.type='button';remove.className='danger tiny';remove.textContent='Disconnect';remove.addEventListener('click',()=>removePrimary(p));tools.appendChild(remove);tr.appendChild(tools);body.appendChild(tr);}
}catch(e){byId('overall').textContent='Status unavailable';byId('managementFeedback').textContent=e.message;}}
async function removePrimary(p){if(!confirm('Disconnect '+p.agent_name+' at '+p.primary_url+'? Its local inventory will be removed. Other primary connections are not affected.'))return;try{await call('/api/disconnect',posted({profile_id:p.profile_id}));byId('managementFeedback').textContent='Disconnected '+p.agent_name;await refresh();}catch(e){if(p.queued_results>0&&confirm('This primary has '+p.queued_results+' undelivered result(s). FORCE DISCONNECT will permanently discard them. Proceed?')){try{await call('/api/disconnect',posted({profile_id:p.profile_id,force:true}));byId('managementFeedback').textContent='Disconnected; pending results discarded.';await refresh();}catch(x){byId('managementFeedback').textContent=x.message;}}else{byId('managementFeedback').textContent=e.message;}}}
byId('pair').addEventListener('submit',async e=>{e.preventDefault();const button=byId('connect');button.disabled=true;byId('feedback').textContent='Connecting…';try{await call('/api/pair',posted({primary_url:byId('url').value,enrollment_code:byId('code').value,allow_http:byId('allow').checked,ca_pem:byId('ca').value}));byId('feedback').textContent='Primary connected. Inventory sync begins automatically.';byId('code').value='';byId('url').value='';byId('ca').value='';await refresh();}catch(x){byId('feedback').textContent=x.message;}finally{button.disabled=false;}});
refresh();setInterval(refresh,5000);
</script></body></html>'''


@app.get("/")
def home():
    return render_template_string(PAGE)


@app.get("/api/state")
def public_state():
    with lock:
        active = list(config["primaries"])
        states = {p["profile_id"]: dict(primary_states.get(p["profile_id"], default_state())) for p in active}
    result = []
    for profile in active:
        pid = profile["profile_id"]
        info = cache_stats(pid)
        s = states[pid]
        last = s["last_contact"]
        try:
            online = bool(last and (datetime.now(timezone.utc) - datetime.fromisoformat(last.replace("Z", "+00:00"))).total_seconds() < 90)
        except (ValueError, TypeError):
            online = False
        result.append({"profile_id": pid, "primary_url": profile["primary_url"],
                       "agent_name": profile.get("agent_name"), "agent_id": profile.get("agent_id"),
                       "connection": "Connected" if online else "Offline / retrying",
                       **s, **info})
    return jsonify({"version": VERSION, "configured": bool(result), "primaries": result,
                    "assigned_sites": sum(p["assigned_sites"] for p in result),
                    "queued_results": sum(p["queued_results"] for p in result),
                    "rejected_results": sum(p["rejected_results"] for p in result),
                    "checks": sum(p["checks"] for p in result),
                    "default_credentials": UI_USERNAME == "admin" and UI_PASSWORD == "admin1234"})


@app.post("/api/pair")
def pair():
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return jsonify({"error": "A JSON configuration object is required"}), 400
    try:
        allow = body.get("allow_http") is True
        url = primary_url(str(body.get("primary_url", "")), allow)
        code = body.get("enrollment_code", "")
        ca = body.get("ca_pem", "")
        if not isinstance(code, str) or not 35 <= len(code) <= 160:
            raise ValueError("Paste the complete enrollment code")
        if not isinstance(ca, str) or len(ca) > 20000:
            raise ValueError("Custom CA certificate is too large")
        with lock:
            if len(config["primaries"]) >= MAX_PRIMARIES:
                raise ValueError("Maximum number of primary connections reached")
            if any(p["primary_url"].casefold() == url.casefold() for p in config["primaries"]):
                raise ValueError("This primary URL is already connected; disconnect before re-pairing")
        pending = {"primary_url": url, "ca_pem": ca, "allow_http": allow}
        reply = primary_call(pending, "/agent/v1/enroll", {"enrollment_code": code})
        token = reply.get("agent_token")
        agent_id = reply.get("agent_id")
        name = reply.get("agent_name")
        if (not isinstance(token, str) or not token.startswith("tlsw-agent-") or
            type(agent_id) is not int or agent_id < 1 or not isinstance(name, str)):
            raise ValueError("Primary enrollment response was invalid")
        pid = profile_id()
        pending.update(profile_id=pid, token=token, agent_id=agent_id, agent_name=name)
        init_cache(pid)
        with lock:
            if any(p["primary_url"].casefold() == url.casefold() for p in config["primaries"]):
                raise ValueError("Primary URL became connected during enrollment")
            atomic_config({"schema_version": 2, "primaries": [*config["primaries"], pending]})
            primary_states[pid] = default_state()
        return jsonify({"ok": True, "profile_id": pid, "agent_name": name})
    except Exception as exc:
        return jsonify({"error": f"{type(exc).__name__}: {exc}"[:600]}), 400


@app.post("/api/disconnect")
def disconnect():
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or not isinstance(body.get("profile_id"), str):
        return jsonify({"error": "profile_id is required"}), 400
    pid = body["profile_id"]
    try:
        cache_path(pid)
        with lock:
            if not any(p["profile_id"] == pid for p in config["primaries"]):
                return jsonify({"error": "Primary profile not found"}), 404
            if pid in syncing or any(key[0] == pid for key in local_inflight):
                return jsonify({"error": "Check or synchronization in progress; retry shortly"}), 409
            stats = cache_stats(pid)
            if stats["queued_results"] and body.get("force") is not True:
                return jsonify({"error": "This primary has undelivered results. Synchronize before disconnecting or explicitly force removal."}), 409
            atomic_config({"schema_version": 2, "primaries": [p for p in config["primaries"] if p["profile_id"] != pid]})
            primary_states.pop(pid, None)
            next_polls.pop(pid, None)
        # Other profiles are unaffected. The removed database is deleted only
        # after its credentials have been removed from the agent config.
        path = cache_path(pid)
        for filename in (path, Path(str(path) + "-wal"), Path(str(path) + "-shm")):
            filename.unlink(missing_ok=True)
        return jsonify({"ok": True})
    except Exception as exc:
        return jsonify({"error": str(exc)[:600]}), 500


def validate_runtime():
    if not UI_BIND:
        raise ValueError("AGENT_UI_BIND must be a valid listen address")
    if not 1 <= PORT <= 65535:
        raise ValueError("AGENT_UI_PORT must be 1..65535")
    if (UI_USERNAME and not UI_PASSWORD) or (UI_PASSWORD and not UI_USERNAME):
        raise ValueError("Set both AGENT_UI_USERNAME and AGENT_UI_PASSWORD, or neither")
    if UI_BIND not in ("127.0.0.1", "::1", "localhost") and not (UI_USERNAME and UI_PASSWORD):
        raise ValueError("Non-loopback agent Web UI requires username and password")


if __name__ == "__main__":
    validate_runtime()
    load_config()
    threading.Thread(target=polling_loop, daemon=True, name="agent-scheduler").start()
    print(f"TLS Watch v{VERSION}: agent Web UI listening on http://{UI_BIND}:{PORT}", flush=True)
    app.run(host=UI_BIND, port=PORT, debug=False, use_reloader=False, threaded=True)
