"""Run after install: .venv/bin/python -m unittest discover -s tests -v"""
import base64
import importlib.util
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('tlswatch_remote_agent', ROOT / 'agent.py')
agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent)


class AgentRuntimeTest(unittest.TestCase):
    def setUp(self):
        self.original = (agent.UI_BIND, agent.UI_USERNAME, agent.UI_PASSWORD)

    def tearDown(self):
        agent.UI_BIND, agent.UI_USERNAME, agent.UI_PASSWORD = self.original

    def test_bind_loopback_default(self):
        agent.UI_BIND, agent.UI_USERNAME, agent.UI_PASSWORD = '127.0.0.1', '', ''
        agent.validate_runtime()

    def test_exposed_ui_requires_credentials(self):
        agent.UI_BIND, agent.UI_USERNAME, agent.UI_PASSWORD = '0.0.0.0', '', ''
        with self.assertRaises(ValueError):
            agent.validate_runtime()

    def test_basic_auth_on_setup_ui(self):
        agent.UI_BIND, agent.UI_USERNAME, agent.UI_PASSWORD = '0.0.0.0', 'test_user', 'test_password'
        agent.validate_runtime()
        with agent.app.test_client() as client:
            self.assertEqual(client.get('/api/state').status_code, 401)
            basic = base64.b64encode(b'test_user:test_password').decode()
            result = client.get('/api/state', headers={'Authorization': 'Basic ' + basic})
            self.assertEqual(result.status_code, 200)
            self.assertIn('configured', result.json)

    def test_https_required_for_primary(self):
        self.assertEqual(agent.primary_url('https://primary.example.test:8080', False),
                         'https://primary.example.test:8080')
        with self.assertRaises(ValueError):
            agent.primary_url('http://primary.example.test:8080', False)


if __name__ == '__main__':
    unittest.main()
