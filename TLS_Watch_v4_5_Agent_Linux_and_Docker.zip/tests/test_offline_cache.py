"""Agent results are written locally during a primary outage and replayed on reconnect."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import agent


class OfflineCacheTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.data=Path(self.temp.name)
        self.paths=patch.multiple(agent, DATA_DIR=self.data, CACHE_FILE=self.data/'outbox.sqlite3')
        self.paths.start()
        self.addCleanup(self.paths.stop)
        agent.init_cache()
        self.site={'site_id':21,'hostname':'internal.example.test','url':'https://internal.example.test',
                   'port':443,'paused':0,'next_check_at':agent.stamp(),'last_checked_at':None}
        agent.reconcile_assignments([self.site])

    def test_offline_queued_then_delivered(self):
        with patch.object(agent,'check_certificate',return_value={'success':False,'error':'offline test'}):
            agent.run_local_check(self.site)
        self.assertEqual(agent.cache_stats()['queued_results'],1)
        with patch.object(agent,'primary_call',side_effect=OSError('no primary')):
            with self.assertRaises(OSError):
                agent.flush_outbox({'token':'fake'})
        self.assertEqual(agent.cache_stats()['queued_results'],1)
        agent.init_cache() # simulated restart: data survives
        self.assertEqual(agent.cache_stats()['assigned_sites'],1)
        def accepted(settings,path,payload):
            self.assertEqual(path,'/agent/v1/results/batch')
            self.assertTrue(payload['results'][0]['checked_at'])
            return {'outcomes':[{'result_id':r['result_id'],'status':'accepted'} for r in payload['results']]}
        with patch.object(agent,'primary_call',side_effect=accepted):
            agent.flush_outbox({'token':'fake'})
        self.assertEqual(agent.cache_stats()['queued_results'],0)
        self.assertIsNotNone(agent.cache_stats()['last_local_check'])

    def test_local_schedule_preserved_until_results_synced(self):
        with patch.object(agent,'check_certificate',return_value={'success':False,'error':'no DNS'}):
            agent.run_local_check(self.site)
        with agent.cache_db() as db:
            last=db.execute('select last_checked_at,next_check_at from inventory where site_id=21').fetchone()
        agent.reconcile_assignments([self.site])
        with agent.cache_db() as db:
            later=db.execute('select last_checked_at,next_check_at from inventory where site_id=21').fetchone()
        self.assertEqual(tuple(last),tuple(later))


if __name__=='__main__': unittest.main()
