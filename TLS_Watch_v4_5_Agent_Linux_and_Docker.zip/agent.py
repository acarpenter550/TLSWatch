"""TLS Watch Agent v4.5. Compatible with Docker host networking or native Linux.

Remote targets are reached using this machine's DNS, routes, and interfaces.
The primary is contacted through outbound polling; no inbound primary-to-agent
connection is required.
"""
from __future__ import annotations

import base64
import sqlite3
import uuid
import secrets
from contextlib import contextmanager
from datetime import timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import hmac
import json
import os
import socket
import ssl
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit
from flask import Flask, jsonify, redirect, render_template_string, request

VERSION = "4.5.0"
DATA_DIR = Path(os.environ.get("AGENT_DATA_DIR", str(Path(__file__).resolve().parent / "data")))
CONFIG_FILE = DATA_DIR / "agent.json"
CACHE_FILE = DATA_DIR / "agent_cache.sqlite3"
PORT = int(os.environ.get("AGENT_UI_PORT", "8899"))
UI_BIND = os.environ.get("AGENT_UI_BIND", "127.0.0.1").strip()
UI_USERNAME = os.environ.get("AGENT_UI_USERNAME", "").strip()
UI_PASSWORD = os.environ.get("AGENT_UI_PASSWORD", "")
POLL_SECONDS = max(5, min(60, int(os.environ.get("POLL_SECONDS", "15"))))
TLS_TIMEOUT = max(3, min(30, int(os.environ.get("TLS_TIMEOUT_SECONDS", "8"))))
WORKERS = max(1, min(4, int(os.environ.get("AGENT_WORKERS", "3"))))

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200000
lock = threading.RLock()
config: dict = {}
state = {"last_contact": None, "last_sync": None, "last_error": None,
         "checks": 0, "last_result": None, "running": 0,
         "timezone": "America/New_York", "rejected_uploads": 0}
threads = ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix="tls-agent-check")
stop_event = threading.Event()


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def load_config() -> None:
    global config
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        with lock:
            config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def save_config(new: dict) -> None:
    global config
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temporary = CONFIG_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(new, indent=2), encoding="utf-8")
    try:
        os.chmod(temporary, 0o600)
    except OSError:
        pass
    temporary.replace(CONFIG_FILE)
    with lock:
        config = dict(new)


def primary_url(raw: str, allow_http: bool) -> str:
    value = raw.strip().rstrip("/")
    parsed = urlsplit(value)
    if (parsed.scheme != "https" and not (parsed.scheme == "http" and allow_http)) or not parsed.hostname:
        raise ValueError("Use an HTTPS primary URL, or explicitly allow HTTP for trusted testing")
    if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ("", "/"):
        raise ValueError("Primary URL must be an origin (scheme + host + optional port)")
    if parsed.port is not None and not 1 <= parsed.port <= 65535:
        raise ValueError("Invalid primary port")
    return value


def make_context(settings: dict):
    context = ssl.create_default_context()
    custom_ca = settings.get("ca_pem", "")
    if custom_ca:
        context.load_verify_locations(cadata=custom_ca)
    return context


class RejectRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError("Primary redirected the request; refusing to forward agent credentials")


def primary_call(settings: dict, path: str, data: dict) -> dict:
    raw = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(settings["primary_url"] + path, raw,
              {"Content-Type": "application/json", "User-Agent": "TLSWatch-Agent/4.5"}, method="POST")
    if path != "/agent/v1/enroll":
        req.add_header("Authorization", "Bearer " + settings["token"])
    try:
        opener = urllib.request.build_opener(RejectRedirect(),
                  urllib.request.HTTPSHandler(context=make_context(settings)))
        with opener.open(req, timeout=18) as response:
            max_reply = 8_000_000 if path == "/agent/v1/sync" else 200_000
            result = response.read(max_reply + 1)
            if len(result) > max_reply:
                raise ValueError("Primary response exceeded safety limit")
            return json.loads(result)
    except urllib.error.HTTPError as exc:
        detail = exc.read(2000).decode("utf-8", "replace")
        raise RuntimeError(f"Primary returned HTTP {exc.code}: {detail[:400]}") from exc


def tls_handshake(host: str, dest: tuple, verify: bool):
    family, address = dest
    ctx = ssl.create_default_context() if verify else ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    with socket.socket(family, socket.SOCK_STREAM) as sock:
        sock.settimeout(TLS_TIMEOUT)
        sock.connect(address)
        with ctx.wrap_socket(sock, server_hostname=host) as channel:
            return None if verify else channel.getpeercert(binary_form=True)


def check_certificate(host: str, port: int) -> dict:
    # Resolve/connect from the remote agent's LAN. No HTTP request or page download.
    addresses = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    if not addresses:
        raise OSError("Hostname has no resolved addresses")
    last_error = None
    der, chosen = None, None
    for family, _, _, _, sockaddr in addresses:
        try:
            der = tls_handshake(host, (family, sockaddr), False)
            if der:
                chosen = (family, sockaddr)
                break
        except (OSError, ssl.SSLError) as exc:
            last_error = exc
    if der is None or chosen is None:
        raise OSError(str(last_error or "Server did not present a certificate"))
    if len(der) > 30_000:
        raise ValueError("Certificate exceeds maximum supported length")
    pem = ssl.DER_cert_to_PEM_cert(der)
    verify_error = None
    verified = True
    try:
        tls_handshake(host, chosen, True)
    except (OSError, ssl.SSLError) as exc:
        verified = False
        verify_error = str(exc)[:600]
    return {"success": True, "certificate_pem": pem, "tls_verified": verified,
            "verify_error": verify_error}


# SQLite is durable: assignments and result outbox survive reboots and primary outages.
# Writes to inventory+outbox are transactional. The server deduplicates by result_id.
CACHE_SCHEMA = """
CREATE TABLE IF NOT EXISTS inventory (
 site_id INTEGER PRIMARY KEY, url TEXT NOT NULL, hostname TEXT NOT NULL,
 port INTEGER NOT NULL, paused INTEGER NOT NULL DEFAULT 0,
 next_check_at TEXT, last_checked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_local_due ON inventory(paused,next_check_at);
CREATE TABLE IF NOT EXISTS outbox (
 result_id TEXT PRIMARY KEY,site_id INTEGER NOT NULL,checked_at TEXT NOT NULL,
 payload_json TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',
 rejected_reason TEXT,created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_outbox_pending ON outbox(status,checked_at);
"""
local_inflight: set[int] = set()


def init_cache():
    DATA_DIR.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(CACHE_FILE,timeout=20) as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(CACHE_SCHEMA)
    try:
        os.chmod(CACHE_FILE,0o600)
    except OSError:
        pass


@contextmanager
def cache_db():
    if not CACHE_FILE.exists():
        with lock:
            if not CACHE_FILE.exists():
                init_cache()
    con=sqlite3.connect(CACHE_FILE,timeout=20)
    con.row_factory=sqlite3.Row
    con.execute("PRAGMA busy_timeout=20000")
    try:
        yield con
        con.commit()
    except BaseException:
        con.rollback()
        raise
    finally:
        con.close()


def next_random_check(now: datetime, tz: str) -> str:
    try:
        zone=ZoneInfo(tz)
    except ZoneInfoNotFoundError:
        zone=timezone.utc
    date=now.astimezone(zone).date()+timedelta(days=1)
    start=datetime(date.year,date.month,date.day,tzinfo=zone).astimezone(timezone.utc)
    later=date+timedelta(days=1)
    end=datetime(later.year,later.month,later.day,tzinfo=zone).astimezone(timezone.utc)
    seconds=max(1,int((end-start).total_seconds()))
    return (start+timedelta(seconds=secrets.randbelow(seconds))).isoformat(timespec="seconds").replace("+00:00","Z")


def cache_stats() -> dict:
    with cache_db() as con:
        total=con.execute("SELECT COUNT(*) FROM inventory").fetchone()[0]
        pending=con.execute("SELECT COUNT(*) FROM outbox WHERE status='pending'").fetchone()[0]
        rejected=con.execute("SELECT COUNT(*) FROM outbox WHERE status='rejected'").fetchone()[0]
        last=con.execute("SELECT MAX(last_checked_at) FROM inventory").fetchone()[0]
        earliest=con.execute("SELECT MIN(checked_at) FROM outbox WHERE status='pending'").fetchone()[0]
        last_reject=con.execute("SELECT rejected_reason FROM outbox WHERE status='rejected' ORDER BY created_at DESC LIMIT 1").fetchone()
    return {"assigned_sites":total,"queued_results":pending,"rejected_results":rejected,
            "last_local_check":last,"oldest_pending_at":earliest,
            "last_rejection":last_reject[0] if last_reject else None}


def reset_cache() -> None:
    with cache_db() as con:
        con.execute("DELETE FROM inventory")
        con.execute("DELETE FROM outbox")


def reconcile_assignments(assignments: list[dict]) -> None:
    if not isinstance(assignments,list) or len(assignments)>20000:
        raise ValueError("Invalid primary assignment snapshot")
    received=set()
    with cache_db() as con:
        con.execute("BEGIN IMMEDIATE")
        for item in assignments:
            site_id=item.get("site_id")
            if (type(site_id) is not int or site_id<1 or site_id in received or
                not isinstance(item.get("hostname"),str) or
                not isinstance(item.get("url"),str) or type(item.get("port")) is not int or
                not 1 <= item["port"] <= 65535 or
                item.get("paused") not in (0,1)):
                raise ValueError("Invalid site assignment from primary")
            received.add(site_id)
            prior=con.execute("SELECT * FROM inventory WHERE site_id=?",(site_id,)).fetchone()
            remote_last=item.get("last_checked_at")
            # Unsynchronized locally performed checks take precedence over the
            # primary's older schedule; a new primary 'check now' can still
            # override after results have synchronized.
            protect_local=(prior and prior["last_checked_at"] and
                           (not remote_last or prior["last_checked_at"]>remote_last))
            next_at=prior["next_check_at"] if protect_local else item.get("next_check_at")
            if not next_at and not item["paused"]:
                next_at=stamp()
            last_at=prior["last_checked_at"] if protect_local else remote_last
            con.execute("""INSERT INTO inventory
              (site_id,url,hostname,port,paused,next_check_at,last_checked_at)
              VALUES (?,?,?,?,?,?,?)
              ON CONFLICT(site_id) DO UPDATE SET
              url=excluded.url,hostname=excluded.hostname,port=excluded.port,
              paused=excluded.paused,next_check_at=excluded.next_check_at,
              last_checked_at=excluded.last_checked_at""",
              (site_id,item["url"],item["hostname"],item["port"],int(item["paused"]),
               next_at if not item["paused"] else None,last_at))
        # The primary is authoritative on membership. Results already obtained
        # remain in the outbox until server ACK/rejects their upload.
        if received:
            placeholders=','.join('?' for _ in received)
            con.execute(f"DELETE FROM inventory WHERE site_id NOT IN ({placeholders})",tuple(sorted(received)))
        else:
            con.execute("DELETE FROM inventory")


def flush_outbox(settings: dict) -> None:
    # A bounded batch avoids oversized PEM payloads and long write transactions.
    with cache_db() as con:
        rows=con.execute("""SELECT result_id,payload_json FROM outbox WHERE status='pending'
            ORDER BY checked_at,result_id LIMIT 15""").fetchall()
    if not rows:
        return
    selected=[]
    current_size=20
    for row in rows:
        estimated=len(row["payload_json"].encode("utf-8"))+2
        if selected and current_size+estimated>350_000:
            break
        selected.append(row)
        current_size+=estimated
    result_data=[json.loads(row["payload_json"]) for row in selected]
    reply=primary_call(settings,"/agent/v1/results/batch",{"results":result_data})
    replies=reply.get("outcomes",[])
    if not isinstance(replies,list) or len(replies)!=len(selected):
        raise RuntimeError("Primary returned incomplete outbox acknowledgement")
    wanted={r["result_id"] for r in selected}
    if {r.get("result_id") for r in replies}!=wanted:
        raise RuntimeError("Primary acknowledged unexpected result IDs")
    with cache_db() as con:
        for outcome in replies:
            result_id=outcome["result_id"]
            status=outcome.get("status")
            if status in ("accepted","duplicate"):
                con.execute("DELETE FROM outbox WHERE result_id=?",(result_id,))
            elif status=="rejected":
                con.execute("UPDATE outbox SET status='rejected',rejected_reason=? WHERE result_id=?",
                            (str(outcome.get("reason","Rejected by primary"))[:400],result_id))
            else:
                raise RuntimeError("Primary sent unrecognized acknowledgement status")


def run_local_check(site: dict):
    with lock:
        state["running"]+=1
        tz=state["timezone"]
    try:
        try:
            report=check_certificate(site["hostname"],int(site["port"]))
        except Exception as exc:
            report={"success":False,"error":f"{type(exc).__name__}: {exc}"[:800]}
        now=datetime.now(timezone.utc)
        checked=now.isoformat(timespec="seconds").replace("+00:00","Z")
        next_at=next_random_check(now,tz)
        payload={"result_id":uuid.uuid4().hex,"site_id":site["site_id"],
                 "checked_at":checked,"next_check_at":next_at,**report}
        # Check/queue/schedule commit together. If agent process terminates
        # after this transaction, startup resumes with the saved outbox.
        with cache_db() as con:
            con.execute("BEGIN IMMEDIATE")
            con.execute("""INSERT INTO outbox
              (result_id,site_id,checked_at,payload_json,created_at)
              VALUES (?,?,?,?,?)""",
              (payload["result_id"],site["site_id"],checked,json.dumps(payload),checked))
            con.execute("UPDATE inventory SET last_checked_at=?,next_check_at=? WHERE site_id=?",
                        (checked,next_at,site["site_id"]))
        with lock:
            state["checks"]+=1
            state["last_result"]={"site":site["url"],"success":report["success"],"at":checked}
    except Exception as exc:
        with lock:
            state["last_error"]=f"Could not cache result for {site['url']}: {exc}"[:500]
    finally:
        with lock:
            state["running"]-=1
            local_inflight.discard(site["site_id"])


def schedule_due():
    with lock:
        available=max(0,WORKERS-len(local_inflight))
        if available==0:
            return
        with cache_db() as con:
            due=[dict(row) for row in con.execute("""SELECT * FROM inventory
                WHERE paused=0 AND next_check_at IS NOT NULL AND next_check_at<=?
                ORDER BY next_check_at LIMIT ?""",(stamp(),max(available*3,8)))]
        for site in due:
            if len(local_inflight)>=WORKERS:
                break
            if site["site_id"] in local_inflight:
                continue
            local_inflight.add(site["site_id"])
            threads.submit(run_local_check,site)


def polling_loop():
    next_poll=0.0
    while not stop_event.is_set():
        with lock:
            current=dict(config)
        if current.get("token") and time.monotonic()>=next_poll:
            next_poll=time.monotonic()+POLL_SECONDS
            try:
                # Persisted results go first to preserve their original order.
                flush_outbox(current)
                stats=cache_stats()
                response=primary_call(current,"/agent/v1/sync",
                    {"version":VERSION,"queued_results":stats["queued_results"],
                     "last_check_at":stats["last_local_check"]})
                reconcile_assignments(response["assignments"])
                with lock:
                    state["last_contact"]=stamp()
                    state["last_sync"]=stamp()
                    state["last_error"]=None
                    state["timezone"]=response.get("timezone","UTC")
            except Exception as exc:
                with lock:
                    state["last_error"]=f"Primary connection/sync failed: {exc}"[:500]
        if current.get("token"):
            # Independent of primary connection: due checks run offline.
            schedule_due()
        stop_event.wait(2)


@app.before_request
def protect_setup():
    # The UI defaults to host loopback. Opt-in LAN binding requires authentication.
    # HTTPS should terminate at an authenticated reverse proxy or private VPN.
    if UI_USERNAME and UI_PASSWORD:
        credentials = request.authorization
        if (not credentials or credentials.type.lower() != "basic"
                or not hmac.compare_digest(credentials.username or "", UI_USERNAME)
                or not hmac.compare_digest(credentials.password or "", UI_PASSWORD)):
            return ("Authentication required", 401,
                    {"WWW-Authenticate": 'Basic realm="TLS Watch Agent"'})
    if request.method == "POST":
        origin = request.headers.get("Origin", "")
        if origin:
            parsed = urlsplit(origin)
            if parsed.scheme not in ("http", "https") or parsed.netloc != request.host:
                return jsonify({"error": "Invalid origin"}), 403


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TLS Watch Remote Agent</title><style>
:root{color-scheme:dark;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#0d1622;color:#eff5ff}*{box-sizing:border-box}body{margin:0;padding:24px}main{max-width:780px;margin:auto}header{display:flex;gap:15px;align-items:center;border-bottom:1px solid #324054;padding-bottom:18px;margin-bottom:28px}h1{font-size:1.55rem;margin:0}.pill{background:#183e3b;color:#8cf3cf;padding:5px 12px;border-radius:18px;font-size:.85rem}.box{background:#162436;border:1px solid #30445a;border-radius:14px;padding:22px;margin:20px 0}h2{font-size:1.1rem;margin:0 0 14px}p{color:#afc4dc;line-height:1.5}label{display:block;margin:16px 0 6px;font-weight:600;font-size:.9rem}input,textarea{width:100%;background:#0e1b2c;color:white;border:1px solid #405772;border-radius:8px;padding:12px;font:inherit}textarea{height:110px}button{background:#2bb88b;color:#031911;border:0;padding:12px 18px;border-radius:8px;font-weight:700;cursor:pointer;margin-top:16px}button.secondary{background:#304a61;color:#f1f5fa}small{color:#9bb3cb}dl{display:grid;grid-template-columns:170px 1fr;gap:10px;overflow-wrap:anywhere}dt{color:#adc0d4}dd{margin:0}.error{color:#ffc5c5;white-space:pre-wrap}.ok{color:#a4edc6}.check{width:auto;vertical-align:middle;margin-right:9px}code{background:#0e1b2c;padding:3px 6px}footer{color:#869eb5;font-size:.85rem;margin-top:32px}@media(max-width:520px){dl{grid-template-columns:1fr}dd{margin-bottom:8px}}</style></head><body><main><header><div><h1>TLS Watch · Remote Agent</h1><small>Outbound-only certificate monitoring · v4.5.0 · Offline resilient</small></div><span class="pill" id="status">Checking status</span></header>
<section class="box"><h2>Agent status</h2><dl><dt>Assigned name</dt><dd id="name">—</dd><dt>Primary server</dt><dd id="primary">—</dd><dt>Last contact</dt><dd id="lastContact">—</dd><dt>Checks performed</dt><dd id="checks">0</dd><dt>Assigned websites</dt><dd id="assigned">0</dd><dt>Queued results</dt><dd id="queued">0</dd><dt>Rejected uploads</dt><dd id="rejected">0</dd><dt>Last rejection reason</dt><dd id="rejection">—</dd><dt>Last local check</dt><dd id="localCheck">—</dd><dt>Last inventory sync</dt><dd id="lastSync">—</dd><dt>Currently running</dt><dd id="running">0</dd><dt>Last check result</dt><dd id="result">—</dd><dt>Communication error</dt><dd id="error">—</dd></dl></section>
<section class="box"><h2>Pair with a primary</h2><p>In the primary TLS Watch dashboard, open <strong>Monitoring agents</strong> and create an agent. Copy its one-time pairing code (expires in 15 minutes). The agent initiates all connections; no inbound firewall rules are needed on the remote LAN.</p>
<form id="pair"><label for="url">Primary URL (reachable from this agent machine)</label><input id="url" type="url" placeholder="https://tls-watch.example.net" required><label for="code">One-time pairing code</label><input id="code" type="password" autocomplete="off" required><label><input id="allow" class="check" type="checkbox">Allow HTTP to primary (trusted lab/test networks only)</label><label for="ca">Custom primary CA certificate in PEM format (optional)</label><textarea id="ca" spellcheck="false" placeholder="-----BEGIN CERTIFICATE-----"></textarea><button type="submit">Connect to primary</button><p id="pairFeedback" role="status"></p></form>
<button type="button" id="forget" class="secondary">Disconnect and forget local credentials</button></section>
<footer>Assignments and queued results persist on disk; monitoring continues during primary outages. Checks use the agent host's LAN DNS and network routes (native Linux or Docker host networking). Keep this setup UI private.</footer></main><script>
const get=id=>document.getElementById(id);
async function refresh(){try{const r=await fetch('/api/state');const d=await r.json();get('status').textContent=!d.configured?'Not paired':(d.last_contact && Date.now()-Date.parse(d.last_contact)<90000?'Connected':'Offline / retrying');get('name').textContent=d.agent_name||'—';get('primary').textContent=d.primary_url||'—';get('lastContact').textContent=d.last_contact||'—';get('checks').textContent=d.checks;get('assigned').textContent=d.assigned_sites;get('queued').textContent=d.queued_results;get('rejected').textContent=d.rejected_results;get('rejection').textContent=d.last_rejection||'—';get('localCheck').textContent=d.last_local_check||'—';get('lastSync').textContent=d.last_sync||'—';get('running').textContent=d.running;get('result').textContent=d.last_result?d.last_result.site+' ('+(d.last_result.success?'success':'failed')+')':'—';get('error').textContent=d.last_error||'—';}catch(e){get('error').textContent=e.message;}}
get('pair').addEventListener('submit',async e=>{e.preventDefault();get('pairFeedback').textContent='Connecting…';try{const r=await fetch('/api/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({primary_url:get('url').value,enrollment_code:get('code').value,allow_http:get('allow').checked,ca_pem:get('ca').value})});const v=await r.json();if(!r.ok)throw new Error(v.error);get('pairFeedback').textContent='Paired successfully';get('code').value='';await refresh();}catch(e){get('pairFeedback').textContent=e.message;}});
get('forget').addEventListener('click',async()=>{if(!confirm('Forget the paired primary, token, local assignments, and queued results? Undelivered results will be lost.'))return;await fetch('/api/disconnect',{method:'POST'});await refresh();});refresh();setInterval(refresh,5000);
</script></body></html>"""


@app.get("/")
def home():
    return render_template_string(PAGE)


@app.get("/api/state")
def public_state():
    with lock:
        c = dict(config)
        result = dict(state)
    result.update({"configured": bool(c.get("token")), "agent_name": c.get("agent_name"),
                   "primary_url": c.get("primary_url"), **cache_stats()})
    return jsonify(result)


@app.post("/api/pair")
def pair():
    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict):
        return jsonify({"error": "Invalid configuration"}), 400
    try:
        allow = body.get("allow_http") is True
        server = primary_url(str(body.get("primary_url", "")), allow)
        code = body.get("enrollment_code", "")
        ca = body.get("ca_pem", "")
        if not isinstance(code, str) or not 35 <= len(code) <= 160:
            raise ValueError("Paste the complete enrollment code")
        if not isinstance(ca, str) or len(ca) > 20000:
            raise ValueError("Custom CA certificate is too large")
        pending = {"primary_url": server, "ca_pem": ca, "allow_http": allow}
        response = primary_call(pending, "/agent/v1/enroll", {"enrollment_code": code})
        token = response.get("agent_token")
        if not isinstance(token, str) or not token.startswith("tlsw-agent-"):
            raise ValueError("Primary enrollment response was invalid")
        pending.update({"token": token,"agent_id": response["agent_id"],
                        "agent_name": response["agent_name"]})
        if config.get("token") != token:
            reset_cache()  # Never send another primary's observations after re-pairing.
        save_config(pending)
        with lock:
            state["last_error"] = None
        return jsonify({"ok": True})
    except Exception as exc:
        return jsonify({"error": f"{type(exc).__name__}: {exc}"[:600]}), 400


@app.post("/api/disconnect")
def disconnect():
    with lock:
        config.clear()
    reset_cache()
    try:
        CONFIG_FILE.unlink(missing_ok=True)
    except OSError as exc:
        return jsonify({"error": str(exc)}), 500
    return jsonify({"ok": True})


def validate_runtime():
    if not UI_BIND:
        raise ValueError("AGENT_UI_BIND must be a valid listen address")
    if not 1 <= PORT <= 65535:
        raise ValueError("AGENT_UI_PORT must be between 1 and 65535")
    if (UI_USERNAME and not UI_PASSWORD) or (UI_PASSWORD and not UI_USERNAME):
        raise ValueError("Set both AGENT_UI_USERNAME and AGENT_UI_PASSWORD, or neither")
    if UI_BIND not in ("127.0.0.1", "::1", "localhost") and not (UI_USERNAME and UI_PASSWORD):
        raise ValueError("Non-loopback AGENT_UI_BIND requires AGENT_UI_USERNAME and AGENT_UI_PASSWORD")


if __name__ == "__main__":
    validate_runtime()
    load_config()
    init_cache()
    threading.Thread(target=polling_loop, daemon=True, name="agent-poll").start()
    print(f"TLS Watch agent setup: http://{UI_BIND}:{PORT} (bind address)", flush=True)
    app.run(host=UI_BIND, port=PORT, debug=False, use_reloader=False, threaded=True)
