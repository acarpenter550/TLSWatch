# TLS Watch Remote Agent v4.5 — Native Linux or Docker

The v4.5 agent **keeps testing certificate targets even when the primary is unreachable**. On connection, it synchronizes assigned sites, then checks due certificates locally on a randomized daily schedule. Each observation is atomically written to a persistent SQLite outbox; after connectivity returns, the agent retries delivery, and the primary deduplicates results.

## Offline operation

| Condition | Behavior |
|---|---|
| Primary reachable | Agent uploads cached results, syncs assignments, then runs due checks locally. |
| Primary unavailable | Agent runs due checks and enqueues their results in SQLite on disk. |
| Agent container or LXC reboots | Pairing, assignments, schedules and cached results survive when persistent `/data` / `data/` is preserved. |
| Primary reconnects | Queued results upload automatically oldest-first, 15 per poll (15-second default). Idempotent ACKs prevent duplicates. |
| Target reassigned/deleted while disconnected | The primary rejects outdated results; they remain locally marked **rejected** for inspection, not silently dropped. |
| Primary unreachable before initial sync | No remote assignment information; first sync must succeed before offline checks can occur. |

Agent UI on `127.0.0.1:8899` shows **Assigned websites, Queued results, Rejected uploads, Last local check, Last inventory sync, and Last contact**. In the primary UI, **Monitoring Agents** shows the most recently synchronized queue depth and timestamp. Rejected results remain in local SQLite for audit. The primary accepts up to **365 days** of delayed observations; ensure the agent disk is sized for your expected maximum outage length.

**Persistence files:** `agent.json` stores pairing config and token; `agent_cache.sqlite3` plus SQLite WAL files store assignments, schedules and unsent results. Keep the same Docker volume/native `data/` directory across upgrades. On **Disconnect and forget**, the UI clears cached assignments and queued results as well as pairing credentials, so do not disconnect while queued results remain if you need them.

**Scheduling:** A synchronized agent uses the primary's configured timezone for next-day randomization, and continues on that schedule offline. Results retain actual UTC check time, not delivery time. If an agent is offline while the primary changes assignments, it only learns of changes upon reconnection. Every target is monitored by its assigned agent only, not also checked from the primary.

## Proxmox LXC recommendations

For **native Python in a Debian/Ubuntu unprivileged LXC**, start with **1 vCPU, 512 MiB RAM, 8 GiB disk**, and optionally 256–512 MiB swap. This is a planning estimate for ~100–500 sites at 3 concurrent checks, not a benchmarked capacity guarantee. For 500–2,000 sites or long disconnections, increase to **2 vCPU, 1 GiB RAM, 16 GiB disk** and adjust worker count as needed. Monitor actual CPU, memory, database growth and timeouts.

Configure the LXC with its own bridged LAN IP/DNS and routing. Being reachable over the LAN does **not** require binding the agent setup UI beyond localhost. For LAN UI, use `AGENT_UI_BIND=0.0.0.0`, Basic auth and preferably HTTPS/VPN, with firewall restrictions. A Linux Docker container using `network_mode: host` shares the *Docker host environment's* network namespace; Docker running **inside a Proxmox LXC** shares the LXC's networking, not the Proxmox hypervisor's. Native Python in LXC is simpler and avoids Docker-in-LXC nesting. For Docker, a small Linux VM is generally a cleaner choice.

---

# TLS Watch Remote Agent — Docker + Native Linux

**Agent version:** 4.5.0 (requires TLS Watch primary v4.5+ for offline sync). **The same agent.py and pairing workflow work in both deployment modes.** This package contains the agent only; the primary Flask server is installed separately.

## Network behavior

- **Outbound monitoring is not limited to localhost.** All assigned HTTPS targets are resolved and connected to **from the agent machine**, so private DNS names, RFC1918 IPs, VLANs, LAN services and site-to-site/VPN networks can be monitored wherever the machine has connectivity. It performs a TLS handshake, not an HTTP GET.
- On **Linux Docker**, the supplied `compose.yaml` uses `network_mode: host`, sharing the host's network stack, DNS and routes. It can access the host's localhost, plus LAN targets, using the same routing behavior as other processes on the host.
- With **native Linux**, the agent uses the Linux host's own network stack automatically.
- All management/task/result traffic is **agent-initiated** to the primary; the primary does not need an incoming firewall rule to this agent. Primary must be reachable from the agent.
- The **setup/status Web UI** defaults to the agent host's `127.0.0.1:8899` for security. This **does not restrict outbound monitoring targets**. You may enable LAN access to the setup UI separately; see below.

## Option A — Linux Docker (recommended when Docker is available)

Requirements: Linux host with Docker Engine and `docker compose` plugin.

```bash
cp .env.example .env
chmod 600 .env
docker compose up -d --build
docker compose logs -f tls-watch-agent
```

Open `http://127.0.0.1:8899` **on the Linux agent host**. Generate a pairing code under **Monitoring Agents** in the primary TLS Watch UI, then enter the reachable **primary HTTPS URL** and that single-use code. Use the *primary hostname/IP reachable from the agent*, not the primary's `localhost` unless they really are on the same machine. A custom CA certificate PEM is supported for the primary's private PKI.

Data persists in Docker volume `tlswatch-agent-data`; `docker compose down` does not remove it unless you specify `-v`.

### Optional Docker bridge mode

For environments where host networking is unavailable, use:

```bash
docker compose -f compose.bridge.yaml up -d --build
```

Bridge networking can usually reach LAN IPs but **container localhost is not host localhost**, and DNS/routes may differ. For this reason, **Linux host networking is the default and preferred**. Bridge compose requires a setup UI username/password, even when publishing only to host loopback, because the server binds on the container's interfaces.

## Option B — Native Linux (no Docker)

Requirements: Python **3.10+**, `python3-venv` or equivalent distribution venv package, pip installation capability, and outbound network access. Runs on common Linux distributions with these prerequisites.

```bash
chmod +x install_linux.sh start_agent.sh install_user_service.sh
./install_linux.sh
./start_agent.sh
```

Open `http://127.0.0.1:8899` **on the agent host** and pair using the same process described above. Credentials are saved to `./data/agent.json` (created with restricted permissions); `.env` controls the UI listener and poll timing. Native mode uses `.venv` and the `data/` folder and **does not require root**.

To install a persistent **systemd user service** (optional):

```bash
./install_user_service.sh
systemctl --user status tlswatch-agent
journalctl --user -u tlswatch-agent -f
```

The service usually runs while the account has a user session. For service startup at boot without login, an administrator may enable user lingering: `sudo loginctl enable-linger YOUR_LINUX_USERNAME`. On a Linux distribution without systemd, use a supervisor or start `./start_agent.sh` directly.

## Configure setup/status UI access from another LAN computer (optional)

**Only do this on trusted networks or through an HTTPS reverse proxy/VPN.** HTTP Basic credentials are *not encrypted over plain HTTP*.

1. Edit `.env` and set:

```dotenv
AGENT_UI_BIND=0.0.0.0
AGENT_UI_PORT=8899
AGENT_UI_USERNAME=admin
AGENT_UI_PASSWORD=replace_with_a_strong_password
```

2. Restart the agent (`docker compose up -d --force-recreate` for Docker; `systemctl --user restart tlswatch-agent` for systemd; or restart the native script).
3. Visit `http://AGENT-LAN-IP:8899` from another LAN computer. Limit inbound TCP/8899 in the Linux host firewall to trusted administration IPs; never forward it from the internet.

**Important:** You do **not** need to bind the Web UI to your LAN to monitor LAN HTTPS servers. The agent's outgoing probes already use the LAN with either deployment mode.

## Configuration options (`.env`)

| Variable | Default | Purpose |
|---|---|---|
| `AGENT_UI_BIND` | `127.0.0.1` | UI listener only; `0.0.0.0` allows LAN access with login required. |
| `AGENT_UI_PORT` | `8899` | UI listening port. |
| `AGENT_UI_USERNAME` / `AGENT_UI_PASSWORD` | unset | Optional on loopback, mandatory for any non-loopback UI bind. |
| `POLL_SECONDS` | `15` | Poll interval, clamped to 5–60 seconds. |
| `AGENT_WORKERS` | `3` | Concurrent TLS check workers, clamped to 1–4. |
| `TLS_TIMEOUT_SECONDS` | `8` | Per-socket timeout, clamped to 3–30 seconds. |
| `AGENT_DATA_DIR` | Native: `./data`; Docker: `/data` | Persistent agent pairing information. Normally leave unset. |

The primary controls assignment and supplies the initial schedule; the agent then schedules its own daily checks locally and queues results while offline. In the primary, choose this agent in **Check Using** for each site to be monitored from this LAN. Deleting/disable agent on primary revokes the token; `Disconnect` in the local UI removes the local token, cached inventory, and queued results (confirm there are no pending results first).

## Troubleshooting

- Confirm the Linux host can reach the private website, for example `curl -vk https://10.0.0.20:443/` or `openssl s_client -connect 10.0.0.20:443 -servername internal.example.test`. These are diagnostic examples; the agent does not download web pages.
- Internal DNS names must resolve on **the agent host**. In Docker host mode DNS is inherited from the Linux host (subject to host resolver configuration). Split DNS/VPN needs to be working on that host.
- To monitor another machine's port 443, use its LAN hostname/IP, **not** `https://localhost` (which always means the agent's own Linux host in native/host-network Docker mode).
- If using container bridge mode, `localhost` instead means the container.
- If polling fails, confirm agent can reach `https://PRIMARY-HOST/agent/v1/*`; reverse proxies must forward the Bearer authorization header.
- Self-signed **monitored target** certificates are collected, but reported as *TLS verification failures* to the primary. Custom CA PEM on the pairing screen is for verifying the *primary*, not targets.
- Do not copy `.env` or `data/agent.json` into Git. Back up pairing configuration securely; do not publish secrets.

## Package contents

- `agent.py` — outbound polling / TLS probe / pair-and-status Web UI
- `Dockerfile`, `compose.yaml`, `compose.bridge.yaml` — Docker options (host networking default on Linux)
- `install_linux.sh`, `start_agent.sh`, `install_user_service.sh` — native Linux setup, startup and optional systemd user service
- `.env.example`, `requirements.txt`, `.gitignore`, `.dockerignore` — configuration/dependencies

v4.5 requires the matching v4.5 primary API for offline syncing. The primary maintains compatibility with older v4.4 agents.

## Tests

After installing the native Python dependencies (`./install_linux.sh`), run:

```bash
.venv/bin/python -m unittest discover -s tests -v
```

These check setup UI authentication and safe listening defaults. The agent's TLS-handshake helper has also been smoke-tested against a local self-signed server; full end-to-end primary-agent and Docker deployments still require testing in your environment.
